import { useState } from 'react';
import { Users, Clock, MapPin, Award, Heart, CheckCircle, Star } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { db, generateId } from '@/lib/database';
import type { Volunteer } from '@/types/database';

export default function VolunteerPage() {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    whatsapp: '',
    dateOfBirth: '',
    address: '',
    city: 'Vadodara',
    state: 'Gujarat',
    pincode: '',
    skills: [] as string[],
    interests: [] as string[],
    availability: {
      weekdays: false,
      weekends: false,
      mornings: false,
      afternoons: false,
      evenings: false
    },
    emergencyName: '',
    emergencyRelationship: '',
    emergencyPhone: '',
    message: ''
  });

  const skillOptions = ['Teaching', 'Healthcare', 'Event Management', 'Photography', 'Writing', 'Driving', 'Technical', 'Counseling', 'Arts & Crafts'];
  const interestOptions = ['Community Service', 'Healthcare', 'Education', 'Environment', 'Youth Programs', 'Senior Care', 'Fundraising', 'Disaster Relief'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 1500));

    const volunteer: Volunteer = {
      id: generateId(),
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phone: formData.phone,
      whatsapp: formData.whatsapp,
      dateOfBirth: formData.dateOfBirth,
      address: {
        street: formData.address,
        city: formData.city,
        state: formData.state,
        pincode: formData.pincode,
        country: 'India'
      },
      skills: formData.skills,
      interests: formData.interests,
      availability: formData.availability,
      totalHours: 0,
      eventsParticipated: 0,
      status: 'Active',
      backgroundVerified: false,
      emergencyContact: {
        name: formData.emergencyName,
        relationship: formData.emergencyRelationship,
        phone: formData.emergencyPhone
      },
      joinDate: new Date().toISOString(),
      badges: [],
      notes: formData.message,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    db.volunteers.create(volunteer);
    
    toast.success('Registration successful!', {
      description: 'Welcome to the Lions Club volunteer team. We will contact you soon.',
    });
    
    setLoading(false);
  };

  const benefits = [
    { icon: Heart, title: 'Make an Impact', desc: 'Directly contribute to meaningful community projects' },
    { icon: Award, title: 'Recognition', desc: 'Earn certificates and badges for your contributions' },
    { icon: Users, title: 'Network', desc: 'Connect with like-minded individuals and leaders' },
    { icon: Star, title: 'Growth', desc: 'Develop new skills and enhance your profile' }
  ];

  return (
    <div className="min-h-screen pt-28">
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-6 bg-yellow-500 text-blue-900 font-bold">Join Our Team</Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">Become a Volunteer</h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Join our community of dedicated volunteers and make a real difference in people's lives.
          </p>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Benefits */}
          <div className="grid md:grid-cols-4 gap-6 mb-16">
            {benefits.map((item, index) => (
              <Card key={index} className="text-center border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-7 h-7 text-yellow-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-3xl text-gray-900">Volunteer Registration</CardTitle>
              <CardDescription className="text-lg">Fill in your details to join our volunteer team</CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Personal Information */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <Users className="w-5 h-5 mr-2 text-blue-600" />
                    Personal Information
                  </h3>
                  <div className="grid md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <Label>First Name *</Label>
                      <Input 
                        value={formData.firstName}
                        onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Last Name *</Label>
                      <Input 
                        value={formData.lastName}
                        onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-5 mt-4">
                    <div className="space-y-2">
                      <Label>Email *</Label>
                      <Input 
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone *</Label>
                      <Input 
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-5 mt-4">
                    <div className="space-y-2">
                      <Label>WhatsApp</Label>
                      <Input 
                        value={formData.whatsapp}
                        onChange={(e) => setFormData({...formData, whatsapp: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Date of Birth</Label>
                      <Input 
                        type="date"
                        value={formData.dateOfBirth}
                        onChange={(e) => setFormData({...formData, dateOfBirth: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                {/* Address */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <MapPin className="w-5 h-5 mr-2 text-blue-600" />
                    Address
                  </h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Street Address *</Label>
                      <Textarea 
                        value={formData.address}
                        onChange={(e) => setFormData({...formData, address: e.target.value})}
                        required
                        rows={2}
                      />
                    </div>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label>City</Label>
                        <Input value={formData.city} onChange={(e) => setFormData({...formData, city: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>State</Label>
                        <Input value={formData.state} onChange={(e) => setFormData({...formData, state: e.target.value})} />
                      </div>
                      <div className="space-y-2">
                        <Label>Pincode *</Label>
                        <Input 
                          value={formData.pincode}
                          onChange={(e) => setFormData({...formData, pincode: e.target.value})}
                          required
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Skills & Interests */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <Award className="w-5 h-5 mr-2 text-blue-600" />
                    Skills & Interests
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <Label className="mb-2 block">Skills (Select all that apply)</Label>
                      <div className="flex flex-wrap gap-2">
                        {skillOptions.map((skill) => (
                          <label key={skill} className="flex items-center space-x-2 px-3 py-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                            <Checkbox 
                              checked={formData.skills.includes(skill)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setFormData({...formData, skills: [...formData.skills, skill]});
                                } else {
                                  setFormData({...formData, skills: formData.skills.filter(s => s !== skill)});
                                }
                              }}
                            />
                            <span className="text-sm">{skill}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                    <div>
                      <Label className="mb-2 block">Areas of Interest (Select all that apply)</Label>
                      <div className="flex flex-wrap gap-2">
                        {interestOptions.map((interest) => (
                          <label key={interest} className="flex items-center space-x-2 px-3 py-2 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100">
                            <Checkbox 
                              checked={formData.interests.includes(interest)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setFormData({...formData, interests: [...formData.interests, interest]});
                                } else {
                                  setFormData({...formData, interests: formData.interests.filter(i => i !== interest)});
                                }
                              }}
                            />
                            <span className="text-sm">{interest}</span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Availability */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <Clock className="w-5 h-5 mr-2 text-blue-600" />
                    Availability
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <label className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100">
                      <Checkbox 
                        checked={formData.availability.weekdays}
                        onCheckedChange={(checked) => setFormData({...formData, availability: {...formData.availability, weekdays: checked as boolean}})}
                      />
                      <span>Weekdays</span>
                    </label>
                    <label className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100">
                      <Checkbox 
                        checked={formData.availability.weekends}
                        onCheckedChange={(checked) => setFormData({...formData, availability: {...formData.availability, weekends: checked as boolean}})}
                      />
                      <span>Weekends</span>
                    </label>
                    <label className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100">
                      <Checkbox 
                        checked={formData.availability.mornings}
                        onCheckedChange={(checked) => setFormData({...formData, availability: {...formData.availability, mornings: checked as boolean}})}
                      />
                      <span>Mornings</span>
                    </label>
                    <label className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100">
                      <Checkbox 
                        checked={formData.availability.afternoons}
                        onCheckedChange={(checked) => setFormData({...formData, availability: {...formData.availability, afternoons: checked as boolean}})}
                      />
                      <span>Afternoons</span>
                    </label>
                  </div>
                </div>

                {/* Emergency Contact */}
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-4">Emergency Contact</h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label>Name</Label>
                      <Input 
                        value={formData.emergencyName}
                        onChange={(e) => setFormData({...formData, emergencyName: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Relationship</Label>
                      <Input 
                        value={formData.emergencyRelationship}
                        onChange={(e) => setFormData({...formData, emergencyRelationship: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone</Label>
                      <Input 
                        value={formData.emergencyPhone}
                        onChange={(e) => setFormData({...formData, emergencyPhone: e.target.value})}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Message (Optional)</Label>
                  <Textarea 
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    placeholder="Tell us why you want to volunteer..."
                    rows={3}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold text-xl py-6 h-auto shadow-xl"
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3" />
                      Submitting...
                    </div>
                  ) : (
                    <>
                      <CheckCircle className="w-6 h-6 mr-2" />
                      Submit Application
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
