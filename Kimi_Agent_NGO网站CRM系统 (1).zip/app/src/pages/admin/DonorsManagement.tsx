import { useState, useEffect } from 'react';
import { Search, Plus, Sparkles, Heart } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { db, generateId } from '@/lib/database';
import type { Donor } from '@/types/database';

export default function DonorsManagement() {
  const [donors, setDonors] = useState<Donor[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingDonor, setEditingDonor] = useState<Donor | null>(null);
  const [formData, setFormData] = useState<Partial<Donor>>({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    donorType: 'Individual',
  });

  useEffect(() => {
    loadDonors();
  }, []);

  const loadDonors = () => {
    setDonors(db.donors.getAll());
  };

  const filteredDonors = donors.filter(d => 
    d.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    d.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingDonor) {
      db.donors.update(editingDonor.id, { ...formData, updatedAt: new Date().toISOString() });
      toast.success('Donor updated successfully');
    } else {
      const newDonor: Donor = {
        id: generateId(),
        ...formData,
        donorSegment: 'New',
        lifetimeValue: 0,
        totalDonations: 0,
        donationCount: 0,
        communicationPreference: ['email'],
        isRecurring: false,
        engagementScore: 50,
        churnRisk: 'low',
        tags: [],
        notes: '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as Donor;
      db.donors.create(newDonor);
      toast.success('Donor added successfully');
    }
    setIsDialogOpen(false);
    setEditingDonor(null);
    loadDonors();
  };

  const getSegmentColor = (segment: string) => {
    const colors: Record<string, string> = {
      'Major': 'bg-purple-100 text-purple-700',
      'Regular': 'bg-green-100 text-green-700',
      'Occasional': 'bg-blue-100 text-blue-700',
      'Lapsed': 'bg-gray-100 text-gray-700',
      'New': 'bg-yellow-100 text-yellow-700',
      'VIP': 'bg-red-100 text-red-700'
    };
    return colors[segment] || 'bg-gray-100 text-gray-700';
  };

  const getChurnRiskColor = (risk: string) => {
    const colors: Record<string, string> = {
      'low': 'bg-green-100 text-green-700',
      'medium': 'bg-yellow-100 text-yellow-700',
      'high': 'bg-red-100 text-red-700'
    };
    return colors[risk] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input placeholder="Search donors..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-10" />
        </div>
        <Button onClick={() => setIsDialogOpen(true)} className="bg-blue-900">
          <Plus className="w-4 h-4 mr-2" />
          Add Donor
        </Button>
      </div>

      {/* AI Insights */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-medium text-purple-900">AI Segmented</span>
            </div>
            <p className="text-2xl font-bold text-purple-700 mt-2">{donors.length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Heart className="w-5 h-5 text-red-500" />
              <span className="text-sm font-medium">Major Donors</span>
            </div>
            <p className="text-2xl font-bold text-gray-900 mt-2">{donors.filter(d => d.donorSegment === 'Major').length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">At Risk</span>
            </div>
            <p className="text-2xl font-bold text-red-600 mt-2">{donors.filter(d => d.churnRisk === 'high').length}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium">Recurring</span>
            </div>
            <p className="text-2xl font-bold text-green-600 mt-2">{donors.filter(d => d.isRecurring).length}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Donor</TableHead>
                <TableHead>Segment</TableHead>
                <TableHead>Lifetime Value</TableHead>
                <TableHead>Donations</TableHead>
                <TableHead>Churn Risk</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDonors.map((donor) => (
                <TableRow key={donor.id}>
                  <TableCell>
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-gradient-to-br from-red-500 to-pink-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
                        {donor.firstName[0]}{donor.lastName[0]}
                      </div>
                      <div>
                        <p className="font-medium">{donor.firstName} {donor.lastName}</p>
                        <p className="text-sm text-gray-500">{donor.email}</p>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge className={getSegmentColor(donor.donorSegment)}>{donor.donorSegment}</Badge>
                  </TableCell>
                  <TableCell className="font-medium">₹{donor.lifetimeValue.toLocaleString()}</TableCell>
                  <TableCell>{donor.donationCount}</TableCell>
                  <TableCell>
                    <Badge className={getChurnRiskColor(donor.churnRisk)}>{donor.churnRisk}</Badge>
                  </TableCell>
                  <TableCell>
                    {donor.isRecurring && <Badge variant="outline" className="text-green-600">Recurring</Badge>}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Donor</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>First Name *</Label>
                <Input value={formData.firstName} onChange={(e) => setFormData({...formData, firstName: e.target.value})} required />
              </div>
              <div className="space-y-2">
                <Label>Last Name *</Label>
                <Input value={formData.lastName} onChange={(e) => setFormData({...formData, lastName: e.target.value})} required />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Email *</Label>
              <Input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} required />
            </div>
            <div className="space-y-2">
              <Label>Phone</Label>
              <Input value={formData.phone} onChange={(e) => setFormData({...formData, phone: e.target.value})} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-900">Add Donor</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
