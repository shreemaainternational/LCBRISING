import { useState, useEffect } from 'react';
import { Plus, Play, Edit, Trash2, Clock, Mail, MessageSquare, Bell, Zap, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { db, generateId } from '@/lib/database';
import type { Automation, AutomationTrigger, AutomationAction } from '@/types/database';

const automationTemplates: { name: string; description: string; trigger: AutomationTrigger; actions: AutomationAction[] }[] = [
  {
    name: 'Welcome New Member',
    description: 'Send welcome email when a new member joins',
    trigger: { type: 'event', event: 'member.created' },
    actions: [{ type: 'send_email', config: { template: 'welcome' } }]
  },
  {
    name: 'Donation Thank You',
    description: 'Send thank you message after donation',
    trigger: { type: 'event', event: 'donation.completed' },
    actions: [{ type: 'send_email', config: { template: 'thank_you' } }]
  },
  {
    name: 'Birthday Wishes',
    description: 'Send birthday wishes to members',
    trigger: { type: 'schedule', schedule: '0 9 * * *' },
    actions: [{ type: 'send_whatsapp', config: { template: 'birthday' } }]
  },
  {
    name: 'Event Reminder',
    description: 'Remind attendees 24 hours before event',
    trigger: { type: 'schedule', schedule: '0 10 * * *' },
    actions: [{ type: 'send_sms', config: { template: 'event_reminder' } }]
  },
  {
    name: 'Re-engage Lapsed Donors',
    description: 'Send re-engagement campaign to donors who haven\'t donated in 6 months',
    trigger: { type: 'condition', condition: 'donor.lapsed' },
    actions: [{ type: 'send_email', config: { template: 're_engagement' } }]
  }
];

export default function AutomationPage() {
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  const [editingAutomation, setEditingAutomation] = useState<Automation | null>(null);
  const [formData, setFormData] = useState<Partial<Automation>>({
    name: '',
    description: '',
    trigger: { type: 'event', event: '' },
    conditions: [],
    actions: [],
    status: 'draft'
  });

  useEffect(() => {
    loadAutomations();
  }, []);

  const loadAutomations = () => {
    setAutomations(db.automations.getAll());
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingAutomation) {
      db.automations.update(editingAutomation.id, { ...formData, updatedAt: new Date().toISOString() });
      toast.success('Automation updated successfully');
    } else {
      const newAutomation: Automation = {
        id: generateId(),
        ...formData,
        runCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      } as Automation;
      db.automations.create(newAutomation);
      toast.success('Automation created successfully');
    }
    setIsDialogOpen(false);
    setEditingAutomation(null);
    loadAutomations();
  };

  const handleToggleStatus = (automation: Automation) => {
    const newStatus = automation.status === 'active' ? 'paused' : 'active';
    db.automations.update(automation.id, { status: newStatus, updatedAt: new Date().toISOString() });
    toast.success(`Automation ${newStatus === 'active' ? 'activated' : 'paused'}`);
    loadAutomations();
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this automation?')) {
      db.automations.delete(id);
      toast.success('Automation deleted successfully');
      loadAutomations();
    }
  };

  const applyTemplate = (template: typeof automationTemplates[0]) => {
    setFormData({
      name: template.name,
      description: template.description,
      trigger: template.trigger,
      conditions: [],
      actions: template.actions,
      status: 'paused'
    });
    setIsTemplateDialogOpen(false);
    setIsDialogOpen(true);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTriggerIcon = (type: string) => {
    switch (type) {
      case 'event': return <Bell className="w-4 h-4" />;
      case 'schedule': return <Clock className="w-4 h-4" />;
      case 'condition': return <Zap className="w-4 h-4" />;
      default: return <Zap className="w-4 h-4" />;
    }
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'send_email': return <Mail className="w-4 h-4" />;
      case 'send_sms': return <MessageSquare className="w-4 h-4" />;
      case 'send_whatsapp': return <MessageSquare className="w-4 h-4 text-green-500" />;
      default: return <Zap className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Automation Workflows</h2>
          <p className="text-gray-500">Create automated workflows for your club</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setIsTemplateDialogOpen(true)}>
            <Calendar className="w-4 h-4 mr-2" />
            Use Template
          </Button>
          <Button onClick={() => setIsDialogOpen(true)} className="bg-blue-900">
            <Plus className="w-4 h-4 mr-2" />
            Create Automation
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Automations</p>
                <p className="text-2xl font-bold">{automations.length}</p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Zap className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active</p>
                <p className="text-2xl font-bold">{automations.filter(a => a.status === 'active').length}</p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Play className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Runs</p>
                <p className="text-2xl font-bold">{automations.reduce((sum, a) => sum + a.runCount, 0)}</p>
              </div>
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {automations.map((automation) => (
          <Card key={automation.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white">
                    {getTriggerIcon(automation.trigger.type)}
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{automation.name}</h3>
                    <p className="text-gray-500 text-sm">{automation.description}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <Badge className={getStatusColor(automation.status)}>
                        {automation.status}
                      </Badge>
                      <span className="text-sm text-gray-500">
                        Trigger: {automation.trigger.type}
                      </span>
                      <span className="text-sm text-gray-500">
                        Runs: {automation.runCount}
                      </span>
                      {automation.lastRun && (
                        <span className="text-sm text-gray-500">
                          Last run: {new Date(automation.lastRun).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-sm text-gray-500">Actions:</span>
                      {automation.actions.map((action, i) => (
                        <div key={i} className="flex items-center gap-1 text-sm">
                          {getActionIcon(action.type)}
                          <span>{action.type.replace('_', ' ')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={automation.status === 'active'}
                    onCheckedChange={() => handleToggleStatus(automation)}
                  />
                  <Button variant="ghost" size="sm" onClick={() => { setEditingAutomation(automation); setFormData(automation); setIsDialogOpen(true); }}>
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete(automation.id)}>
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {automations.length === 0 && (
        <Card className="p-8 text-center">
          <Zap className="w-12 h-12 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600">No automations yet</h3>
          <p className="text-gray-500 mb-4">Create your first automation workflow to save time</p>
          <Button onClick={() => setIsTemplateDialogOpen(true)} className="bg-blue-900">
            <Plus className="w-4 h-4 mr-2" />
            Create from Template
          </Button>
        </Card>
      )}

      {/* Template Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Choose a Template</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4">
            {automationTemplates.map((template, index) => (
              <Card key={index} className="cursor-pointer hover:border-blue-500 transition-colors" onClick={() => applyTemplate(template)}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Zap className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{template.name}</h4>
                      <p className="text-sm text-gray-500">{template.description}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline">{template.trigger.type}</Badge>
                        <span className="text-xs text-gray-500">{template.actions.length} actions</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Create/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingAutomation ? 'Edit Automation' : 'Create Automation'}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label>Name *</Label>
              <Input value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Trigger Type</Label>
              <Select value={formData.trigger?.type} onValueChange={(v) => setFormData({...formData, trigger: { ...formData.trigger, type: v as any }})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="event">Event Based</SelectItem>
                  <SelectItem value="schedule">Scheduled</SelectItem>
                  <SelectItem value="condition">Condition Based</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v as any})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
              <Button type="submit" className="bg-blue-900">{editingAutomation ? 'Update' : 'Create'} Automation</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
