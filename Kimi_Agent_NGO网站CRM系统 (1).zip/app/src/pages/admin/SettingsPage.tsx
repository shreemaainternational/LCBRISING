import { useState, useEffect } from 'react';
import { Save, Building, Bell, Shield, Mail, Globe, Key } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { clubInfoDB } from '@/lib/database';
import type { LionsClubInfo } from '@/types/database';

export default function SettingsPage() {
  const [clubInfo, setClubInfo] = useState<LionsClubInfo | null>(null);

  useEffect(() => {
    const info = clubInfoDB.get();
    if (info) {
      setClubInfo(info);
    }
  }, []);

  const handleSave = () => {
    if (clubInfo) {
      clubInfoDB.set(clubInfo);
      toast.success('Settings saved successfully');
    }
  };

  if (!clubInfo) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Settings</h2>
          <p className="text-gray-500">Manage your club settings and preferences</p>
        </div>
        <Button onClick={handleSave} className="bg-blue-900">
          <Save className="w-4 h-4 mr-2" />
          Save Changes
        </Button>
      </div>

      <Tabs defaultValue="club" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto">
          <TabsTrigger value="club">Club Info</TabsTrigger>
          <TabsTrigger value="contact">Contact</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="club" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="w-5 h-5 mr-2" />
                Club Information
              </CardTitle>
              <CardDescription>Basic information about your Lions Club</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Club Name</Label>
                  <Input 
                    value={clubInfo.clubName} 
                    onChange={(e) => setClubInfo({...clubInfo, clubName: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Club Number</Label>
                  <Input 
                    value={clubInfo.clubNumber} 
                    onChange={(e) => setClubInfo({...clubInfo, clubNumber: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>District</Label>
                  <Input 
                    value={clubInfo.district} 
                    onChange={(e) => setClubInfo({...clubInfo, district: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Region</Label>
                  <Input 
                    value={clubInfo.region} 
                    onChange={(e) => setClubInfo({...clubInfo, region: e.target.value})}
                  />
                  <p className="text-xs text-amber-600">* Changes from 1st July every year</p>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Zone</Label>
                  <Input 
                    value={clubInfo.zone} 
                    onChange={(e) => setClubInfo({...clubInfo, zone: e.target.value})}
                  />
                  <p className="text-xs text-amber-600">* Changes from 1st July every year</p>
                </div>
                <div className="space-y-2">
                  <Label>Charter Date</Label>
                  <Input 
                    type="date"
                    value={clubInfo.charterDate} 
                    onChange={(e) => setClubInfo({...clubInfo, charterDate: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                Meeting Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Meeting Venue</Label>
                <Input 
                  value={clubInfo.meetingVenue} 
                  onChange={(e) => setClubInfo({...clubInfo, meetingVenue: e.target.value})}
                />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Meeting Day</Label>
                  <Input 
                    value={clubInfo.meetingDay} 
                    onChange={(e) => setClubInfo({...clubInfo, meetingDay: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Meeting Time</Label>
                  <Input 
                    value={clubInfo.meetingTime} 
                    onChange={(e) => setClubInfo({...clubInfo, meetingTime: e.target.value})}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2" />
                Contact Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input 
                    type="email"
                    value={clubInfo.email} 
                    onChange={(e) => setClubInfo({...clubInfo, email: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone</Label>
                  <Input 
                    value={clubInfo.phone} 
                    onChange={(e) => setClubInfo({...clubInfo, phone: e.target.value})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input 
                  value={clubInfo.website} 
                  onChange={(e) => setClubInfo({...clubInfo, website: e.target.value})}
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                Social Media
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Facebook</Label>
                <Input 
                  value={clubInfo.socialMedia?.facebook || ''} 
                  onChange={(e) => setClubInfo({...clubInfo, socialMedia: {...clubInfo.socialMedia, facebook: e.target.value}})}
                  placeholder="https://facebook.com/..."
                />
              </div>
              <div className="space-y-2">
                <Label>Instagram</Label>
                <Input 
                  value={clubInfo.socialMedia?.instagram || ''} 
                  onChange={(e) => setClubInfo({...clubInfo, socialMedia: {...clubInfo.socialMedia, instagram: e.target.value}})}
                  placeholder="https://instagram.com/..."
                />
              </div>
              <div className="space-y-2">
                <Label>LinkedIn</Label>
                <Input 
                  value={clubInfo.socialMedia?.linkedin || ''} 
                  onChange={(e) => setClubInfo({...clubInfo, socialMedia: {...clubInfo.socialMedia, linkedin: e.target.value}})}
                  placeholder="https://linkedin.com/..."
                />
              </div>
              <div className="space-y-2">
                <Label>YouTube</Label>
                <Input 
                  value={clubInfo.socialMedia?.youtube || ''} 
                  onChange={(e) => setClubInfo({...clubInfo, socialMedia: {...clubInfo.socialMedia, youtube: e.target.value}})}
                  placeholder="https://youtube.com/..."
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">New Member Notifications</p>
                  <p className="text-sm text-gray-500">Get notified when a new member joins</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Donation Alerts</p>
                  <p className="text-sm text-gray-500">Get notified for new donations</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Event Reminders</p>
                  <p className="text-sm text-gray-500">Get reminders before events</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Birthday Wishes</p>
                  <p className="text-sm text-gray-500">Send automatic birthday wishes</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Security Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Two-Factor Authentication</p>
                  <p className="text-sm text-gray-500">Require 2FA for admin access</p>
                </div>
                <Switch />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Audit Logging</p>
                  <p className="text-sm text-gray-500">Log all admin actions</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">Session Timeout</p>
                  <p className="text-sm text-gray-500">Auto logout after 30 minutes</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Key className="w-5 h-5 mr-2" />
                Change Password
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Current Password</Label>
                <Input type="password" />
              </div>
              <div className="space-y-2">
                <Label>New Password</Label>
                <Input type="password" />
              </div>
              <div className="space-y-2">
                <Label>Confirm New Password</Label>
                <Input type="password" />
              </div>
              <Button variant="outline" onClick={() => toast.success('Password updated')}>
                Update Password
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
