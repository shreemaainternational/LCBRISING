import { useState, useEffect } from 'react';
import { Send, Mail, MessageSquare, Phone, Plus, CheckCircle, XCircle, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { db, generateId } from '@/lib/database';
import type { Communication, MessageTemplate } from '@/types/database';

const defaultTemplates = [
  { name: 'Welcome Email', type: 'email', subject: 'Welcome to Lions Club!', content: 'Dear {{name}},\n\nWelcome to Lions Club of Baroda Rising Star!' },
  { name: 'Thank You', type: 'email', subject: 'Thank You for Your Support', content: 'Dear {{name}},\n\nThank you for your generous donation of ₹{{amount}}.' },
  { name: 'Event Invitation', type: 'email', subject: 'You\'re Invited!', content: 'Dear {{name}},\n\nYou are invited to our upcoming event.' },
  { name: 'Birthday Wishes', type: 'whatsapp', content: 'Happy Birthday {{name}}! Wishing you a wonderful year ahead.' },
  { name: 'Meeting Reminder', type: 'sms', content: 'Reminder: Lions Club meeting tomorrow at 7 PM. Venue: {{venue}}' },
];

export default function CommunicationsPage() {
  const [communications, setCommunications] = useState<Communication[]>([]);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [activeTab, setActiveTab] = useState('compose');
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);
  
  // Compose form state
  const [recipientType, setRecipientType] = useState<'member' | 'donor' | 'volunteer'>('member');
  const [communicationType, setCommunicationType] = useState<'email' | 'sms' | 'whatsapp'>('email');
  const [recipients, setRecipients] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');

  useEffect(() => {
    loadData();
    seedTemplates();
  }, []);

  const loadData = () => {
    setCommunications(db.communications.getAll());
    setTemplates(db.templates.getAll());
  };

  const seedTemplates = () => {
    const existing = db.templates.getAll();
    if (existing.length === 0) {
      defaultTemplates.forEach(t => {
        db.templates.create({
          id: generateId(),
          name: t.name,
          type: t.type as any,
          subject: t.subject,
          content: t.content,
          variables: ['name', 'amount', 'venue'],
          category: 'Default',
          usageCount: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
      });
      loadData();
    }
  };

  const handleSend = () => {
    if (!message.trim()) {
      toast.error('Please enter a message');
      return;
    }

    const recipientList = recipients.split(',').map(r => r.trim()).filter(r => r);
    
    recipientList.forEach(recipientId => {
      const communication: Communication = {
        id: generateId(),
        type: communicationType,
        recipientId,
        recipientType,
        subject: communicationType === 'email' ? subject : undefined,
        content: message,
        status: 'sent',
        sentAt: new Date().toISOString(),
        createdAt: new Date().toISOString()
      };
      db.communications.create(communication);
    });

    toast.success(`Message sent to ${recipientList.length} recipients`);
    setMessage('');
    setSubject('');
    loadData();
  };

  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setSelectedTemplate(templateId);
      setCommunicationType(template.type);
      if (template.subject) setSubject(template.subject);
      setMessage(template.content);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'failed': return <XCircle className="w-4 h-4 text-red-500" />;
      case 'queued': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email': return <Mail className="w-4 h-4" />;
      case 'sms': return <MessageSquare className="w-4 h-4" />;
      case 'whatsapp': return <Phone className="w-4 h-4 text-green-500" />;
      default: return <Mail className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Communications</h2>
          <p className="text-gray-500">Send emails, SMS, and WhatsApp messages</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 lg:w-auto">
          <TabsTrigger value="compose">Compose</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="compose" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Compose Message</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Recipient Type</Label>
                    <Select value={recipientType} onValueChange={(v) => setRecipientType(v as any)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="member">Members</SelectItem>
                        <SelectItem value="donor">Donors</SelectItem>
                        <SelectItem value="volunteer">Volunteers</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Communication Type</Label>
                    <Select value={communicationType} onValueChange={(v) => setCommunicationType(v as any)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="email">Email</SelectItem>
                        <SelectItem value="sms">SMS</SelectItem>
                        <SelectItem value="whatsapp">WhatsApp</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Use Template</Label>
                  <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a template (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">None</SelectItem>
                      {templates.map(t => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Recipients (comma-separated IDs)</Label>
                  <Input 
                    placeholder="Enter recipient IDs separated by commas"
                    value={recipients}
                    onChange={(e) => setRecipients(e.target.value)}
                  />
                </div>

                {communicationType === 'email' && (
                  <div className="space-y-2">
                    <Label>Subject</Label>
                    <Input 
                      placeholder="Enter email subject"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Message</Label>
                  <Textarea 
                    placeholder="Enter your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    rows={8}
                  />
                  <p className="text-xs text-gray-500">
                    Use {'{{name}}'}, {'{{amount}}'}, {'{{venue}}'} as variables
                  </p>
                </div>

                <Button onClick={handleSend} className="w-full bg-blue-900">
                  <Send className="w-4 h-4 mr-2" />
                  Send Message
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center">
                    <Mail className="w-5 h-5 text-blue-600 mr-2" />
                    <span>Emails Sent</span>
                  </div>
                  <span className="font-bold">{communications.filter(c => c.type === 'email').length}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center">
                    <MessageSquare className="w-5 h-5 text-green-600 mr-2" />
                    <span>SMS Sent</span>
                  </div>
                  <span className="font-bold">{communications.filter(c => c.type === 'sms').length}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div className="flex items-center">
                    <Phone className="w-5 h-5 text-purple-600 mr-2" />
                    <span>WhatsApp Sent</span>
                  </div>
                  <span className="font-bold">{communications.filter(c => c.type === 'whatsapp').length}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Message Templates</h3>
            <Button onClick={() => setIsTemplateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Add Template
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((template) => (
              <Card key={template.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        {template.type === 'email' ? <Mail className="w-5 h-5 text-blue-600" /> :
                         template.type === 'sms' ? <MessageSquare className="w-5 h-5 text-green-600" /> :
                         <Phone className="w-5 h-5 text-purple-600" />}
                      </div>
                      <div>
                        <h4 className="font-semibold">{template.name}</h4>
                        <p className="text-sm text-gray-500">{template.subject}</p>
                        <p className="text-xs text-gray-400 mt-1 line-clamp-2">{template.content}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge variant="outline">{template.type}</Badge>
                          <span className="text-xs text-gray-500">Used {template.usageCount} times</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Recipient</TableHead>
                    <TableHead>Subject/Preview</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Sent At</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {communications.slice().reverse().map((comm) => (
                    <TableRow key={comm.id}>
                      <TableCell>{getTypeIcon(comm.type)}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{comm.recipientType}</Badge>
                      </TableCell>
                      <TableCell>
                        <p className="truncate max-w-xs">{comm.subject || comm.content.substring(0, 50)}...</p>
                      </TableCell>
                      <TableCell>{getStatusIcon(comm.status)}</TableCell>
                      <TableCell>{comm.sentAt ? new Date(comm.sentAt).toLocaleString() : '-'}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Template</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Template Name</Label>
              <Input placeholder="Enter template name" />
            </div>
            <div className="space-y-2">
              <Label>Type</Label>
              <Select>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="email">Email</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                  <SelectItem value="whatsapp">WhatsApp</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)}>Cancel</Button>
              <Button className="bg-blue-900" onClick={() => { toast.success('Template added'); setIsTemplateDialogOpen(false); }}>Add Template</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
