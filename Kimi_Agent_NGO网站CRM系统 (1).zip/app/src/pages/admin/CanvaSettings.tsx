import { useState, useEffect } from 'react';
import { Palette, Save, RefreshCw, Plus, Trash2, Edit2 } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { canvaConfigDB, initializeCanva } from '@/lib/canvaService';
import { defaultCanvaConfig } from '@/types/canvaConfig';
import type { CanvaConfig, CanvaTemplate } from '@/types/canvaConfig';

export default function CanvaSettings() {
  const [config, setConfig] = useState<CanvaConfig>(defaultCanvaConfig);
  const [isDirty, setIsDirty] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<CanvaTemplate | null>(null);
  const [isTemplateDialogOpen, setIsTemplateDialogOpen] = useState(false);

  useEffect(() => {
    const savedConfig = canvaConfigDB.get();
    setConfig(savedConfig);
  }, []);

  const handleSave = () => {
    canvaConfigDB.set(config);
    initializeCanva();
    setIsDirty(false);
    toast.success('Canva configuration saved successfully!');
  };

  const handleReset = () => {
    if (confirm('Are you sure you want to reset to default configuration?')) {
      canvaConfigDB.reset();
      setConfig(canvaConfigDB.get());
      setIsDirty(false);
      toast.success('Configuration reset to defaults');
    }
  };

  const updateFeature = (feature: keyof typeof config.features, value: boolean) => {
    setConfig(prev => ({
      ...prev,
      features: { ...prev.features, [feature]: value }
    }));
    setIsDirty(true);
  };

  const updateExportSetting = (setting: keyof typeof config.exportSettings, value: any) => {
    setConfig(prev => ({
      ...prev,
      exportSettings: { ...prev.exportSettings, [setting]: value }
    }));
    setIsDirty(true);
  };

  const updateBrandColor = (color: string, value: string) => {
    setConfig(prev => ({
      ...prev,
      brandKit: {
        ...prev.brandKit!,
        colors: { ...prev.brandKit!.colors, [color]: value }
      }
    }));
    setIsDirty(true);
  };

  const addTemplate = () => {
    const newTemplate: CanvaTemplate = {
      id: `template-${Date.now()}`,
      name: 'New Template',
      description: 'Template description',
      category: 'custom',
      thumbnailUrl: '/templates/default.jpg',
      defaultDimensions: { width: 1080, height: 1080, unit: 'px' },
      editableElements: ['title', 'description']
    };
    setEditingTemplate(newTemplate);
    setIsTemplateDialogOpen(true);
  };

  const editTemplate = (template: CanvaTemplate) => {
    setEditingTemplate({ ...template });
    setIsTemplateDialogOpen(true);
  };

  const saveTemplate = () => {
    if (!editingTemplate) return;
    
    const existingIndex = config.templates.findIndex(t => t.id === editingTemplate.id);
    let newTemplates;
    
    if (existingIndex >= 0) {
      newTemplates = [...config.templates];
      newTemplates[existingIndex] = editingTemplate;
    } else {
      newTemplates = [...config.templates, editingTemplate];
    }
    
    setConfig(prev => ({ ...prev, templates: newTemplates }));
    setIsDirty(true);
    setIsTemplateDialogOpen(false);
    setEditingTemplate(null);
    toast.success('Template saved');
  };

  const deleteTemplate = (templateId: string) => {
    if (confirm('Are you sure you want to delete this template?')) {
      setConfig(prev => ({
        ...prev,
        templates: prev.templates.filter(t => t.id !== templateId)
      }));
      setIsDirty(true);
      toast.success('Template deleted');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Palette className="w-6 h-6 text-blue-600" />
            Canva Integration Settings
          </h1>
          <p className="text-gray-500">Configure Canva design tools for your club</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleReset}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button 
            onClick={handleSave} 
            disabled={!isDirty}
            className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 font-bold"
          >
            <Save className="w-4 h-4 mr-2" />
            Save Changes
          </Button>
        </div>
      </div>

      {/* Enable Toggle */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-lg">Enable Canva Integration</h3>
              <p className="text-gray-500">Allow users to create designs using Canva templates</p>
            </div>
            <Switch 
              checked={config.enabled}
              onCheckedChange={(checked) => {
                setConfig(prev => ({ ...prev, enabled: checked }));
                setIsDirty(true);
              }}
            />
          </div>
        </CardContent>
      </Card>

      {config.enabled && (
        <Tabs defaultValue="features" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4 lg:w-auto">
            <TabsTrigger value="features">Features</TabsTrigger>
            <TabsTrigger value="templates">Templates</TabsTrigger>
            <TabsTrigger value="brand">Brand Kit</TabsTrigger>
            <TabsTrigger value="export">Export</TabsTrigger>
          </TabsList>

          {/* Features Tab */}
          <TabsContent value="features" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Feature Toggles</CardTitle>
                <CardDescription>Enable or disable specific Canva features</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(config.features).map(([feature, enabled]) => (
                  <div key={feature} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{feature.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}</p>
                      <p className="text-sm text-gray-500">
                        {feature === 'enableDesignButton' && 'Show design button on entities'}
                        {feature === 'enableTemplates' && 'Allow users to choose from templates'}
                        {feature === 'enableBrandKit' && 'Apply brand colors and fonts'}
                        {feature === 'enableCollaboration' && 'Allow multiple users to edit'}
                        {feature === 'enableComments' && 'Enable commenting on designs'}
                        {feature === 'enableVersionHistory' && 'Track design versions'}
                      </p>
                    </div>
                    <Switch 
                      checked={enabled}
                      onCheckedChange={(checked) => updateFeature(feature as any, checked)}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Templates Tab */}
          <TabsContent value="templates" className="space-y-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Design Templates</CardTitle>
                  <CardDescription>Templates available for users to create designs</CardDescription>
                </div>
                <Button onClick={addTemplate}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Template
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {config.templates.map(template => (
                    <div key={template.id} className="border rounded-lg p-4 hover:border-blue-400 transition-colors">
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{template.name}</p>
                            <Badge variant="outline">{template.category}</Badge>
                          </div>
                          <p className="text-sm text-gray-500 mt-1">{template.description}</p>
                          <p className="text-xs text-gray-400 mt-2">
                            {template.defaultDimensions.width}×{template.defaultDimensions.height}{template.defaultDimensions.unit}
                            {' • '}
                            {template.editableElements.length} editable elements
                          </p>
                        </div>
                        <div className="flex gap-1">
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8"
                            onClick={() => editTemplate(template)}
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button 
                            size="icon" 
                            variant="ghost" 
                            className="h-8 w-8 text-red-500"
                            onClick={() => deleteTemplate(template.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Brand Kit Tab */}
          <TabsContent value="brand" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Brand Kit</CardTitle>
                <CardDescription>Your club's brand colors and fonts for consistent designs</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Colors */}
                <div>
                  <h4 className="font-medium mb-3">Brand Colors</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {Object.entries(config.brandKit?.colors || {}).map(([name, color]) => (
                      <div key={name} className="space-y-2">
                        <Label className="capitalize">{name}</Label>
                        <div className="flex gap-2">
                          <input 
                            type="color" 
                            value={color}
                            onChange={(e) => updateBrandColor(name as any, e.target.value)}
                            className="w-10 h-10 rounded cursor-pointer"
                          />
                          <Input 
                            value={color}
                            onChange={(e) => updateBrandColor(name as any, e.target.value)}
                            className="flex-1 font-mono"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Fonts */}
                <div>
                  <h4 className="font-medium mb-3">Brand Fonts</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {Object.entries(config.brandKit?.fonts || {}).map(([name, font]) => (
                      <div key={name} className="space-y-2">
                        <Label className="capitalize">{name} Font</Label>
                        <Input 
                          value={font}
                          onChange={(e) => {
                            setConfig(prev => ({
                              ...prev,
                              brandKit: {
                                ...prev.brandKit!,
                                fonts: { ...prev.brandKit!.fonts, [name]: e.target.value }
                              }
                            }));
                            setIsDirty(true);
                          }}
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Logos */}
                <div>
                  <h4 className="font-medium mb-3">Brand Logos</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {Object.entries(config.brandKit?.logos || {}).map(([name, url]) => (
                      <div key={name} className="space-y-2">
                        <Label className="capitalize">{name} Logo URL</Label>
                        <Input 
                          value={url}
                          onChange={(e) => {
                            setConfig(prev => ({
                              ...prev,
                              brandKit: {
                                ...prev.brandKit!,
                                logos: { ...prev.brandKit!.logos, [name]: e.target.value }
                              }
                            }));
                            setIsDirty(true);
                          }}
                          placeholder="/logo.png"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Export Tab */}
          <TabsContent value="export" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Export Settings</CardTitle>
                <CardDescription>Configure default export options for designs</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Default Format</Label>
                    <select 
                      className="w-full p-2 border rounded-md"
                      value={config.exportSettings.defaultFormat}
                      onChange={(e) => updateExportSetting('defaultFormat', e.target.value)}
                    >
                      <option value="png">PNG</option>
                      <option value="jpg">JPG</option>
                      <option value="pdf">PDF</option>
                      <option value="mp4">MP4 (Video)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Default Quality</Label>
                    <select 
                      className="w-full p-2 border rounded-md"
                      value={config.exportSettings.defaultQuality}
                      onChange={(e) => updateExportSetting('defaultQuality', e.target.value)}
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Allow Multiple Formats</p>
                      <p className="text-sm text-gray-500">Users can export in multiple formats</p>
                    </div>
                    <Switch 
                      checked={config.exportSettings.allowMultipleFormats}
                      onCheckedChange={(checked) => updateExportSetting('allowMultipleFormats', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Auto Download</p>
                      <p className="text-sm text-gray-500">Automatically download exported files</p>
                    </div>
                    <Switch 
                      checked={config.exportSettings.autoDownload}
                      onCheckedChange={(checked) => updateExportSetting('autoDownload', checked)}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Save to CRM</p>
                      <p className="text-sm text-gray-500">Save exported files to the CRM system</p>
                    </div>
                    <Switch 
                      checked={config.exportSettings.saveToCRM}
                      onCheckedChange={(checked) => updateExportSetting('saveToCRM', checked)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* Template Edit Dialog */}
      <Dialog open={isTemplateDialogOpen} onOpenChange={setIsTemplateDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingTemplate?.id.includes('template-') ? 'Add' : 'Edit'} Template</DialogTitle>
          </DialogHeader>
          {editingTemplate && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input 
                  value={editingTemplate.name}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, name: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Description</Label>
                <Input 
                  value={editingTemplate.description}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, description: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <select 
                  className="w-full p-2 border rounded-md"
                  value={editingTemplate.category}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, category: e.target.value as any })}
                >
                  <option value="social">Social Media</option>
                  <option value="poster">Poster</option>
                  <option value="flyer">Flyer</option>
                  <option value="banner">Banner</option>
                  <option value="presentation">Presentation</option>
                  <option value="custom">Custom</option>
                </select>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="space-y-2">
                  <Label>Width</Label>
                  <Input 
                    type="number"
                    value={editingTemplate.defaultDimensions.width}
                    onChange={(e) => setEditingTemplate({ 
                      ...editingTemplate, 
                      defaultDimensions: { 
                        ...editingTemplate.defaultDimensions, 
                        width: parseInt(e.target.value) 
                      } 
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Height</Label>
                  <Input 
                    type="number"
                    value={editingTemplate.defaultDimensions.height}
                    onChange={(e) => setEditingTemplate({ 
                      ...editingTemplate, 
                      defaultDimensions: { 
                        ...editingTemplate.defaultDimensions, 
                        height: parseInt(e.target.value) 
                      } 
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Unit</Label>
                  <select 
                    className="w-full p-2 border rounded-md"
                    value={editingTemplate.defaultDimensions.unit}
                    onChange={(e) => setEditingTemplate({ 
                      ...editingTemplate, 
                      defaultDimensions: { 
                        ...editingTemplate.defaultDimensions, 
                        unit: e.target.value as any 
                      } 
                    })}
                  >
                    <option value="px">px</option>
                    <option value="in">in</option>
                    <option value="mm">mm</option>
                  </select>
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsTemplateDialogOpen(false)}>Cancel</Button>
            <Button onClick={saveTemplate}>Save Template</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
