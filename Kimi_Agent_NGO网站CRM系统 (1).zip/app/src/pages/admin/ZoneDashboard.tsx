import { useState, useEffect } from 'react';
import { 
  Building2, Users, Calendar, TrendingUp, AlertTriangle, 
  CheckCircle, FileText, Bell, Award, MapPin, ChevronRight,
  BarChart3, PieChart, Activity, Download, Send
} from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  getZoneDashboardStats, 
  zoneDB, 
  clubDB, 
  advisoryDB, 
  notificationDB,
  seedZoneData 
} from '@/lib/zoneDatabase';
import { generateId } from '@/lib/database';
import type { ZoneDashboardStats, Club, ZoneAlert, Advisory } from '@/types/zoneDatabase';

export default function ZoneDashboard() {
  const [stats, setStats] = useState<ZoneDashboardStats | null>(null);
  const [clubs, setClubs] = useState<Club[]>([]);
  const [alerts, setAlerts] = useState<ZoneAlert[]>([]);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [zone, setZone] = useState<any>(null);

  useEffect(() => {
    // Seed data if needed
    seedZoneData();
    
    // Load data
    const zones = zoneDB.getAll();
    if (zones.length > 0) {
      setZone(zones[0]);
      const zoneStats = getZoneDashboardStats(zones[0].id);
      setStats(zoneStats);
      setAlerts(zoneStats.alerts);
      
      const zoneClubs = clubDB.getByZone(zones[0].id);
      setClubs(zoneClubs);
      
      // Load notifications
      const notifs = notificationDB.getUnread('zone-chairperson');
      setNotifications(notifs);
    }
  }, []);

  const handleSendAdvisory = (clubId: string, type: string) => {
    const advisory: Advisory = {
      id: generateId(),
      type: type as any,
      priority: 'High',
      targetType: 'Club',
      targetId: clubId,
      subject: `Advisory: ${type}`,
      message: `Your club needs attention on ${type}. Please review and take necessary action.`,
      recommendations: [
        'Schedule a board meeting to discuss',
        'Create an action plan',
        'Report progress within 2 weeks'
      ],
      status: 'Sent',
      sentAt: new Date().toISOString(),
      createdBy: 'zone-chairperson',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    advisoryDB.create(advisory);
    toast.success('Advisory sent successfully!');
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'Warning': return 'bg-amber-100 text-amber-800 border-amber-200';
      default: return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  if (!stats || !zone) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Zone Chairperson Dashboard</h1>
          <p className="text-gray-500 flex items-center gap-2 mt-1">
            <MapPin className="w-4 h-4" />
            {zone.zoneName} • District {zone.districtId} • Region {zone.regionId}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="relative">
            <Bell className="w-4 h-4 mr-2" />
            Notifications
            {notifications.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                {notifications.length}
              </span>
            )}
          </Button>
          <Button className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 font-bold">
            <Download className="w-4 h-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Clubs</p>
                <p className="text-2xl font-bold">{stats.totalClubs}</p>
              </div>
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Building2 className="w-5 h-5 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Members</p>
                <p className="text-2xl font-bold">{stats.totalMembers}</p>
              </div>
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <Users className="w-5 h-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Activities</p>
                <p className="text-2xl font-bold">{stats.totalServiceActivities}</p>
              </div>
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <Calendar className="w-5 h-5 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Volunteer Hrs</p>
                <p className="text-2xl font-bold">{stats.totalVolunteerHours}</p>
              </div>
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                <Activity className="w-5 h-5 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Funds Raised</p>
                <p className="text-2xl font-bold">₹{(stats.totalFundsRaised / 100000).toFixed(1)}L</p>
              </div>
              <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Beneficiaries</p>
                <p className="text-2xl font-bold">{stats.totalBeneficiaries.toLocaleString()}</p>
              </div>
              <div className="w-10 h-10 bg-pink-100 rounded-full flex items-center justify-center">
                <Award className="w-5 h-5 text-pink-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 lg:w-auto">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="clubs">Clubs</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="advisories">Advisories</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Club Rankings */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2" />
                  Club Performance Rankings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stats.clubRankings.map((club, index) => (
                    <div key={club.clubId} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${
                        index === 0 ? 'bg-yellow-400 text-blue-900' :
                        index === 1 ? 'bg-gray-300 text-gray-700' :
                        index === 2 ? 'bg-amber-600 text-white' :
                        'bg-gray-200 text-gray-600'
                      }`}>
                        {club.rank}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium">{club.clubName}</p>
                        <p className="text-sm text-gray-500">Club #{club.clubNumber}</p>
                      </div>
                      <div className="flex gap-4 text-sm">
                        <div className="text-center">
                          <p className="font-bold">{club.metrics.attendance}%</p>
                          <p className="text-xs text-gray-500">Attendance</p>
                        </div>
                        <div className="text-center">
                          <p className="font-bold">{club.metrics.membership}</p>
                          <p className="text-xs text-gray-500">Members</p>
                        </div>
                        <div className="text-center">
                          <p className="font-bold">{club.metrics.service}</p>
                          <p className="text-xs text-gray-500">Activities</p>
                        </div>
                        <div className="text-center">
                          <p className="font-bold text-blue-600">{club.score}</p>
                          <p className="text-xs text-gray-500">Score</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Alerts & Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2" />
                  Alerts & Actions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px]">
                  <div className="space-y-3">
                    {alerts.length === 0 ? (
                      <div className="text-center py-8 text-gray-500">
                        <CheckCircle className="w-12 h-12 mx-auto mb-2 text-green-500" />
                        <p>No alerts at this time</p>
                      </div>
                    ) : (
                      alerts.map(alert => (
                        <div key={alert.id} className={`p-3 rounded-lg border ${getSeverityColor(alert.severity)}`}>
                          <div className="flex items-start gap-2">
                            <AlertTriangle className="w-4 h-4 mt-0.5" />
                            <div className="flex-1">
                              <p className="font-medium text-sm">{alert.clubName}</p>
                              <p className="text-sm">{alert.message}</p>
                              <p className="text-xs mt-1 opacity-75">Action: {alert.actionRequired}</p>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                className="mt-2 h-7 text-xs"
                                onClick={() => handleSendAdvisory(alert.clubId!, alert.type)}
                              >
                                <Send className="w-3 h-3 mr-1" />
                                Send Advisory
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>

                <div className="mt-4 pt-4 border-t space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Pending Reports</span>
                    <Badge variant="secondary">{stats.pendingReports}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Pending Advisories</span>
                    <Badge variant="secondary">{stats.pendingAdvisories}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Pending Approvals</span>
                    <Badge variant="secondary">{stats.pendingApprovals}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Clubs Tab */}
        <TabsContent value="clubs" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {clubs.map(club => (
              <Card key={club.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{club.clubName}</CardTitle>
                      <CardDescription>Club #{club.clubNumber}</CardDescription>
                    </div>
                    <Avatar className="w-12 h-12 bg-blue-100">
                      <AvatarFallback className="bg-blue-900 text-white text-sm">
                        {club.clubName.split(' ').map(n => n[0]).join('').substring(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <p className="text-2xl font-bold">{club.stats.totalMembers}</p>
                      <p className="text-xs text-gray-500">Members</p>
                    </div>
                    <div className="text-center p-2 bg-gray-50 rounded">
                      <p className="text-2xl font-bold">{club.stats.serviceActivities}</p>
                      <p className="text-xs text-gray-500">Activities</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Attendance</span>
                      <span className="font-medium">{Math.round((club.stats.activeMembers / club.stats.totalMembers) * 100)}%</span>
                    </div>
                    <Progress value={(club.stats.activeMembers / club.stats.totalMembers) * 100} className="h-2" />
                  </div>
                  
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <FileText className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <Send className="w-4 h-4 mr-1" />
                      Advisory
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Attendance Tab */}
        <TabsContent value="attendance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Zone Attendance Overview</CardTitle>
              <CardDescription>Average attendance across all clubs: {stats.averageAttendance}%</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-green-50 rounded-lg text-center">
                  <p className="text-3xl font-bold text-green-600">{stats.averageAttendance}%</p>
                  <p className="text-sm text-green-700">Average Attendance</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg text-center">
                  <p className="text-3xl font-bold text-blue-600">{clubs.length * 4}</p>
                  <p className="text-sm text-blue-700">Meetings This Month</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg text-center">
                  <p className="text-3xl font-bold text-purple-600">{stats.pendingApprovals}</p>
                  <p className="text-sm text-purple-700">Pending Review</p>
                </div>
              </div>
              
              <div className="text-center py-8 text-gray-500">
                <BarChart3 className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>Detailed attendance charts coming soon</p>
                <p className="text-sm">Track meeting attendance, trends, and club comparisons</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Advisories Tab */}
        <TabsContent value="advisories" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Zone Advisories</CardTitle>
                <CardDescription>Send and track advisories to clubs</CardDescription>
              </div>
              <Button className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 font-bold">
                <Send className="w-4 h-4 mr-2" />
                New Advisory
              </Button>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <FileText className="w-16 h-16 mx-auto mb-4 opacity-50" />
                <p>No advisories sent yet</p>
                <p className="text-sm">Create advisories for attendance, membership, or compliance issues</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Automated Reports</CardTitle>
                <CardDescription>Generate reports for Lions Portal</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {[
                  { name: 'Monthly Club Report', status: 'Ready', icon: FileText },
                  { name: 'Quarterly Zone Report', status: 'Pending', icon: PieChart },
                  { name: 'Annual Report', status: 'Pending', icon: BarChart3 },
                  { name: 'Social Impact Report', status: 'Ready', icon: Award },
                ].map((report, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <report.icon className="w-5 h-5 text-blue-600" />
                      <span className="font-medium">{report.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={report.status === 'Ready' ? 'default' : 'secondary'}>
                        {report.status}
                      </Badge>
                      <Button size="sm" variant="ghost">
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lions Portal Submission</CardTitle>
                <CardDescription>Ready for submission to Lions International</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="font-medium text-green-800">Ready for Submission</span>
                  </div>
                  <p className="text-sm text-green-700">
                    All required data is collected and formatted for Lions Portal.
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Member Data</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Service Activities</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Attendance Records</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Financial Summary</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                </div>
                
                <Button className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 font-bold">
                  <Download className="w-4 h-4 mr-2" />
                  Download CSV for Lions Portal
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
