import { useState, useEffect } from 'react';
import { 
  Users, Heart, TrendingUp, Calendar, Briefcase, 
  AlertTriangle, Sparkles, ArrowUpRight, ArrowDownRight,
  Target, Zap, MessageCircle
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from 'recharts';
import { getDashboardStats } from '@/lib/database';
import type { DashboardStats, AIRecommendation } from '@/types/database';

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = () => {
      const dashboardStats = getDashboardStats();
      setStats(dashboardStats);
      setRecommendations(dashboardStats.recommendedActions);
      setLoading(false);
    };
    loadData();
  }, []);

  const statCards = [
    { 
      icon: Users, 
      label: 'Total Members', 
      value: stats?.totalMembers || 0, 
      change: '+12%',
      trend: 'up',
      color: 'bg-blue-500',
      lightColor: 'bg-blue-50'
    },
    { 
      icon: Heart, 
      label: 'Total Donations', 
      value: `₹${((stats?.totalDonations || 0) / 100000).toFixed(1)}L`, 
      change: '+23%',
      trend: 'up',
      color: 'bg-green-500',
      lightColor: 'bg-green-50'
    },
    { 
      icon: Briefcase, 
      label: 'Active Service Activities', 
      value: stats?.activeProjects || 0, 
      change: '+5%',
      trend: 'up',
      color: 'bg-yellow-500',
      lightColor: 'bg-yellow-50'
    },
    { 
      icon: Calendar, 
      label: 'Upcoming Events', 
      value: stats?.upcomingEvents || 0, 
      change: '+8%',
      trend: 'up',
      color: 'bg-purple-500',
      lightColor: 'bg-purple-50'
    },
  ];

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

  const pieData = stats?.donationByCategory?.map(item => ({
    name: item.category,
    value: item.amount
  })) || [];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-900" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* AI Insights Banner */}
      {recommendations.length > 0 && (
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 text-white shadow-xl">
          <div className="flex items-center space-x-3 mb-4">
            <Sparkles className="w-6 h-6 text-yellow-300" />
            <h3 className="text-lg font-bold">AI-Powered Insights</h3>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {recommendations.slice(0, 3).map((rec, idx) => (
              <div key={idx} className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Badge className={`${rec.priority === 'high' ? 'bg-red-500' : 'bg-yellow-500'} text-white text-xs`}>
                    {rec.priority.toUpperCase()}
                  </Badge>
                  <span className="text-xs text-white/70 capitalize">{rec.type}</span>
                </div>
                <h4 className="font-semibold mb-1">{rec.title}</h4>
                <p className="text-sm text-white/80 mb-2">{rec.description}</p>
                <p className="text-xs text-yellow-300">{rec.expectedImpact}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Stats Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((card, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow border-0 shadow-md">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-gray-500 mb-1">{card.label}</p>
                  <p className="text-3xl font-bold text-gray-900">{card.value}</p>
                  <div className={`flex items-center mt-2 text-sm ${card.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {card.trend === 'up' ? <ArrowUpRight className="w-4 h-4 mr-1" /> : <ArrowDownRight className="w-4 h-4 mr-1" />}
                    {card.change} this month
                  </div>
                </div>
                <div className={`w-12 h-12 ${card.lightColor} rounded-xl flex items-center justify-center`}>
                  <card.icon className={`w-6 h-6 ${card.color.replace('bg-', 'text-')}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Monthly Donations Chart */}
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-blue-600" />
              <span>Monthly Donations</span>
            </CardTitle>
            <CardDescription>Donation trends over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={stats?.monthlyDonations || []}>
                <defs>
                  <linearGradient id="colorDonations" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                <XAxis dataKey="month" stroke="#6B7280" fontSize={12} />
                <YAxis stroke="#6B7280" fontSize={12} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', borderRadius: '8px', border: '1px solid #E5E7EB' }}
                  formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Donations']}
                />
                <Area 
                  type="monotone" 
                  dataKey="donations" 
                  stroke="#3B82F6" 
                  fillOpacity={1} 
                  fill="url(#colorDonations)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Donation Categories */}
        <Card className="border-0 shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-green-600" />
              <span>Donation Categories</span>
            </CardTitle>
            <CardDescription>Distribution by category</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `₹${value.toLocaleString()}`} />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-3 mt-4">
              {pieData.map((entry, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                  <span className="text-sm text-gray-600">{entry.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* AI Predictions & Alerts */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Predictive Fundraising */}
        <Card className="border-0 shadow-md bg-gradient-to-br from-purple-50 to-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-purple-900">
              <Sparkles className="w-5 h-5" />
              <span>AI Predictions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-600 mb-1">Predicted Donations (Next Month)</p>
                <p className="text-2xl font-bold text-purple-700">₹{stats?.predictedDonationsNextMonth?.toLocaleString() || 0}</p>
                <Progress value={75} className="mt-2" />
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-1">Donor Retention Rate</p>
                <p className="text-2xl font-bold text-blue-700">{stats?.donorRetentionRate || 0}%</p>
                <Progress value={stats?.donorRetentionRate || 0} className="mt-2" />
              </div>
              <div className="flex items-center space-x-2 text-amber-600 bg-amber-50 p-3 rounded-lg">
                <AlertTriangle className="w-5 h-5" />
                <span className="text-sm">{stats?.atRiskDonors || 0} donors at churn risk</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-0 shadow-md lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-yellow-600" />
              <span>Recent Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              {/* Recent Donations */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Heart className="w-4 h-4 mr-2 text-red-500" />
                  Recent Donations
                </h4>
                <div className="space-y-3">
                  {stats?.recentDonations?.slice(0, 4).map((donation) => (
                    <div key={donation.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{donation.donorName}</p>
                        <p className="text-xs text-gray-500">{new Date(donation.createdAt).toLocaleDateString()}</p>
                      </div>
                      <span className="font-bold text-green-600">₹{donation.amount.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Upcoming Events */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                  <Calendar className="w-4 h-4 mr-2 text-blue-500" />
                  Upcoming Events
                </h4>
                <div className="space-y-3">
                  {stats?.upcomingEventsList?.slice(0, 4).map((event) => (
                    <div key={event.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{event.name}</p>
                        <p className="text-xs text-gray-500">{new Date(event.startDate).toLocaleDateString()}</p>
                      </div>
                      <Badge variant="outline" className="text-xs">{event.type}</Badge>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="border-0 shadow-md">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Users className="w-4 h-4 mr-2" />
              Add Member
            </Button>
            <Button className="bg-green-600 hover:bg-green-700">
              <Heart className="w-4 h-4 mr-2" />
              Record Donation
            </Button>
            <Button className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-blue-900 font-bold">
              <Briefcase className="w-4 h-4 mr-2" />
              New Service Activity
            </Button>
            <Button className="bg-yellow-600 hover:bg-yellow-700">
              <Calendar className="w-4 h-4 mr-2" />
              Create Event
            </Button>
            <Button variant="outline" className="border-purple-500 text-purple-600 hover:bg-purple-50">
              <Sparkles className="w-4 h-4 mr-2" />
              Run AI Analysis
            </Button>
            <Button variant="outline" className="border-blue-500 text-blue-600 hover:bg-blue-50">
              <MessageCircle className="w-4 h-4 mr-2" />
              Send Campaign
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
