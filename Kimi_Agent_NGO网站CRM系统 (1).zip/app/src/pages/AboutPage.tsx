import { useState, useEffect } from 'react';
import { Target, Eye, Heart, Award, Globe, HandHeart, Activity } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { db } from '@/lib/database';
import type { Member } from '@/types/database';

export default function AboutPage() {
  const [members, setMembers] = useState<Member[]>([]);

  useEffect(() => {
    setMembers(db.members.getAll().filter(m => m.status === 'Active'));
  }, []);

  const leadershipTeam = members.filter(m => 
    ['President', 'Vice President', 'Secretary', 'Treasurer'].includes(m.designation)
  );

  const values = [
    { icon: Heart, title: 'Compassion', desc: 'We serve with empathy and understanding, putting the needs of others first.' },
    { icon: Award, title: 'Integrity', desc: 'We act with honesty and transparency in all our dealings.' },
    { icon: Activity, title: 'Excellence', desc: 'We strive for the highest standards in everything we do.' },
    { icon: Globe, title: 'Impact', desc: 'We focus on creating meaningful, lasting change in our community.' },
  ];

  return (
    <div className="min-h-screen pt-28">
      {/* Hero */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full" style={{
            backgroundImage: 'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.1) 0%, transparent 50%)'
          }} />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <Badge className="mb-6 bg-yellow-500 text-blue-900 font-bold">About Us</Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Lions Club of<br />
            <span className="text-yellow-400">Baroda Rising Star</span>
          </h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Serving our community with dedication, compassion, and the spirit of volunteerism since 2020.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <Card className="border-l-4 border-l-yellow-500 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-10">
                <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center mb-6">
                  <Target className="w-8 h-8 text-yellow-600" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
                <p className="text-gray-600 leading-relaxed text-lg">
                  To empower our members to serve their communities, meet humanitarian needs, encourage peace, 
                  and promote international understanding through Lions clubs. We are dedicated to making 
                  a meaningful difference in the lives of those we serve.
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-l-4 border-l-blue-500 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-10">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                  <Eye className="w-8 h-8 text-blue-600" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Vision</h2>
                <p className="text-gray-600 leading-relaxed text-lg">
                  To be the global leader in community and humanitarian service, creating a world where 
                  every community has the opportunity to thrive. We envision a future where our service 
                  creates lasting positive change.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-blue-100 text-blue-900">Our Principles</Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Our Core Values</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              These principles guide everything we do as Lions.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-md group">
                <CardContent className="p-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                    <value.icon className="w-8 h-8 text-yellow-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{value.title}</h3>
                  <p className="text-gray-600">{value.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-yellow-100 text-yellow-800">Our Team</Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Leadership Team</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Meet the dedicated leaders who guide our club's mission.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {leadershipTeam.length > 0 ? leadershipTeam.map((member) => (
              <Card key={member.id} className="text-center overflow-hidden hover:shadow-2xl transition-all duration-300 border-0 shadow-lg group">
                <div className="h-32 bg-gradient-to-br from-blue-500 to-blue-700 relative">
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors" />
                </div>
                <CardContent className="p-6 -mt-16 relative">
                  <Avatar className="w-32 h-32 mx-auto border-4 border-white shadow-xl mb-4">
                    <AvatarFallback className="bg-gradient-to-br from-yellow-400 to-yellow-500 text-blue-900 text-2xl font-bold">
                      {member.firstName[0]}{member.lastName[0]}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-xl font-bold text-gray-900">{member.firstName} {member.lastName}</h3>
                  <Badge className="mt-2 bg-yellow-500 text-blue-900 font-bold">{member.designation}</Badge>
                  <p className="text-gray-500 mt-2 text-sm">{member.occupation}</p>
                </CardContent>
              </Card>
            )) : (
              <div className="col-span-4 text-center py-12">
                <HandHeart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">Leadership team information will be updated soon.</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
