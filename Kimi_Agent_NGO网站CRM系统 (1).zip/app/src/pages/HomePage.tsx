import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Heart, Users, Target, TrendingUp, Calendar, Award, 
  ArrowRight, ChevronRight, Star, MapPin 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { db, getDashboardStats } from '@/lib/database';
import type { DashboardStats, Project, Event } from '@/types/database';

export default function HomePage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
    setStats(getDashboardStats());
    setProjects(db.projects.getAll().slice(0, 3));
    setEvents(db.events.getAll().filter(e => new Date(e.startDate) > new Date()).slice(0, 3));
  }, []);

  const impactStats = [
    { icon: Users, label: 'Active Members', value: stats?.activeMembers || 0, suffix: '+' },
    { icon: Target, label: 'Service Activities', value: stats?.totalProjects || 0, suffix: '+' },
    { icon: Heart, label: 'Lives Impacted', value: stats?.totalBeneficiaries || 0, suffix: '+' },
    { icon: TrendingUp, label: 'Funds Raised (₹)', value: ((stats?.totalDonations || 0) / 100000).toFixed(1), suffix: 'L+' },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background with Overlay */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-blue-900/95 via-blue-800/90 to-blue-900/95 z-10" />
          <div 
            className="absolute inset-0 bg-cover bg-center scale-105 animate-slow-zoom"
            style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1559027615-cd4628902d4a?w=1920&q=80)' }}
          />
          {/* Animated Particles */}
          <div className="absolute inset-0 z-10 overflow-hidden">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="absolute w-2 h-2 bg-yellow-400/30 rounded-full animate-float"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 5}s`,
                  animationDuration: `${5 + Math.random() * 5}s`
                }}
              />
            ))}
          </div>
        </div>
        
        {/* Hero Content */}
        <div className={`relative z-20 text-center px-4 max-w-6xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center space-x-2 bg-white/10 backdrop-blur-md rounded-full px-5 py-2 mb-8 border border-white/20">
            <Star className="w-4 h-4 text-yellow-400" />
            <span className="text-white/90 text-sm font-medium">Serving Since 2020</span>
            <span className="text-white/50">|</span>
            <span className="text-yellow-400 text-sm font-medium">District 3232</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 leading-tight">
            Together We
            <span className="block bg-gradient-to-r from-yellow-400 via-yellow-300 to-yellow-500 bg-clip-text text-transparent">
              Make a Difference
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-blue-100 mb-10 max-w-3xl mx-auto leading-relaxed">
            Lions Club of Baroda Rising Star is dedicated to serving our community 
            through humanitarian projects, healthcare initiatives, and educational programs.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/donate">
              <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-blue-900 font-bold px-8 py-6 text-lg shadow-2xl hover:shadow-yellow-500/25 transition-all duration-300 group">
                Donate Now
                <Heart className="w-5 h-5 ml-2 group-hover:scale-110 transition-transform" />
              </Button>
            </Link>
            <Link to="/projects">
              <Button size="lg" className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-blue-900 font-bold px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all duration-300 group">
                Our Service Activities
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
          
          {/* Quick Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {impactStats.map((stat, index) => (
              <div key={index} className="bg-white/5 backdrop-blur-sm rounded-2xl p-4 border border-white/10">
                <stat.icon className="w-6 h-6 text-yellow-400 mx-auto mb-2" />
                <div className="text-2xl md:text-3xl font-bold text-white">{stat.value}{stat.suffix}</div>
                <div className="text-blue-200 text-sm">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 z-20 animate-bounce">
          <div className="w-10 h-10 rounded-full border-2 border-white/30 flex items-center justify-center">
            <ChevronRight className="w-5 h-5 text-white rotate-90" />
          </div>
        </div>
      </section>

      {/* About Preview Section */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-100/50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-100/50 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <Badge className="mb-4 bg-blue-100 text-blue-900 hover:bg-blue-200">About Us</Badge>
              <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Dedicated to Service
                <span className="text-blue-600"> Since 2020</span>
              </h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Lions Club of Baroda Rising Star is part of the world's largest service club organization. 
                We are men and women who volunteer our time to humanitarian causes in our local and world communities.
              </p>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                Our club has been actively serving the Vadodara community through various projects in healthcare, 
                education, environment, and community development.
              </p>
              
              <div className="flex flex-wrap gap-3 mb-8">
                {['Community Service', 'Healthcare', 'Education', 'Environment'].map((item) => (
                  <div key={item} className="flex items-center space-x-2 bg-green-50 px-4 py-2 rounded-full">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="font-medium text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
              
              <Link to="/about">
                <Button className="bg-blue-900 hover:bg-blue-800">
                  Learn More About Us
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <img 
                  src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400&q=80" 
                  alt="Community Service" 
                  className="rounded-2xl shadow-xl w-full h-48 object-cover hover:scale-105 transition-transform duration-500"
                />
                <img 
                  src="https://images.unsplash.com/photo-1531206715517-5c0ba140b2b8?w=400&q=80" 
                  alt="Volunteers" 
                  className="rounded-2xl shadow-xl w-full h-48 object-cover mt-8 hover:scale-105 transition-transform duration-500"
                />
                <img 
                  src="https://images.unsplash.com/photo-1593113598332-cd288d649433?w=400&q=80" 
                  alt="Team Work" 
                  className="rounded-2xl shadow-xl w-full h-48 object-cover hover:scale-105 transition-transform duration-500"
                />
                <img 
                  src="https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=400&q=80" 
                  alt="Helping Hands" 
                  className="rounded-2xl shadow-xl w-full h-48 object-cover mt-8 hover:scale-105 transition-transform duration-500"
                />
              </div>
              
              {/* Floating Badge */}
              <div className="absolute -bottom-6 -left-6 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-2xl p-6 shadow-xl">
                <div className="text-4xl font-bold text-blue-900">5+</div>
                <div className="text-blue-800 text-sm font-medium">Years of Service</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Service Activities */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-yellow-100 text-yellow-800 hover:bg-yellow-200">Our Work</Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Featured Service Activities</h2>
            <p className="text-gray-600 max-w-2xl mx-auto text-lg">
              Discover the impactful service activities we're working on to make our community a better place.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project) => (
              <Card key={project.id} className="overflow-hidden hover:shadow-2xl transition-all duration-500 group border-0 shadow-lg">
                <div className="h-56 bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                  <Target className="w-20 h-20 text-white/30 group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-white/90 text-blue-900">{project.category}</Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">{project.name}</h3>
                  <p className="text-gray-600 mb-4 line-clamp-2">{project.description}</p>
                  
                  <div className="flex items-center justify-between text-sm mb-4">
                    <span className="text-gray-500 flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {project.beneficiaries} beneficiaries
                    </span>
                    <span className={`font-medium px-3 py-1 rounded-full text-xs ${
                      project.status === 'In Progress' ? 'bg-yellow-100 text-yellow-700' : 
                      project.status === 'Completed' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {project.status}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Progress</span>
                      <span className="font-medium">{Math.round((project.spent / project.budget) * 100)}%</span>
                    </div>
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-yellow-400 to-yellow-500 transition-all duration-1000"
                        style={{ width: `${Math.round((project.spent / project.budget) * 100)}%` }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/projects">
              <Button className="bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-blue-900 font-bold px-8 py-6 text-lg shadow-lg hover:shadow-xl transition-all">
                View All Service Activities
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Upcoming Events */}
      <section className="py-24 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-64 h-64 border border-white/20 rounded-full" />
          <div className="absolute bottom-20 right-20 w-96 h-96 border border-white/20 rounded-full" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <Badge className="mb-4 bg-yellow-500 text-blue-900">Get Involved</Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Upcoming Events</h2>
            <p className="text-blue-200 max-w-2xl mx-auto text-lg">
              Join us at our upcoming events and be part of the change.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event) => (
              <Card key={event.id} className="bg-white/10 backdrop-blur-md border-white/20 text-white hover:bg-white/15 transition-all duration-300 group">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-xl flex flex-col items-center justify-center text-blue-900 shadow-lg">
                      <span className="text-xs font-bold uppercase">{new Date(event.startDate).toLocaleString('default', { month: 'short' }).toUpperCase()}</span>
                      <span className="text-2xl font-bold">{new Date(event.startDate).getDate()}</span>
                    </div>
                    <div>
                      <Badge className="bg-white/20 text-white mb-1">{event.type}</Badge>
                      <h3 className="font-bold text-lg group-hover:text-yellow-300 transition-colors">{event.name}</h3>
                    </div>
                  </div>
                  <p className="text-blue-200 mb-4 line-clamp-2">{event.description}</p>
                  <div className="flex items-center text-sm text-blue-200">
                    <MapPin className="w-4 h-4 mr-2" />
                    {event.venue}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link to="/events">
              <Button variant="outline" className="border-2 border-white/30 text-white hover:bg-white/10 px-8">
                View All Events
                <Calendar className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-400 relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-0 left-0 w-full h-full" style={{
            backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(0,0,0,0.1) 0%, transparent 50%)'
          }} />
        </div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          <Award className="w-16 h-16 text-blue-900 mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-6">
            Ready to Make a Difference?
          </h2>
          <p className="text-blue-900/80 text-xl mb-10 max-w-2xl mx-auto">
            Join us in our mission to serve the community. Your support can change lives and create lasting impact.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/donate">
              <Button size="lg" className="bg-blue-900 hover:bg-blue-800 text-white font-bold px-10 py-6 text-lg shadow-xl">
                Donate Now
              </Button>
            </Link>
            <Link to="/volunteer">
              <Button size="lg" variant="outline" className="border-2 border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white px-10 py-6 text-lg font-bold">
                Become a Volunteer
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}