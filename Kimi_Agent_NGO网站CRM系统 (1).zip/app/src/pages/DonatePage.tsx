import { useState } from 'react';
import { Heart, Award, Shield, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { db, generateId, generateDonationReceipt } from '@/lib/database';
import type { Donation } from '@/types/database';

export default function DonatePage() {
  const [amount, setAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    category: 'General Fund',
    message: '',
    isAnonymous: false
  });

  const presetAmounts = [500, 1000, 2500, 5000, 10000, 25000];
  const categories = ['General Fund', 'Education', 'Healthcare', 'Environment', 'Disaster Relief', 'Eye Care', 'Hunger Relief'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const donationAmount = amount || parseInt(customAmount);
    if (!donationAmount) {
      toast.error('Please select or enter a donation amount');
      return;
    }

    setLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    const donation: Donation = {
      id: generateId(),
      donorName: formData.name,
      donorEmail: formData.email,
      donorPhone: formData.phone,
      amount: donationAmount,
      currency: 'INR',
      donationType: 'One-Time',
      category: formData.category as any,
      paymentMethod: 'Credit Card',
      paymentStatus: 'Pending',
      receiptNumber: generateDonationReceipt(),
      isAnonymous: formData.isAnonymous,
      message: formData.message,
      taxCertificateIssued: false,
      acknowledgmentSent: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    db.donations.create(donation);
    
    toast.success('Thank you for your donation!', {
      description: `Receipt #${donation.receiptNumber} will be emailed to you.`,
    });
    
    setAmount(null);
    setCustomAmount('');
    setFormData({ name: '', email: '', phone: '', category: 'General Fund', message: '', isAnonymous: false });
    setLoading(false);
  };

  const features = [
    { icon: Heart, title: '100% Impact', desc: 'Every rupee goes directly to our projects' },
    { icon: Award, title: 'Tax Benefits', desc: '80G certificate provided for all donations' },
    { icon: Shield, title: 'Secure Payment', desc: 'Bank-grade encryption for all transactions' },
    { icon: Zap, title: 'Instant Receipt', desc: 'Tax receipt emailed immediately' }
  ];

  return (
    <div className="min-h-screen pt-28">
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-6 bg-yellow-500 text-blue-900 font-bold">Support Our Cause</Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">Make a Donation</h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Your contribution helps us continue our mission of serving the community.
          </p>
        </div>
      </section>

      <section className="py-24 bg-gray-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Features */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            {features.map((item, index) => (
              <Card key={index} className="text-center border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-yellow-100 to-yellow-200 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <item.icon className="w-7 h-7 text-yellow-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-600">{item.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="border-0 shadow-xl">
            <CardHeader className="text-center pb-2">
              <CardTitle className="text-3xl text-gray-900">Donation Form</CardTitle>
              <CardDescription className="text-lg">Choose your donation amount and fill in your details</CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Amount Selection */}
                <div>
                  <Label className="text-lg font-medium mb-4 block">Select Amount (₹)</Label>
                  <div className="grid grid-cols-3 md:grid-cols-6 gap-3 mb-4">
                    {presetAmounts.map((amt) => (
                      <Button
                        key={amt}
                        type="button"
                        variant={amount === amt ? 'default' : 'outline'}
                        onClick={() => { setAmount(amt); setCustomAmount(''); }}
                        className={`h-14 text-lg font-bold ${amount === amt ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 hover:from-yellow-500 hover:to-yellow-600' : ''}`}
                      >
                        ₹{amt.toLocaleString()}
                      </Button>
                    ))}
                  </div>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-bold">₹</span>
                    <Input 
                      type="number"
                      placeholder="Enter custom amount"
                      value={customAmount}
                      onChange={(e) => { setCustomAmount(e.target.value); setAmount(null); }}
                      className="pl-10 h-14 text-lg"
                    />
                  </div>
                </div>

                {/* Category */}
                <div>
                  <Label className="text-lg font-medium mb-4 block">Donation Category</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={(value) => setFormData({...formData, category: value})}
                  >
                    <SelectTrigger className="h-12">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Personal Details */}
                <div className="grid md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label htmlFor="dname">Full Name *</Label>
                    <Input 
                      id="dname"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                      className="h-12"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="demail">Email *</Label>
                    <Input 
                      id="demail"
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                      className="h-12"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dphone">Phone *</Label>
                  <Input 
                    id="dphone"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    required
                    className="h-12"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="dmessage">Message (Optional)</Label>
                  <Textarea 
                    id="dmessage"
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    placeholder="Any message you'd like to share..."
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                  <Switch 
                    id="anonymous"
                    checked={formData.isAnonymous}
                    onCheckedChange={(checked) => setFormData({...formData, isAnonymous: checked})}
                  />
                  <Label htmlFor="anonymous" className="cursor-pointer">Make this donation anonymous</Label>
                </div>

                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-500 hover:to-yellow-600 text-blue-900 font-bold text-xl py-6 h-auto shadow-xl hover:shadow-2xl transition-all"
                  disabled={loading}
                >
                  {loading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-900 mr-3" />
                      Processing...
                    </div>
                  ) : (
                    <>
                      Proceed to Payment
                      <Heart className="w-6 h-6 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  );
}
