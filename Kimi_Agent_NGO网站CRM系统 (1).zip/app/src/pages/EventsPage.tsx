import { useState, useEffect } from 'react';
import { Clock, MapPin, Calendar, Users, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { db } from '@/lib/database';
import type { Event } from '@/types/database';

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([]);

  useEffect(() => {
    setEvents(db.events.getAll().sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime()));
  }, []);

  const upcomingEvents = events.filter(e => new Date(e.startDate) > new Date());
  const pastEvents = events.filter(e => new Date(e.startDate) <= new Date());

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return {
      month: date.toLocaleString('default', { month: 'short' }).toUpperCase(),
      day: date.getDate(),
      year: date.getFullYear(),
      time: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  };

  return (
    <div className="min-h-screen pt-28">
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-6 bg-yellow-500 text-blue-900 font-bold">Get Involved</Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">Events</h1>
          <p className="text-xl text-blue-200 max-w-3xl mx-auto">
            Join us at our upcoming events and be part of the change.
          </p>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs defaultValue="upcoming" className="w-full">
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-12">
              <TabsTrigger value="upcoming" className="text-lg">Upcoming Events</TabsTrigger>
              <TabsTrigger value="past" className="text-lg">Past Events</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upcoming">
              <div className="grid md:grid-cols-2 gap-8">
                {upcomingEvents.map((event) => {
                  const date = formatDate(event.startDate);
                  return (
                    <Card key={event.id} className="overflow-hidden hover:shadow-2xl transition-all duration-300 border-0 shadow-lg group">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-1/3 bg-gradient-to-br from-yellow-400 to-yellow-500 flex flex-col items-center justify-center p-8 text-blue-900">
                          <span className="text-sm font-bold uppercase tracking-wider">{date.month}</span>
                          <span className="text-6xl font-bold">{date.day}</span>
                          <span className="text-lg">{date.year}</span>
                        </div>
                        <CardContent className="md:w-2/3 p-6">
                          <Badge className="mb-3 bg-blue-100 text-blue-700">{event.type}</Badge>
                          <h3 className="text-2xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">{event.name}</h3>
                          <p className="text-gray-600 mb-4">{event.description}</p>
                          <div className="space-y-2 text-sm text-gray-500">
                            <div className="flex items-center">
                              <Clock className="w-4 h-4 mr-2 text-blue-500" />
                              {date.time}
                            </div>
                            <div className="flex items-center">
                              <MapPin className="w-4 h-4 mr-2 text-blue-500" />
                              {event.venue}
                            </div>
                            <div className="flex items-center">
                              <Users className="w-4 h-4 mr-2 text-blue-500" />
                              {event.attendees.length} registered
                            </div>
                          </div>
                          {event.registrationOpen && (
                            <Button className="mt-4 bg-blue-900 hover:bg-blue-800">
                              Register Now
                            </Button>
                          )}
                        </CardContent>
                      </div>
                    </Card>
                  );
                })}
              </div>
              {upcomingEvents.length === 0 && (
                <div className="text-center py-16">
                  <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg">No upcoming events at the moment.</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="past">
              <div className="grid md:grid-cols-2 gap-8">
                {pastEvents.map((event) => {
                  const date = formatDate(event.startDate);
                  return (
                    <Card key={event.id} className="overflow-hidden opacity-70 hover:opacity-100 transition-opacity">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-1/3 bg-gray-200 flex flex-col items-center justify-center p-8 text-gray-700">
                          <span className="text-sm font-bold uppercase tracking-wider">{date.month}</span>
                          <span className="text-6xl font-bold">{date.day}</span>
                          <span className="text-lg">{date.year}</span>
                        </div>
                        <CardContent className="md:w-2/3 p-6">
                          <Badge variant="secondary" className="mb-3">{event.type}</Badge>
                          <h3 className="text-2xl font-bold text-gray-900 mb-2">{event.name}</h3>
                          <p className="text-gray-600 mb-4">{event.description}</p>
                          <div className="flex items-center text-green-600">
                            <CheckCircle className="w-5 h-5 mr-2" />
                            Event Completed
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  );
                })}
              </div>
              {pastEvents.length === 0 && (
                <div className="text-center py-16">
                  <CheckCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 text-lg">No past events to display.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </div>
  );
}
