import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Menu, X, LogIn, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PublicNavbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white shadow-xl' : 'bg-transparent'}`}>
      {/* Top Contact Bar */}
      <div className={`${scrolled ? 'bg-gradient-to-r from-blue-900 to-blue-800' : 'bg-black/20 backdrop-blur-sm'} transition-all duration-300`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
          <div className="flex justify-between items-center">
            <span className="text-white/80 text-xs">Serving Community Since 2020</span>
            <a href="tel:+919712299333" className="flex items-center space-x-2 text-sm text-white hover:text-yellow-400 transition-colors">
              <Phone className="w-4 h-4" />
              <span>+91-9712299333</span>
            </a>
          </div>
        </div>
      </div>
      
      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link to="/" className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-14 h-14 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg">
                <Heart className="w-7 h-7 text-blue-900" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-[8px] text-white font-bold">LCI</span>
              </div>
            </div>
            <div className={`font-bold ${scrolled ? 'text-blue-900' : 'text-white'}`}>
              <span className="block text-[10px] uppercase tracking-widest opacity-70">Lions Club of</span>
              <span className="block text-lg leading-tight">Baroda Rising Star</span>
            </div>
          </Link>
          
          <div className="hidden lg:flex items-center space-x-1">
            {[
              { name: 'Home', path: '/' },
              { name: 'About', path: '/about' },
              { name: 'Service Activities', path: '/projects' },
              { name: 'Events', path: '/events' },
              { name: 'Contact', path: '/contact' }
            ].map((item) => (
              <Link 
                key={item.name} 
                to={item.path}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-300 hover:bg-yellow-500/10 ${
                  scrolled ? 'text-gray-700 hover:text-blue-900' : 'text-white/90 hover:text-white'
                }`}
              >
                {item.name}
              </Link>
            ))}
            
            <div className="flex items-center space-x-2 ml-4">
              <Link to="/donate">
                <Button className="bg-gradient-to-r from-yellow-500 to-yellow-600 hover:from-yellow-600 hover:to-yellow-700 text-blue-900 font-bold shadow-lg hover:shadow-xl transition-all">
                  Donate
                </Button>
              </Link>
              <Link to="/volunteer">
                <Button variant="outline" className={`${scrolled ? 'border-blue-900 text-blue-900 hover:bg-blue-900 hover:text-white' : 'border-white text-white hover:bg-white/10'} font-medium`}>
                  Volunteer
                </Button>
              </Link>
              <Link to="/admin">
                <Button variant="ghost" size="icon" className={`${scrolled ? 'text-blue-900' : 'text-white'}`}>
                  <LogIn className="w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
          
          <button className="lg:hidden p-2" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className={scrolled ? 'text-gray-900' : 'text-white'} /> : <Menu className={scrolled ? 'text-gray-900' : 'text-white'} />}
          </button>
        </div>
      </div>
      
      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white shadow-2xl border-t">
          <div className="px-4 py-6 space-y-3">
            {['Home', 'About', 'Service Activities', 'Events', 'Contact'].map((item) => (
              <Link 
                key={item} 
                to={item === 'Home' ? '/' : `/${item.toLowerCase()}`}
                className="block px-4 py-3 text-gray-700 hover:text-blue-900 hover:bg-blue-50 rounded-lg font-medium transition-colors"
                onClick={() => setIsOpen(false)}
              >
                {item}
              </Link>
            ))}
            <div className="pt-4 space-y-3">
              <Link to="/donate" onClick={() => setIsOpen(false)}>
                <Button className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 text-blue-900 font-bold">
                  Donate Now
                </Button>
              </Link>
              <Link to="/volunteer" onClick={() => setIsOpen(false)}>
                <Button variant="outline" className="w-full border-blue-900 text-blue-900">
                  Become a Volunteer
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}