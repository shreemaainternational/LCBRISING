import { useState, useRef } from 'react';
import { Upload, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { fileToBase64, compressImage } from '@/lib/shareService';

interface ImageUploadProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
  maxSizeMB?: number;
}

export default function ImageUpload({ 
  images, 
  onImagesChange, 
  maxImages = 10,
  maxSizeMB = 5 
}: ImageUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (files: FileList | null) => {
    if (!files || files.length === 0) return;

    const remainingSlots = maxImages - images.length;
    if (remainingSlots <= 0) {
      toast.error(`Maximum ${maxImages} images allowed`);
      return;
    }

    const filesToProcess = Array.from(files).slice(0, remainingSlots);
    setUploading(true);

    const newImages: string[] = [];

    for (const file of filesToProcess) {
      // Check file size
      if (file.size > maxSizeMB * 1024 * 1024) {
        toast.error(`${file.name} is too large. Max size is ${maxSizeMB}MB`);
        continue;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        toast.error(`${file.name} is not an image file`);
        continue;
      }

      try {
        const base64 = await fileToBase64(file);
        const compressed = await compressImage(base64, 1200, 0.8);
        newImages.push(compressed);
        toast.success(`${file.name} uploaded successfully`);
      } catch (error) {
        toast.error(`Failed to upload ${file.name}`);
      }
    }

    onImagesChange([...images, ...newImages]);
    setUploading(false);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileSelect(e.dataTransfer.files);
  };

  const removeImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    onImagesChange(newImages);
    toast.success('Image removed');
  };

  const reorderImages = (fromIndex: number, toIndex: number) => {
    const newImages = [...images];
    const [moved] = newImages.splice(fromIndex, 1);
    newImages.splice(toIndex, 0, moved);
    onImagesChange(newImages);
  };

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <div
        onClick={() => fileInputRef.current?.click()}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`
          border-2 border-dashed rounded-xl p-8 text-center cursor-pointer
          transition-all duration-200
          ${isDragging 
            ? 'border-blue-500 bg-blue-50' 
            : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
          }
          ${images.length >= maxImages ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={(e) => handleFileSelect(e.target.files)}
          disabled={images.length >= maxImages || uploading}
        />
        
        {uploading ? (
          <div className="flex flex-col items-center">
            <Loader2 className="w-10 h-10 text-blue-500 animate-spin mb-2" />
            <p className="text-gray-600">Uploading images...</p>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className="w-14 h-14 bg-blue-100 rounded-full flex items-center justify-center mb-3">
              <Upload className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-gray-700 font-medium mb-1">
              {images.length >= maxImages 
                ? 'Maximum images reached' 
                : 'Click or drag images here'
              }
            </p>
            <p className="text-sm text-gray-500">
              Supports: JPG, PNG, GIF (max {maxSizeMB}MB each)
            </p>
            <p className="text-xs text-gray-400 mt-2">
              {images.length} / {maxImages} images
            </p>
          </div>
        )}
      </div>

      {/* Image Grid */}
      {images.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Uploaded Images</Label>
            <span className="text-xs text-gray-500">{images.length} image(s)</span>
          </div>
          
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
            {images.map((image, index) => (
              <div 
                key={index} 
                className="relative group aspect-square rounded-lg overflow-hidden border bg-gray-100"
              >
                <img 
                  src={image} 
                  alt={`Upload ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  {index > 0 && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="w-8 h-8 text-white hover:bg-white/20"
                      onClick={(e) => {
                        e.stopPropagation();
                        reorderImages(index, index - 1);
                      }}
                    >
                      ←
                    </Button>
                  )}
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="w-8 h-8 text-white hover:bg-red-500/80"
                    onClick={(e) => {
                      e.stopPropagation();
                      removeImage(index);
                    }}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                  {index < images.length - 1 && (
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="w-8 h-8 text-white hover:bg-white/20"
                      onClick={(e) => {
                        e.stopPropagation();
                        reorderImages(index, index + 1);
                      }}
                    >
                      →
                    </Button>
                  )}
                </div>

                {/* Index Badge */}
                <div className="absolute top-1 left-1 bg-blue-600 text-white text-xs px-1.5 py-0.5 rounded">
                  {index + 1}
                </div>

                {/* Cover Image Badge */}
                {index === 0 && (
                  <div className="absolute bottom-1 right-1 bg-yellow-500 text-blue-900 text-xs px-1.5 py-0.5 rounded font-medium">
                    Cover
                  </div>
                )}
              </div>
            ))}
          </div>
          
          <p className="text-xs text-gray-500">
            First image will be used as cover. Drag to reorder or click arrows.
          </p>
        </div>
      )}
    </div>
  );
}

// Label component for ImageUpload
function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <span className={`text-sm font-medium ${className}`}>{children}</span>;
}
