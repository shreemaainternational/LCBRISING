import { Link } from 'react-router-dom';
import { Heart, Facebook, Instagram, MapPin, Phone, Mail, ExternalLink } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-blue-950 via-blue-900 to-blue-950 text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Column */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-blue-900" />
              </div>
              <div className="font-bold">
                <span className="block text-[10px] uppercase tracking-wider opacity-70">Lions Club of</span>
                <span className="block text-sm">Baroda Rising Star</span>
              </div>
            </div>
            <p className="text-blue-200 text-sm leading-relaxed mb-6">
              Serving humanity with compassion and dedication. Together, we make a lasting impact in our community through service, leadership, and volunteerism.
            </p>
            <div className="flex space-x-3">
              <a 
                href="https://www.facebook.com/profile.php?id=61572422069093" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/10 hover:bg-yellow-500 rounded-full flex items-center justify-center transition-all duration-300 group"
              >
                <Facebook className="w-5 h-5 group-hover:text-blue-900 transition-colors" />
              </a>
              <a 
                href="https://www.instagram.com/barodarisingstar/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/10 hover:bg-yellow-500 rounded-full flex items-center justify-center transition-all duration-300 group"
              >
                <Instagram className="w-5 h-5 group-hover:text-blue-900 transition-colors" />
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-yellow-400">Quick Links</h3>
            <ul className="space-y-3">
              {[
                { name: 'Home', path: '/' },
                { name: 'About Us', path: '/about' },
                { name: 'Our Service Activities', path: '/projects' },
                { name: 'Events', path: '/events' },
                { name: 'Contact', path: '/contact' },
                { name: 'Donate', path: '/donate' },
                { name: 'Volunteer', path: '/volunteer' }
              ].map((link) => (
                <li key={link.name}>
                  <Link to={link.path} className="text-blue-200 hover:text-yellow-400 transition-colors flex items-center group">
                    <span className="w-0 group-hover:w-2 h-0.5 bg-yellow-400 mr-0 group-hover:mr-2 transition-all duration-300" />
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Our Focus */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-yellow-400">Our Focus Areas</h3>
            <ul className="space-y-3">
              {['Community Service', 'Healthcare Initiatives', 'Education Support', 'Environmental Care', 'Youth Programs', 'Senior Care', 'Eye Care Camps', 'Hunger Relief'].map((item) => (
                <li key={item} className="text-blue-200 flex items-center">
                  <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full mr-3" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold mb-6 text-yellow-400">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3">
                <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <p className="text-blue-100 font-medium">Address</p>
                  <p className="text-blue-300 text-sm">12-Kirtikunj Society, B/S Pragati Bank, Karelibaug, Vadodara - 390018</p>
                </div>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <p className="text-blue-100 font-medium">Phone</p>
                  <a href="tel:+919712299333" className="text-blue-300 text-sm hover:text-yellow-400 transition-colors">+91-9712299333</a>
                </div>
              </li>
              <li className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-yellow-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <p className="text-blue-100 font-medium">Email</p>
                  <a href="mailto:barodarisingstar@gmail.com" className="text-blue-300 text-sm hover:text-yellow-400 transition-colors">barodarisingstar@gmail.com</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      
      <Separator className="bg-blue-800" />
      
      {/* Bottom Bar */}
      <div className="bg-blue-950/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-blue-400 text-sm text-center md:text-left">
              &copy; {currentYear} Lions Club of Baroda Rising Star. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 text-sm">
              <Link to="/admin" className="text-blue-400 hover:text-yellow-400 transition-colors flex items-center">
                Admin Login <ExternalLink className="w-3 h-3 ml-1" />
              </Link>
              <span className="text-blue-700">|</span>
              <span className="text-blue-400">District 3232</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
