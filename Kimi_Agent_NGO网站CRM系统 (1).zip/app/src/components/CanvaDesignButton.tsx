import { useState } from 'react';
import { Palette, ExternalLink, Download, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { canvaConfigDB, canvaDesignDB, canvaUrls, createDesignFromTemplate } from '@/lib/canvaService';
import type { CanvaTemplate, CanvaDesign } from '@/types/canvaConfig';

interface CanvaDesignButtonProps {
  entityType: 'project' | 'event' | 'campaign' | 'member' | 'general';
  entityId?: string;
  entityData?: any;
  buttonText?: string;
  buttonVariant?: 'default' | 'outline' | 'ghost';
  buttonSize?: 'default' | 'sm' | 'lg' | 'icon';
  className?: string;
  showExisting?: boolean;
}

export default function CanvaDesignButton({
  entityType,
  entityId,
  entityData,
  buttonText = 'Design in Canva',
  buttonVariant = 'default',
  buttonSize = 'default',
  className = '',
  showExisting = true
}: CanvaDesignButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [existingDesigns, setExistingDesigns] = useState<CanvaDesign[]>([]);
  const [templates, setTemplates] = useState<CanvaTemplate[]>([]);
  
  const config = canvaConfigDB.get();
  
  if (!config.enabled) {
    return null;
  }

  const handleOpen = () => {
    // Load templates
    setTemplates(canvaConfigDB.getTemplates());
    
    // Load existing designs if applicable
    if (showExisting && entityId) {
      setExistingDesigns(canvaDesignDB.getByEntity(entityType, entityId));
    }
    
    setIsOpen(true);
  };

  const handleCreateDesign = async (templateId: string) => {
    setIsLoading(true);
    
    try {
      const title = entityData?.name || entityData?.title || `New ${entityType} Design`;
      const { editorUrl } = createDesignFromTemplate(
        templateId,
        entityType,
        entityId,
        title
      );
      
      // Open Canva in new window
      window.open(editorUrl, '_blank', 'width=1400,height=900');
      
      toast.success('Design created! Canva opened in new tab.');
      setIsOpen(false);
    } catch (error) {
      toast.error('Failed to create design. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleOpenExisting = (design: CanvaDesign) => {
    if (design.canvaEditUrl) {
      window.open(design.canvaEditUrl, '_blank', 'width=1400,height=900');
    } else {
      // Fallback to browsing templates
      window.open(canvaUrls.browseTemplates(), '_blank');
    }
  };

  const handleDownload = (design: CanvaDesign) => {
    if (design.exports.length > 0) {
      const latestExport = design.exports[design.exports.length - 1];
      window.open(latestExport.url, '_blank');
    } else {
      toast.info('No exports available yet. Edit the design in Canva first.');
    }
  };

  // Get category icon/color
  const getCategoryStyle = (category: string) => {
    const styles: Record<string, { bg: string; icon: string }> = {
      social: { bg: 'bg-pink-100 text-pink-700', icon: '📱' },
      poster: { bg: 'bg-blue-100 text-blue-700', icon: '📋' },
      flyer: { bg: 'bg-green-100 text-green-700', icon: '📄' },
      banner: { bg: 'bg-purple-100 text-purple-700', icon: '🎯' },
      presentation: { bg: 'bg-orange-100 text-orange-700', icon: '📊' },
      custom: { bg: 'bg-gray-100 text-gray-700', icon: '🎨' }
    };
    return styles[category] || styles.custom;
  };

  return (
    <>
      <Button
        variant={buttonVariant}
        size={buttonSize}
        className={`${className}`}
        onClick={handleOpen}
      >
        <Palette className="w-4 h-4 mr-2" />
        {buttonText}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Palette className="w-5 h-5 text-blue-600" />
              Design with Canva
            </DialogTitle>
            <DialogDescription>
              Create professional designs for your {entityType} using Canva templates
            </DialogDescription>
          </DialogHeader>

          <ScrollArea className="h-[60vh]">
            <div className="space-y-6 pr-4">
              {/* Existing Designs Section */}
              {showExisting && existingDesigns.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
                    Existing Designs ({existingDesigns.length})
                  </h3>
                  <div className="grid grid-cols-2 gap-3">
                    {existingDesigns.map(design => (
                      <div 
                        key={design.id} 
                        className="border rounded-lg p-3 hover:border-blue-400 transition-colors"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <p className="font-medium text-sm">{design.title}</p>
                            <p className="text-xs text-gray-500">
                              v{design.version} • {new Date(design.updatedAt).toLocaleDateString()}
                            </p>
                          </div>
                          <Badge variant={design.status === 'published' ? 'default' : 'secondary'} className="text-xs">
                            {design.status}
                          </Badge>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1 text-xs"
                            onClick={() => handleOpenExisting(design)}
                          >
                            <ExternalLink className="w-3 h-3 mr-1" />
                            Edit
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1 text-xs"
                            onClick={() => handleDownload(design)}
                            disabled={design.exports.length === 0}
                          >
                            <Download className="w-3 h-3 mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Templates Section */}
              <div>
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
                  Choose a Template
                </h3>
                
                {isLoading ? (
                  <div className="flex items-center justify-center py-12">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-4">
                    {templates.map(template => {
                      const style = getCategoryStyle(template.category);
                      return (
                        <button
                          key={template.id}
                          onClick={() => handleCreateDesign(template.id)}
                          className="group text-left border rounded-xl overflow-hidden hover:shadow-lg hover:border-blue-400 transition-all"
                        >
                          {/* Template Preview */}
                          <div 
                            className="h-32 bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center relative"
                            style={{
                              aspectRatio: `${template.defaultDimensions.width} / ${template.defaultDimensions.height}`
                            }}
                          >
                            <span className="text-4xl">{style.icon}</span>
                            <div className={`absolute top-2 right-2 px-2 py-1 rounded text-xs font-medium ${style.bg}`}>
                              {template.category}
                            </div>
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors flex items-center justify-center">
                              <span className="opacity-0 group-hover:opacity-100 bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-medium transition-opacity">
                                Use Template
                              </span>
                            </div>
                          </div>
                          
                          {/* Template Info */}
                          <div className="p-3">
                            <p className="font-medium text-sm">{template.name}</p>
                            <p className="text-xs text-gray-500 mt-1">{template.description}</p>
                            <div className="flex items-center gap-2 mt-2 text-xs text-gray-400">
                              <span>{template.defaultDimensions.width}×{template.defaultDimensions.height}{template.defaultDimensions.unit}</span>
                              <span>•</span>
                              <span>{template.editableElements.length} elements</span>
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Quick Actions */}
              <div className="border-t pt-4">
                <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-3">
                  Quick Actions
                </h3>
                <div className="flex gap-3">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => window.open(canvaUrls.browseTemplates('social'), '_blank')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Browse Canva Templates
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => window.open('https://www.canva.com/brand', '_blank')}
                  >
                    <Palette className="w-4 h-4 mr-2" />
                    Brand Kit
                  </Button>
                </div>
              </div>
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Compact version for inline use
export function CanvaDesignCompact({
  entityType,
  entityId,
  entityData
}: Omit<CanvaDesignButtonProps, 'buttonText' | 'buttonVariant' | 'buttonSize' | 'className' | 'showExisting'>) {
  const config = canvaConfigDB.get();
  
  if (!config.enabled) return null;

  const quickTemplates = canvaConfigDB.getTemplates().slice(0, 3);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm">
          <Palette className="w-4 h-4 mr-1" />
          Design
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        {quickTemplates.map(template => (
          <DropdownMenuItem 
            key={template.id}
            onClick={() => {
              const title = entityData?.name || `New ${entityType} Design`;
              const { editorUrl } = createDesignFromTemplate(
                template.id,
                entityType,
                entityId,
                title
              );
              window.open(editorUrl, '_blank');
            }}
          >
            <span className="mr-2">
              {template.category === 'social' && '📱'}
              {template.category === 'poster' && '📋'}
              {template.category === 'flyer' && '📄'}
              {template.category === 'banner' && '🎯'}
              {template.category === 'presentation' && '📊'}
            </span>
            {template.name}
          </DropdownMenuItem>
        ))}
        <DropdownMenuItem onClick={() => window.open(canvaUrls.browseTemplates(), '_blank')}>
          <ExternalLink className="w-4 h-4 mr-2" />
          Browse More Templates...
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
