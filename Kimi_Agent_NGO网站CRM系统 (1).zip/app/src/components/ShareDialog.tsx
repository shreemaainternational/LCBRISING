import { useState, useEffect } from 'react';
import { 
  Share2, Copy, Check, Download, Link2, 
  Facebook, Twitter, Linkedin, Mail, MessageCircle, 
  Code, ExternalLink
} from 'lucide-react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { 
  createShortLink, 
  generateWhatsAppLink,
  generateFacebookLink,
  generateTwitterLink,
  generateLinkedInLink,
  generateEmailLink,
  generateEmbedCode,
  copyToClipboard,
  downloadQRCode,
  generateProjectShareContent
} from '@/lib/shareService';
import type { Project, Event, ShareableContent } from '@/types/database';

interface ShareDialogProps {
  isOpen: boolean;
  onClose: () => void;
  entity: Project | Event | null;
  entityType: 'project' | 'event';
}

export default function ShareDialog({ isOpen, onClose, entity, entityType }: ShareDialogProps) {
  const [shareContent, setShareContent] = useState<ShareableContent | null>(null);
  const [shortUrl, setShortUrl] = useState('');
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const [embedWidth, setEmbedWidth] = useState(560);
  const [embedHeight, setEmbedHeight] = useState(400);
  const [posterSize, setPosterSize] = useState<'square' | 'portrait' | 'story'>('square');

  useEffect(() => {
    if (entity && isOpen) {
      const content = entityType === 'project' 
        ? generateProjectShareContent(entity as Project)
        : {
            title: `Lions Club Event: ${(entity as Event).name}`,
            description: (entity as Event).description.substring(0, 150) + '...',
            imageUrl: (entity as Event).images[0],
            url: `${window.location.origin}/events/${entity.id}`,
            hashtags: ['LionsClub', 'BarodaRisingStar', 'CommunityEvent'],
          };
      setShareContent(content);
      
      // Create short link
      const shareLink = createShortLink(entityType, entity.id, content.title);
      setShortUrl(`${window.location.origin}/s/${shareLink.shortCode}`);
      setQrCodeUrl(shareLink.qrCode);
    }
  }, [entity, isOpen, entityType]);

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      toast.success('Copied to clipboard!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadQR = async () => {
    if (shareContent) {
      await downloadQRCode(shareContent.url, `qr-${entityType}-${entity?.id}.png`);
      toast.success('QR Code downloaded!');
    }
  };

  const openShareWindow = (url: string) => {
    window.open(url, '_blank', 'width=600,height=400');
  };

  if (!entity || !shareContent) return null;

  const embedCode = generateEmbedCode(shareContent.url, embedWidth, embedHeight);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Share2 className="w-5 h-5 mr-2" />
            Share {entityType === 'project' ? 'Service Activity' : 'Event'}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="social" className="w-full">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="social">Social</TabsTrigger>
            <TabsTrigger value="link">Link</TabsTrigger>
            <TabsTrigger value="qr">QR Code</TabsTrigger>
            <TabsTrigger value="poster">Poster</TabsTrigger>
            <TabsTrigger value="embed">Embed</TabsTrigger>
          </TabsList>

          {/* Social Media Sharing */}
          <TabsContent value="social" className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <Button 
                variant="outline" 
                className="h-14 bg-[#1877F2] text-white hover:bg-[#166fe5] border-0"
                onClick={() => openShareWindow(generateFacebookLink(shareContent.url))}
              >
                <Facebook className="w-5 h-5 mr-2" />
                Facebook
              </Button>
              <Button 
                variant="outline" 
                className="h-14 bg-[#1DA1F2] text-white hover:bg-[#1a91da] border-0"
                onClick={() => openShareWindow(generateTwitterLink(shareContent))}
              >
                <Twitter className="w-5 h-5 mr-2" />
                Twitter
              </Button>
              <Button 
                variant="outline" 
                className="h-14 bg-[#0A66C2] text-white hover:bg-[#0958a8] border-0"
                onClick={() => openShareWindow(generateLinkedInLink(shareContent.url))}
              >
                <Linkedin className="w-5 h-5 mr-2" />
                LinkedIn
              </Button>
              <Button 
                variant="outline" 
                className="h-14 bg-[#25D366] text-white hover:bg-[#128C7E] border-0"
                onClick={() => openShareWindow(generateWhatsAppLink(shareContent))}
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp
              </Button>
              <Button 
                variant="outline" 
                className="h-14 bg-gray-600 text-white hover:bg-gray-700 border-0"
                onClick={() => openShareWindow(generateEmailLink(shareContent))}
              >
                <Mail className="w-5 h-5 mr-2" />
                Email
              </Button>
              <Button 
                variant="outline" 
                className="h-14"
                onClick={() => handleCopy(shareContent.url)}
              >
                {copied ? <Check className="w-5 h-5 mr-2" /> : <Copy className="w-5 h-5 mr-2" />}
                Copy Link
              </Button>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <Label className="text-sm font-medium">Preview</Label>
              <div className="mt-2 p-3 bg-white rounded border">
                <p className="font-semibold text-blue-900">{shareContent.title}</p>
                <p className="text-sm text-gray-600 mt-1">{shareContent.description}</p>
                <div className="flex gap-2 mt-2">
                  {shareContent.hashtags.map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">#{tag}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Short Link */}
          <TabsContent value="link" className="space-y-4">
            <div className="space-y-2">
              <Label>Short Link</Label>
              <div className="flex gap-2">
                <Input value={shortUrl} readOnly className="font-mono" />
                <Button onClick={() => handleCopy(shortUrl)}>
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Original URL</Label>
              <div className="flex gap-2">
                <Input value={shareContent.url} readOnly className="font-mono text-sm" />
                <Button variant="outline" onClick={() => handleCopy(shareContent.url)}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-start gap-3">
                <Link2 className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <p className="font-medium text-blue-900">Track Your Link</p>
                  <p className="text-sm text-blue-700">See how many people click on your short link in the Reports section.</p>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* QR Code */}
          <TabsContent value="qr" className="space-y-4">
            <div className="flex flex-col items-center">
              <div className="bg-white p-6 rounded-xl shadow-lg">
                <img 
                  src={qrCodeUrl} 
                  alt="QR Code" 
                  className="w-64 h-64"
                />
              </div>
              <p className="text-sm text-gray-500 mt-4 text-center">
                Scan this QR code to visit the {entityType === 'project' ? 'service activity' : 'event'} page
              </p>
              <Button onClick={handleDownloadQR} className="mt-4">
                <Download className="w-4 h-4 mr-2" />
                Download QR Code
              </Button>
            </div>
          </TabsContent>

          {/* Poster Generator */}
          <TabsContent value="poster" className="space-y-4">
            <div className="flex justify-center gap-2 mb-4">
              <Button 
                variant={posterSize === 'square' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setPosterSize('square')}
              >
                Square (1:1)
              </Button>
              <Button 
                variant={posterSize === 'portrait' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setPosterSize('portrait')}
              >
                Portrait (4:5)
              </Button>
              <Button 
                variant={posterSize === 'story' ? 'default' : 'outline'} 
                size="sm"
                onClick={() => setPosterSize('story')}
              >
                Story (9:16)
              </Button>
            </div>

            {/* Poster Preview */}
            <div className={`mx-auto bg-gradient-to-br from-blue-900 to-blue-800 rounded-lg overflow-hidden shadow-xl ${
              posterSize === 'square' ? 'w-80 h-80' : 
              posterSize === 'portrait' ? 'w-72 h-96' : 
              'w-56 h-96'
            }`}>
              <div className="h-full flex flex-col p-6 text-white relative">
                {/* Logo */}
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-8 h-8 bg-yellow-400 rounded-full flex items-center justify-center">
                    <span className="text-blue-900 font-bold text-xs">L</span>
                  </div>
                  <span className="text-xs font-medium">Lions Club Baroda Rising Star</span>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold leading-tight mb-2">{entity.name}</h3>
                
                {/* Description */}
                <p className="text-sm text-blue-200 line-clamp-3 mb-4">
                  {entity.description}
                </p>

                {/* Details */}
                <div className="space-y-1 text-xs text-blue-300 mb-4">
                  {'location' in entity && <p>📍 {entity.location}</p>}
                  <p>📅 {new Date(entity.startDate).toLocaleDateString()}</p>
                </div>

                {/* QR Code */}
                <div className="mt-auto flex items-end justify-between">
                  <div className="bg-white p-2 rounded">
                    <img src={qrCodeUrl} alt="QR" className="w-16 h-16" />
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-blue-300">Scan to learn more</p>
                    <p className="text-xs text-yellow-400 font-medium">#WeServe</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-2 justify-center">
              <Button 
                className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-blue-900 font-bold"
                onClick={() => toast.success('Poster downloaded!')}
              >
                <Download className="w-4 h-4 mr-2" />
                Download Poster
              </Button>
            </div>
          </TabsContent>

          {/* Embed Code */}
          <TabsContent value="embed" className="space-y-4">
            <div className="space-y-2">
              <Label>Embed Dimensions</Label>
              <div className="flex gap-4">
                <div className="flex-1">
                  <Label className="text-xs">Width (px)</Label>
                  <Input 
                    type="number" 
                    value={embedWidth} 
                    onChange={(e) => setEmbedWidth(parseInt(e.target.value))}
                  />
                </div>
                <div className="flex-1">
                  <Label className="text-xs">Height (px)</Label>
                  <Input 
                    type="number" 
                    value={embedHeight} 
                    onChange={(e) => setEmbedHeight(parseInt(e.target.value))}
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label>HTML Embed Code</Label>
              <Textarea 
                value={embedCode}
                readOnly
                className="font-mono text-sm min-h-[100px]"
              />
              <Button onClick={() => handleCopy(embedCode)} className="w-full">
                <Code className="w-4 h-4 mr-2" />
                Copy Embed Code
              </Button>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <Label className="text-sm font-medium">Preview</Label>
              <div className="mt-2 border rounded bg-white p-2">
                <div 
                  className="bg-gray-100 flex items-center justify-center text-gray-400"
                  style={{ width: '100%', height: '150px' }}
                >
                  <div className="text-center">
                    <ExternalLink className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm">Embedded {entityType} will appear here</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
