// ============================================
// ZONE CHAIRPERSON CONTROL SYSTEM - DATABASE SCHEMA
// Multi-Club Management with Full Automation
// ============================================

// ===== ZONE STRUCTURE =====
export interface Zone {
  id: string;
  zoneCode: string;
  zoneName: string;
  districtId: string;
  regionId: string;
  chairpersonId: string;
  clubs: string[]; // Club IDs
  meetingSchedule: ZoneMeetingSchedule;
  createdAt: string;
  updatedAt: string;
}

export interface ZoneMeetingSchedule {
  day: string;
  time: string;
  venue: string;
  frequency: 'Monthly' | 'Bi-Monthly' | 'Quarterly';
}

// ===== CLUB STRUCTURE (Extended) =====
export interface Club {
  id: string;
  clubNumber: string;
  clubName: string;
  charterDate: string;
  zoneId: string;
  districtId: string;
  regionId: string;
  
  // Club Officers
  officers: ClubOfficers;
  
  // Meeting Details
  meetingInfo: ClubMeetingInfo;
  
  // Contact
  email: string;
  phone: string;
  website?: string;
  address: Address;
  
  // Social Media
  socialMedia: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    youtube?: string;
  };
  
  // Statistics
  stats: ClubStatistics;
  
  // Lions Portal Credentials
  lionsPortal?: {
    username: string;
    lastSync: string;
    syncStatus: 'synced' | 'pending' | 'failed';
  };
  
  createdAt: string;
  updatedAt: string;
}

export interface ClubOfficers {
  president: Officer;
  vicePresident: Officer;
  secretary: Officer;
  treasurer: Officer;
  jointSecretary?: Officer;
  directors: Officer[];
  lionTamer?: Officer;
  tailTwister?: Officer;
}

export interface Officer {
  memberId: string;
  name: string;
  email: string;
  phone: string;
  designation: string;
  photo?: string;
  tenureStart: string;
  tenureEnd: string;
}

export interface ClubMeetingInfo {
  day: string;
  time: string;
  venue: string;
  frequency: 'Weekly' | 'Bi-Weekly' | 'Monthly';
  nextMeetingDate: string;
}

export interface ClubStatistics {
  totalMembers: number;
  activeMembers: number;
  newMembersThisYear: number;
  serviceActivities: number;
  volunteerHours: number;
  fundsRaised: number;
  beneficiariesServed: number;
}

export interface Address {
  street: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
}

// ===== ATTENDANCE SYSTEM =====
export interface AttendanceRecord {
  id: string;
  clubId: string;
  meetingType: 'Club Meeting' | 'Board Meeting' | 'Zone Meeting' | 'District Event';
  meetingDate: string;
  meetingNumber: number;
  
  // Attendees
  attendees: Attendee[];
  
  // Absentees with reason
  absentees: Absentee[];
  
  // Meeting Details
  agenda: string[];
  decisions: string[];
  actionItems: ActionItem[];
  
  // Statistics
  totalMembers: number;
  presentCount: number;
  absentCount: number;
  attendancePercentage: number;
  
  // Photos
  photos: string[];
  
  // Submitted by
  submittedBy: string;
  submittedAt: string;
  
  // Zone Chairperson Review
  reviewedBy?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  
  createdAt: string;
}

export interface Attendee {
  memberId: string;
  name: string;
  designation: string;
  checkInTime: string;
  signature?: string;
}

export interface Absentee {
  memberId: string;
  name: string;
  designation: string;
  reason: 'Sick' | 'Out of Town' | 'Work' | 'Personal' | 'No Response' | 'Other';
  otherReason?: string;
  informedBefore: boolean;
}

export interface ActionItem {
  id: string;
  description: string;
  assignedTo: string;
  deadline: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  completedAt?: string;
}

// ===== ADVISORY SYSTEM =====
export interface Advisory {
  id: string;
  type: AdvisoryType;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  
  // Target
  targetType: 'Club' | 'Officer' | 'Zone';
  targetId: string;
  
  // Content
  subject: string;
  message: string;
  recommendations: string[];
  
  // Related Data
  relatedMetrics?: AdvisoryMetrics;
  
  // Status
  status: 'Draft' | 'Sent' | 'Read' | 'Acknowledged' | 'Implemented';
  
  // Tracking
  sentAt?: string;
  readAt?: string;
  acknowledgedAt?: string;
  implementedAt?: string;
  
  // Response
  response?: AdvisoryResponse;
  
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export type AdvisoryType = 
  | 'Attendance Improvement'
  | 'Membership Growth'
  | 'Service Activity'
  | 'Fundraising'
  | 'Reporting'
  | 'Leadership'
  | 'Compliance'
  | 'Recognition'
  | 'General';

export interface AdvisoryMetrics {
  currentAttendance?: number;
  targetAttendance?: number;
  currentMembership?: number;
  targetMembership?: number;
  serviceActivitiesCount?: number;
  fundsRaised?: number;
}

export interface AdvisoryResponse {
  acknowledgedBy: string;
  acknowledgedAt: string;
  actionPlan: string;
  timeline: string;
  supportNeeded?: string;
}

// ===== AUTOMATED REPORTS =====
export interface AutomatedReport {
  id: string;
  reportType: ReportType;
  clubId?: string;
  zoneId: string;
  
  // Period
  period: {
    startDate: string;
    endDate: string;
    month?: number;
    year: number;
    quarter?: number;
  };
  
  // Data
  data: ReportData;
  
  // Status
  status: 'Generating' | 'Ready' | 'Submitted' | 'Approved';
  
  // Lions Portal
  lionsPortalStatus?: 'Not Submitted' | 'Submitted' | 'Approved' | 'Rejected';
  lionsPortalSubmissionId?: string;
  lionsPortalSubmittedAt?: string;
  
  // PDF
  pdfUrl?: string;
  generatedAt?: string;
  
  createdAt: string;
  updatedAt: string;
}

export type ReportType = 
  | 'Monthly Club Report'
  | 'Quarterly Zone Report'
  | 'Annual Report'
  | 'Service Activity Report'
  | 'Membership Report'
  | 'Attendance Report'
  | 'Financial Report'
  | 'Social Impact Report';

export interface ReportData {
  // Membership
  membership: {
    totalMembers: number;
    newMembers: number;
    droppedMembers: number;
    netGrowth: number;
    attendanceAverage: number;
  };
  
  // Service Activities
  serviceActivities: {
    total: number;
    byCategory: Record<string, number>;
    volunteerHours: number;
    beneficiaries: number;
    fundsUtilized: number;
  };
  
  // Fundraising
  fundraising: {
    totalRaised: number;
    bySource: Record<string, number>;
    expenses: number;
    netBalance: number;
  };
  
  // Recognition
  recognition: {
    awardsReceived: string[];
    mediaCoverage: MediaCoverage[];
    testimonials: Testimonial[];
  };
}

export interface MediaCoverage {
  id: string;
  type: 'Newspaper' | 'TV' | 'Radio' | 'Online' | 'Social Media';
  outlet: string;
  title: string;
  date: string;
  url?: string;
  image?: string;
}

export interface Testimonial {
  id: string;
  beneficiaryName: string;
  beneficiaryType: 'Individual' | 'Organization' | 'Community';
  testimonial: string;
  photo?: string;
  video?: string;
  date: string;
}

// ===== SOCIAL IMPACT REPORTING =====
export interface SocialImpactReport {
  id: string;
  clubId: string;
  zoneId: string;
  
  // Period
  period: {
    startDate: string;
    endDate: string;
    year: number;
  };
  
  // Impact Metrics
  impact: SocialImpactMetrics;
  
  // Stories
  successStories: SuccessStory[];
  
  // Visuals
  photos: string[];
  videos: string[];
  infographics: string[];
  
  // Generated PDF
  pdfUrl?: string;
  generatedAt?: string;
  
  createdAt: string;
  updatedAt: string;
}

export interface SocialImpactMetrics {
  // People
  totalBeneficiaries: number;
  directBeneficiaries: number;
  indirectBeneficiaries: number;
  
  // Categories
  byCategory: {
    healthcare: ImpactCategory;
    education: ImpactCategory;
    environment: ImpactCategory;
    hunger: ImpactCategory;
    disaster: ImpactCategory;
    youth: ImpactCategory;
    senior: ImpactCategory;
    eyeCare: ImpactCategory;
    other: ImpactCategory;
  };
  
  // Resources
  volunteerHours: number;
  fundsUtilized: number;
  inKindDonations: number;
  
  // Outcomes
  livesImproved: number;
  communitiesServed: number;
  sustainabilityScore: number;
}

export interface ImpactCategory {
  activities: number;
  beneficiaries: number;
  volunteerHours: number;
  fundsUtilized: number;
}

export interface SuccessStory {
  id: string;
  title: string;
  description: string;
  beneficiaryName: string;
  beneficiaryPhoto?: string;
  beforePhoto?: string;
  afterPhoto?: string;
  quote: string;
  date: string;
  location: string;
  volunteers: string[];
}

// ===== ZONE DASHBOARD STATS =====
export interface ZoneDashboardStats {
  // Overview
  totalClubs: number;
  totalMembers: number;
  totalServiceActivities: number;
  totalVolunteerHours: number;
  totalFundsRaised: number;
  totalBeneficiaries: number;
  
  // Club Performance
  clubRankings: ClubRanking[];
  
  // Attendance
  attendanceTrend: MonthlyAttendance[];
  averageAttendance: number;
  
  // Membership
  membershipTrend: MonthlyMembership[];
  membershipGrowth: number;
  
  // Service Activities
  activitiesByCategory: CategoryBreakdown[];
  activitiesByMonth: MonthlyActivities[];
  
  // Alerts
  alerts: ZoneAlert[];
  
  // Pending Actions
  pendingReports: number;
  pendingAdvisories: number;
  pendingApprovals: number;
}

export interface ClubRanking {
  clubId: string;
  clubName: string;
  clubNumber: string;
  rank: number;
  score: number;
  metrics: {
    attendance: number;
    membership: number;
    service: number;
    fundraising: number;
    reporting: number;
  };
}

export interface MonthlyAttendance {
  month: string;
  year: number;
  averageAttendance: number;
  totalMeetings: number;
}

export interface MonthlyMembership {
  month: string;
  year: number;
  totalMembers: number;
  newMembers: number;
  droppedMembers: number;
}

export interface CategoryBreakdown {
  category: string;
  activities: number;
  beneficiaries: number;
  volunteerHours: number;
}

export interface MonthlyActivities {
  month: string;
  year: number;
  activities: number;
  beneficiaries: number;
}

export interface ZoneAlert {
  id: string;
  type: 'Attendance' | 'Membership' | 'Reporting' | 'Compliance' | 'General';
  severity: 'Info' | 'Warning' | 'Critical';
  clubId?: string;
  clubName?: string;
  message: string;
  actionRequired: string;
  createdAt: string;
}

// ===== LIONS PORTAL INTEGRATION =====
export interface LionsPortalSubmission {
  id: string;
  reportId: string;
  reportType: string;
  clubId: string;
  
  // Submission Data
  data: Record<string, any>;
  
  // Status
  status: 'Draft' | 'Ready' | 'Submitted' | 'Approved' | 'Rejected';
  
  // Submission Details
  submittedAt?: string;
  submittedBy?: string;
  submissionReference?: string;
  
  // Response
  responseMessage?: string;
  responseDate?: string;
  
  createdAt: string;
  updatedAt: string;
}

// ===== NOTIFICATION SYSTEM =====
export interface Notification {
  id: string;
  type: 'Advisory' | 'Report' | 'Attendance' | 'Alert' | 'System';
  priority: 'Low' | 'Medium' | 'High';
  
  recipientType: 'ZoneChairperson' | 'ClubOfficer' | 'Member';
  recipientId: string;
  
  title: string;
  message: string;
  
  // Action
  actionUrl?: string;
  actionText?: string;
  
  // Status
  isRead: boolean;
  readAt?: string;
  
  createdAt: string;
}
