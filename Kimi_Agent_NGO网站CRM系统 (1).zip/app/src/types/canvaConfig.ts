// ============================================
// CANVA INTEGRATION CONFIGURATION
// ============================================

export interface CanvaConfig {
  // API Configuration
  enabled: boolean;
  apiKey?: string;
  partnerId?: string;
  
  // Design Templates
  templates: CanvaTemplate[];
  
  // Export Settings
  exportSettings: CanvaExportSettings;
  
  // Feature Toggles
  features: CanvaFeatures;
  
  // Brand Kit (for consistent branding)
  brandKit?: CanvaBrandKit;
}

export interface CanvaTemplate {
  id: string;
  name: string;
  description: string;
  category: 'social' | 'poster' | 'flyer' | 'banner' | 'presentation' | 'custom';
  thumbnailUrl: string;
  canvaTemplateId?: string;
  defaultDimensions: {
    width: number;
    height: number;
    unit: 'px' | 'in' | 'mm';
  };
  editableElements: string[];
  prefillData?: Record<string, any>;
}

export interface CanvaExportSettings {
  defaultFormat: 'png' | 'jpg' | 'pdf' | 'mp4';
  defaultQuality: 'low' | 'medium' | 'high';
  allowMultipleFormats: boolean;
  autoDownload: boolean;
  saveToCRM: boolean;
}

export interface CanvaFeatures {
  enableDesignButton: boolean;
  enableTemplates: boolean;
  enableBrandKit: boolean;
  enableCollaboration: boolean;
  enableComments: boolean;
  enableVersionHistory: boolean;
}

export interface CanvaBrandKit {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    text: string;
    background: string;
  };
  fonts: {
    heading: string;
    body: string;
    accent: string;
  };
  logos: {
    main: string;
    white: string;
    icon: string;
  };
  patterns?: string[];
}

export interface CanvaDesign {
  id: string;
  title: string;
  description?: string;
  canvaDesignId?: string;
  canvaEditUrl?: string;
  canvaViewUrl?: string;
  thumbnailUrl?: string;
  
  // Related to CRM entity
  entityType: 'project' | 'event' | 'campaign' | 'member' | 'general';
  entityId?: string;
  
  // Design metadata
  templateId?: string;
  dimensions: {
    width: number;
    height: number;
  };
  
  // Export files
  exports: CanvaExport[];
  
  // Status
  status: 'draft' | 'in_review' | 'approved' | 'published';
  
  // Collaboration
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  collaborators: string[];
  version: number;
}

export interface CanvaExport {
  id: string;
  format: 'png' | 'jpg' | 'pdf' | 'mp4';
  quality: string;
  url: string;
  fileSize: number;
  dimensions: {
    width: number;
    height: number;
  };
  exportedAt: string;
  exportedBy: string;
}

// Default configuration for Lions Club
export const defaultCanvaConfig: CanvaConfig = {
  enabled: true,
  templates: [
    {
      id: 'social-square',
      name: 'Social Media Post (Square)',
      description: 'Perfect for Instagram and Facebook posts',
      category: 'social',
      thumbnailUrl: '/templates/social-square.jpg',
      defaultDimensions: { width: 1080, height: 1080, unit: 'px' },
      editableElements: ['title', 'description', 'date', 'location', 'image', 'logo'],
      prefillData: {
        logo: '/logo.png',
        hashtag: '#LionsClub #WeServe'
      }
    },
    {
      id: 'social-story',
      name: 'Instagram Story',
      description: 'Vertical format for Instagram and Facebook Stories',
      category: 'social',
      thumbnailUrl: '/templates/social-story.jpg',
      defaultDimensions: { width: 1080, height: 1920, unit: 'px' },
      editableElements: ['title', 'description', 'date', 'image', 'logo', 'cta'],
      prefillData: {
        logo: '/logo.png',
        cta: 'Swipe up to learn more'
      }
    },
    {
      id: 'event-poster',
      name: 'Event Poster',
      description: 'Professional poster for club events',
      category: 'poster',
      thumbnailUrl: '/templates/event-poster.jpg',
      defaultDimensions: { width: 24, height: 36, unit: 'in' },
      editableElements: ['eventName', 'date', 'time', 'venue', 'description', 'contact', 'image', 'logo'],
      prefillData: {
        logo: '/logo.png',
        clubName: 'Lions Club of Baroda Rising Star'
      }
    },
    {
      id: 'service-flyer',
      name: 'Service Activity Flyer',
      description: 'Promote your service activities',
      category: 'flyer',
      thumbnailUrl: '/templates/service-flyer.jpg',
      defaultDimensions: { width: 8.5, height: 11, unit: 'in' },
      editableElements: ['title', 'description', 'impact', 'images', 'logo', 'contact'],
      prefillData: {
        logo: '/logo.png',
        tagline: 'We Serve'
      }
    },
    {
      id: 'banner-web',
      name: 'Website Banner',
      description: 'Banner for website headers',
      category: 'banner',
      thumbnailUrl: '/templates/banner-web.jpg',
      defaultDimensions: { width: 1920, height: 600, unit: 'px' },
      editableElements: ['headline', 'subheadline', 'cta', 'image', 'logo'],
      prefillData: {
        logo: '/logo.png'
      }
    },
    {
      id: 'presentation',
      name: 'Club Presentation',
      description: 'Professional presentation template',
      category: 'presentation',
      thumbnailUrl: '/templates/presentation.jpg',
      defaultDimensions: { width: 1920, height: 1080, unit: 'px' },
      editableElements: ['title', 'content', 'images', 'charts', 'logo'],
      prefillData: {
        logo: '/logo.png',
        clubName: 'Lions Club of Baroda Rising Star'
      }
    }
  ],
  exportSettings: {
    defaultFormat: 'png',
    defaultQuality: 'high',
    allowMultipleFormats: true,
    autoDownload: true,
    saveToCRM: true
  },
  features: {
    enableDesignButton: true,
    enableTemplates: true,
    enableBrandKit: true,
    enableCollaboration: false,
    enableComments: true,
    enableVersionHistory: true
  },
  brandKit: {
    colors: {
      primary: '#1e40af',    // Lions Blue
      secondary: '#fbbf24',  // Lions Gold
      accent: '#dc2626',     // Accent Red
      text: '#1f2937',       // Dark Gray
      background: '#ffffff'  // White
    },
    fonts: {
      heading: 'Montserrat',
      body: 'Open Sans',
      accent: 'Playfair Display'
    },
    logos: {
      main: '/logo.png',
      white: '/logo-white.png',
      icon: '/logo-icon.png'
    }
  }
};

// Canva API endpoints (when API key is available)
export const CANVA_API_ENDPOINTS = {
  design: 'https://api.canva.com/v1/designs',
  template: 'https://api.canva.com/v1/templates',
  export: 'https://api.canva.com/v1/exports',
  brand: 'https://api.canva.com/v1/brand',
  user: 'https://api.canva.com/v1/users'
};

// Canva Embed URL patterns
export const CANVA_EMBED_URLS = {
  // For opening Canva editor with a template
  editor: (designId?: string) => designId 
    ? `https://www.canva.com/design/${designId}/edit`
    : 'https://www.canva.com/design',
  
  // For viewing a design
  viewer: (designId: string) => `https://www.canva.com/design/${designId}/view`,
  
  // For embedding a design (iframe)
  embed: (designId: string) => `https://www.canva.com/design/${designId}/view?embed`,
  
  // For template selection
  templates: 'https://www.canva.com/templates/?search=lions+club'
};
