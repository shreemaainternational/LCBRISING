// ============================================
// LIONS CLUB AI CRM - DATABASE SCHEMA
// Professional NGO CRM with AI Features
// ============================================

// ===== MEMBER SYSTEM =====
export interface Member {
  id: string;
  memberId: string;
  firstName: string;
  middleName?: string;
  lastName: string;
  email: string;
  phone: string;
  whatsapp?: string;
  dateOfBirth: string;
  joinDate: string;
  designation: MemberDesignation;
  status: MemberStatus;
  membershipType: MembershipType;
  membershipCategory: string;
  address: Address;
  emergencyContact: EmergencyContact;
  profileImage?: string;
  bloodGroup?: string;
  occupation: string;
  companyName?: string;
  gender?: string;
  spouseName?: string;
  skills: string[];
  interests: string[];
  committeeRoles: CommitteeRole[];
  attendance: AttendanceRecord[];
  dues: MemberDues[];
  volunteerHours: number;
  totalDonations: number;
  lastActivityDate?: string;
  engagementScore: number; // AI-calculated 0-100
  tags: string[]; // For segmentation
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type MemberDesignation = 
  | 'President'
  | 'Vice President'
  | 'Secretary'
  | 'Treasurer'
  | 'Joint Secretary'
  | 'Director'
  | 'Member'
  | 'Probationary Member'
  | 'Honorary Member';

export type MemberStatus = 'Active' | 'Inactive' | 'Suspended' | 'Resigned' | 'Deceased';

export type MembershipType = 'Regular' | 'Family' | 'Life' | 'Honorary' | 'Associate';

export interface Address {
  street: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface CommitteeRole {
  committeeId: string;
  committeeName: string;
  role: string;
  startDate: string;
  endDate?: string;
}

export interface AttendanceRecord {
  eventId: string;
  eventName: string;
  date: string;
  status: 'Present' | 'Absent' | 'Excused';
}

export interface MemberDues {
  year: number;
  amount: number;
  paid: boolean;
  paidDate?: string;
  paymentMethod?: string;
}

// ===== DONOR & DONATION SYSTEM =====
export interface Donor {
  id: string;
  memberId?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address?: Address;
  donorType: DonorType;
  donorSegment: DonorSegment; // AI-segmented
  lifetimeValue: number;
  totalDonations: number;
  donationCount: number;
  firstDonationDate?: string;
  lastDonationDate?: string;
  preferredCategory?: string;
  communicationPreference: ('email' | 'sms' | 'whatsapp' | 'call')[];
  isRecurring: boolean;
  recurringAmount?: number;
  engagementScore: number;
  churnRisk: 'low' | 'medium' | 'high'; // AI prediction
  nextPredictedDonation?: string; // AI prediction
  tags: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type DonorType = 'Individual' | 'Corporate' | 'Foundation' | 'Anonymous';

export type DonorSegment = 'Major' | 'Regular' | 'Occasional' | 'Lapsed' | 'New' | 'VIP';

export interface Donation {
  id: string;
  donorId?: string;
  donorName: string;
  donorEmail: string;
  donorPhone: string;
  amount: number;
  currency: string;
  donationType: DonationType;
  category: DonationCategory;
  projectId?: string;
  campaignId?: string;
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;
  transactionId?: string;
  receiptNumber: string;
  isAnonymous: boolean;
  message?: string;
  taxCertificateIssued: boolean;
  taxCertificateNumber?: string;
  acknowledgmentSent: boolean;
  createdAt: string;
  updatedAt: string;
}

export type DonationType = 'One-Time' | 'Monthly' | 'Quarterly' | 'Annual' | 'In-Kind';

export type DonationCategory = 
  | 'General Fund'
  | 'Education'
  | 'Healthcare'
  | 'Environment'
  | 'Disaster Relief'
  | 'Community Development'
  | 'Youth Programs'
  | 'Senior Care'
  | 'Eye Care'
  | 'Hunger Relief'
  | 'Specific Project';

export type PaymentMethod = 'Credit Card' | 'Debit Card' | 'Net Banking' | 'UPI' | 'Cash' | 'Cheque' | 'Bank Transfer' | 'PayPal';

export type PaymentStatus = 'Pending' | 'Completed' | 'Failed' | 'Refunded' | 'Cancelled';

// ===== VOLUNTEER SYSTEM =====
export interface Volunteer {
  id: string;
  memberId?: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  whatsapp?: string;
  dateOfBirth?: string;
  address: Address;
  skills: string[];
  interests: string[];
  availability: VolunteerAvailability;
  totalHours: number;
  eventsParticipated: number;
  status: VolunteerStatus;
  backgroundVerified: boolean;
  emergencyContact: EmergencyContact;
  joinDate: string;
  lastActivityDate?: string;
  badges: VolunteerBadge[];
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export type VolunteerStatus = 'Active' | 'Inactive' | 'OnHold' | 'Blacklisted';

export interface VolunteerAvailability {
  weekdays: boolean;
  weekends: boolean;
  mornings: boolean;
  afternoons: boolean;
  evenings: boolean;
}

export interface VolunteerBadge {
  name: string;
  description: string;
  awardedAt: string;
  icon: string;
}

// ===== PROJECT/ACTIVITY SYSTEM =====
export interface Project {
  id: string;
  projectCode: string;
  name: string;
  description: string;
  category: ProjectCategory;
  status: ProjectStatus;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  startDate: string;
  endDate?: string;
  budget: number;
  spent: number;
  location: string;
  beneficiaries: number;
  coordinatorId: string;
  teamMembers: string[];
  volunteers: string[];
  milestones: Milestone[];
  images: string[];
  documents: ProjectDocument[];
  reports: ProjectReport[];
  donations: string[];
  volunteerHours: number;
  impactMetrics: ImpactMetric[];
  createdAt: string;
  updatedAt: string;
}

export type ProjectCategory = 
  | 'Community Service'
  | 'Healthcare'
  | 'Education'
  | 'Environment'
  | 'Disaster Relief'
  | 'Youth'
  | 'Senior Care'
  | 'Eye Care'
  | 'Hunger'
  | 'Fundraising';

export type ProjectStatus = 'Planned' | 'In Progress' | 'Completed' | 'Cancelled' | 'On Hold';

export interface Milestone {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  completed: boolean;
  completedAt?: string;
}

export interface ImpactMetric {
  name: string;
  target: number;
  achieved: number;
  unit: string;
}

export interface ProjectDocument {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadedAt: string;
  uploadedBy: string;
}

export interface ProjectReport {
  id: string;
  title: string;
  content: string;
  submittedBy: string;
  submittedAt: string;
  images: string[];
}

// ===== EVENT SYSTEM =====
export interface Event {
  id: string;
  eventCode: string;
  name: string;
  description: string;
  type: EventType;
  status: EventStatus;
  startDate: string;
  endDate: string;
  venue: string;
  address: string;
  maxAttendees?: number;
  organizerId: string;
  attendees: EventAttendee[];
  volunteers: string[];
  budget: number;
  actualCost: number;
  images: string[];
  agenda: AgendaItem[];
  registrationOpen: boolean;
  registrationDeadline?: string;
  createdAt: string;
  updatedAt: string;
}

export type EventType = 
  | 'General Meeting'
  | 'Board Meeting'
  | 'Committee Meeting'
  | 'Fundraising Event'
  | 'Community Service'
  | 'Social Event'
  | 'Training'
  | 'Installation'
  | 'Charter Night'
  | 'District Event';

export type EventStatus = 'Draft' | 'Published' | 'Registration Open' | 'Registration Closed' | 'Ongoing' | 'Completed' | 'Cancelled';

export interface EventAttendee {
  memberId: string;
  name: string;
  email: string;
  status: 'Registered' | 'Confirmed' | 'Attended' | 'No Show' | 'Cancelled';
  registeredAt: string;
}

export interface AgendaItem {
  id: string;
  time: string;
  title: string;
  description?: string;
  presenter?: string;
}

// ===== CAMPAIGN SYSTEM =====
export interface Campaign {
  id: string;
  campaignCode: string;
  name: string;
  description: string;
  type: CampaignType;
  status: CampaignStatus;
  goal: number;
  raised: number;
  donorCount: number;
  startDate: string;
  endDate: string;
  targetAudience: string[];
  channels: CampaignChannel[];
  content: CampaignContent[];
  metrics: CampaignMetrics;
  createdAt: string;
  updatedAt: string;
}

export type CampaignType = 'Fundraising' | 'Awareness' | 'Recruitment' | 'Event Promotion';

export type CampaignStatus = 'Draft' | 'Scheduled' | 'Active' | 'Paused' | 'Completed';

export interface CampaignChannel {
  channel: 'email' | 'sms' | 'whatsapp' | 'social' | 'website';
  status: 'pending' | 'sent' | 'failed';
  sentAt?: string;
  metrics: { opens?: number; clicks?: number; conversions?: number };
}

export interface CampaignContent {
  type: 'subject' | 'body' | 'image' | 'cta';
  content: string;
  variant?: 'A' | 'B'; // For A/B testing
}

export interface CampaignMetrics {
  impressions: number;
  clicks: number;
  conversions: number;
  conversionRate: number;
}

// ===== AUTOMATION SYSTEM =====
export interface Automation {
  id: string;
  name: string;
  description: string;
  trigger: AutomationTrigger;
  conditions: AutomationCondition[];
  actions: AutomationAction[];
  status: 'active' | 'paused' | 'draft';
  runCount: number;
  lastRun?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AutomationTrigger {
  type: 'event' | 'schedule' | 'condition';
  event?: string;
  schedule?: string;
  condition?: string;
}

export interface AutomationCondition {
  field: string;
  operator: 'equals' | 'not_equals' | 'greater_than' | 'less_than' | 'contains';
  value: string | number;
}

export interface AutomationAction {
  type: 'send_email' | 'send_sms' | 'send_whatsapp' | 'add_tag' | 'create_task' | 'update_field';
  config: Record<string, any>;
}

// ===== COMMUNICATION SYSTEM =====
export interface Communication {
  id: string;
  type: 'email' | 'sms' | 'whatsapp';
  recipientId: string;
  recipientType: 'member' | 'donor' | 'volunteer';
  subject?: string;
  content: string;
  status: 'queued' | 'sent' | 'delivered' | 'failed' | 'read';
  sentAt?: string;
  deliveredAt?: string;
  readAt?: string;
  templateId?: string;
  campaignId?: string;
  createdAt: string;
}

export interface MessageTemplate {
  id: string;
  name: string;
  type: 'email' | 'sms' | 'whatsapp';
  subject?: string;
  content: string;
  variables: string[];
  category: string;
  usageCount: number;
  createdAt: string;
  updatedAt: string;
}

// ===== FINANCIAL SYSTEM =====
export interface FinancialTransaction {
  id: string;
  transactionCode: string;
  date: string;
  type: TransactionType;
  category: string;
  amount: number;
  description: string;
  reference?: string;
  projectId?: string;
  eventId?: string;
  approvedBy: string;
  attachments: string[];
  createdAt: string;
}

export type TransactionType = 'Income' | 'Expense';

export interface Budget {
  id: string;
  year: number;
  totalBudget: number;
  categories: BudgetCategory[];
  createdAt: string;
  updatedAt: string;
}

export interface BudgetCategory {
  name: string;
  allocated: number;
  spent: number;
}

// ===== ANNOUNCEMENT SYSTEM =====
export interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'General' | 'Urgent' | 'Meeting' | 'Event' | 'Project' | 'Achievement';
  postedBy: string;
  postedAt: string;
  expiresAt?: string;
  isPinned: boolean;
  targetAudience: string[];
  attachments: string[];
  readBy: string[];
}

// ===== USER/AUTHENTICATION SYSTEM =====
export interface User {
  id: string;
  memberId?: string;
  email: string;
  passwordHash: string;
  role: UserRole;
  permissions: Permission[];
  lastLogin?: string;
  loginAttempts: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export type UserRole = 'Super Admin' | 'Admin' | 'President' | 'Secretary' | 'Treasurer' | 'Member' | 'Volunteer Coordinator';

export type Permission = 
  | 'members.view' | 'members.create' | 'members.edit' | 'members.delete' | 'members.export'
  | 'donors.view' | 'donors.create' | 'donors.edit' | 'donors.delete'
  | 'donations.view' | 'donations.create' | 'donations.edit' | 'donations.delete'
  | 'projects.view' | 'projects.create' | 'projects.edit' | 'projects.delete'
  | 'events.view' | 'events.create' | 'events.edit' | 'events.delete'
  | 'volunteers.view' | 'volunteers.create' | 'volunteers.edit' | 'volunteers.delete'
  | 'campaigns.view' | 'campaigns.create' | 'campaigns.edit' | 'campaigns.delete'
  | 'finance.view' | 'finance.create' | 'finance.edit' | 'finance.delete'
  | 'reports.view' | 'reports.create' | 'reports.export'
  | 'automation.view' | 'automation.create' | 'automation.edit' | 'automation.delete'
  | 'settings.view' | 'settings.edit'
  | 'announcements.manage';

// ===== AUDIT LOG =====
export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  entityType: string;
  entityId: string;
  oldValue?: string;
  newValue?: string;
  ipAddress?: string;
  timestamp: string;
}

// ===== DASHBOARD STATS =====
export interface DashboardStats {
  // Member Stats
  totalMembers: number;
  activeMembers: number;
  newMembersThisMonth: number;
  memberGrowthRate: number;
  
  // Donation Stats
  totalDonations: number;
  donationsThisMonth: number;
  donationsThisYear: number;
  averageDonation: number;
  recurringDonors: number;
  
  // Donor Stats
  totalDonors: number;
  donorRetentionRate: number;
  donorChurnRisk: number;
  
  // Project Stats
  totalProjects: number;
  activeProjects: number;
  completedProjects: number;
  projectsThisMonth: number;
  
  // Event Stats
  totalEvents: number;
  upcomingEvents: number;
  eventsThisMonth: number;
  averageAttendance: number;
  
  // Volunteer Stats
  totalVolunteers: number;
  activeVolunteers: number;
  volunteerHoursThisMonth: number;
  
  // Impact Stats
  totalBeneficiaries: number;
  volunteerHours: number;
  
  // Financial Stats
  yearToDateIncome: number;
  yearToDateExpense: number;
  netBalance: number;
  
  // AI Insights
  predictedDonationsNextMonth: number;
  atRiskDonors: number;
  recommendedActions: AIRecommendation[];
  
  // Charts Data
  monthlyDonations: MonthlyStat[];
  donationByCategory: CategoryStat[];
  memberGrowth: GrowthStat[];
  recentDonations: Donation[];
  recentMembers: Member[];
  upcomingEventsList: Event[];
}

export interface MonthlyStat {
  month: string;
  donations: number;
  expenses: number;
  newMembers: number;
  volunteerHours: number;
}

export interface CategoryStat {
  category: string;
  amount: number;
  percentage: number;
}

export interface GrowthStat {
  date: string;
  members: number;
  donors: number;
}

export interface AIRecommendation {
  type: 'donation' | 'engagement' | 'retention' | 'event';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  action: string;
  expectedImpact: string;
}

// ===== LIONS CLUB SPECIFIC =====
export interface LionsClubInfo {
  clubName: string;
  clubNumber: string;
  charterDate: string;
  district: string;
  region: string;
  zone: string;
  meetingVenue: string;
  meetingDay: string;
  meetingTime: string;
  logo: string;
  website: string;
  email: string;
  phone: string;
  socialMedia: {
    facebook?: string;
    instagram?: string;
    linkedin?: string;
    youtube?: string;
  };
}

export interface DistrictReport {
  id: string;
  reportPeriod: string;
  projectsCompleted: number;
  serviceHours: number;
  donationsRaised: number;
  membersAdded: number;
  beneficiariesServed: number;
  submittedAt: string;
  submittedBy: string;
}

// ===== CSV EXPORT FORMATS =====
export interface LionsPortalCSV {
  memberId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  dateOfBirth: string;
  joinDate: string;
  designation: string;
  status: string;
  membershipType: string;
}

// ===== SHARING SYSTEM =====
export interface ShareLink {
  id: string;
  shortCode: string;
  originalUrl: string;
  entityType: 'project' | 'event' | 'campaign' | 'donation';
  entityId: string;
  qrCode: string;
  clickCount: number;
  createdAt: string;
  expiresAt?: string;
}

export interface ShareableContent {
  title: string;
  description: string;
  imageUrl?: string;
  url: string;
  hashtags: string[];
}

export interface PosterTemplate {
  id: string;
  name: string;
  layout: 'portrait' | 'square' | 'landscape';
  backgroundImage?: string;
  primaryColor: string;
  secondaryColor: string;
  showLogo: boolean;
  showQrCode: boolean;
  showDate: boolean;
  showLocation: boolean;
}

export interface SocialShareConfig {
  platform: 'facebook' | 'twitter' | 'linkedin' | 'whatsapp' | 'email' | 'copy';
  enabled: boolean;
  customMessage?: string;
}
