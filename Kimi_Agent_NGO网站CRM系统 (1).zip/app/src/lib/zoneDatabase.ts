// ============================================
// ZONE CHAIRPERSON CONTROL SYSTEM - DATABASE LAYER
// Multi-Club Management with Full Automation
// ============================================

import { generateId } from './database';
import type { 
  Zone, Club, AttendanceRecord, Advisory, AutomatedReport,
  SocialImpactReport, ZoneDashboardStats, Notification,
  ZoneAlert, ClubRanking
} from '@/types/zoneDatabase';

// ===== LOCAL STORAGE KEYS =====
const STORAGE_KEYS = {
  zones: 'lions_zones',
  clubs: 'lions_clubs',
  attendance: 'lions_attendance',
  advisories: 'lions_advisories',
  reports: 'lions_reports',
  socialImpact: 'lions_social_impact',
  notifications: 'lions_notifications',
  currentZone: 'lions_current_zone',
};

// ===== ZONE DATABASE =====
export const zoneDB = {
  getAll: (): Zone[] => {
    const data = localStorage.getItem(STORAGE_KEYS.zones);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): Zone | null => {
    const zones = zoneDB.getAll();
    return zones.find(z => z.id === id) || null;
  },
  
  create: (zone: Zone): Zone => {
    const zones = zoneDB.getAll();
    zones.push(zone);
    localStorage.setItem(STORAGE_KEYS.zones, JSON.stringify(zones));
    return zone;
  },
  
  update: (id: string, updates: Partial<Zone>): Zone | null => {
    const zones = zoneDB.getAll();
    const index = zones.findIndex(z => z.id === id);
    if (index === -1) return null;
    zones[index] = { ...zones[index], ...updates, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.zones, JSON.stringify(zones));
    return zones[index];
  },
  
  delete: (id: string): boolean => {
    const zones = zoneDB.getAll();
    const filtered = zones.filter(z => z.id !== id);
    localStorage.setItem(STORAGE_KEYS.zones, JSON.stringify(filtered));
    return zones.length !== filtered.length;
  }
};

// ===== CLUB DATABASE =====
export const clubDB = {
  getAll: (): Club[] => {
    const data = localStorage.getItem(STORAGE_KEYS.clubs);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): Club | null => {
    const clubs = clubDB.getAll();
    return clubs.find(c => c.id === id) || null;
  },
  
  getByZone: (zoneId: string): Club[] => {
    const clubs = clubDB.getAll();
    return clubs.filter(c => c.zoneId === zoneId);
  },
  
  create: (club: Club): Club => {
    const clubs = clubDB.getAll();
    clubs.push(club);
    localStorage.setItem(STORAGE_KEYS.clubs, JSON.stringify(clubs));
    return club;
  },
  
  update: (id: string, updates: Partial<Club>): Club | null => {
    const clubs = clubDB.getAll();
    const index = clubs.findIndex(c => c.id === id);
    if (index === -1) return null;
    clubs[index] = { ...clubs[index], ...updates, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.clubs, JSON.stringify(clubs));
    return clubs[index];
  },
  
  delete: (id: string): boolean => {
    const clubs = clubDB.getAll();
    const filtered = clubs.filter(c => c.id !== id);
    localStorage.setItem(STORAGE_KEYS.clubs, JSON.stringify(filtered));
    return clubs.length !== filtered.length;
  }
};

// ===== ATTENDANCE DATABASE =====
export const attendanceDB = {
  getAll: (): AttendanceRecord[] => {
    const data = localStorage.getItem(STORAGE_KEYS.attendance);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): AttendanceRecord | null => {
    const records = attendanceDB.getAll();
    return records.find(r => r.id === id) || null;
  },
  
  getByClub: (clubId: string): AttendanceRecord[] => {
    const records = attendanceDB.getAll();
    return records.filter(r => r.clubId === clubId).sort((a, b) => 
      new Date(b.meetingDate).getTime() - new Date(a.meetingDate).getTime()
    );
  },
  
  getByZone: (zoneId: string): AttendanceRecord[] => {
    const clubs = clubDB.getByZone(zoneId);
    const clubIds = clubs.map(c => c.id);
    const records = attendanceDB.getAll();
    return records.filter(r => clubIds.includes(r.clubId));
  },
  
  create: (record: AttendanceRecord): AttendanceRecord => {
    const records = attendanceDB.getAll();
    records.push(record);
    localStorage.setItem(STORAGE_KEYS.attendance, JSON.stringify(records));
    return record;
  },
  
  update: (id: string, updates: Partial<AttendanceRecord>): AttendanceRecord | null => {
    const records = attendanceDB.getAll();
    const index = records.findIndex(r => r.id === id);
    if (index === -1) return null;
    records[index] = { ...records[index], ...updates };
    localStorage.setItem(STORAGE_KEYS.attendance, JSON.stringify(records));
    return records[index];
  },
  
  delete: (id: string): boolean => {
    const records = attendanceDB.getAll();
    const filtered = records.filter(r => r.id !== id);
    localStorage.setItem(STORAGE_KEYS.attendance, JSON.stringify(filtered));
    return records.length !== filtered.length;
  },
  
  // Get attendance statistics
  getStats: (clubId: string, startDate?: string, endDate?: string) => {
    let records = attendanceDB.getByClub(clubId);
    
    if (startDate) {
      records = records.filter(r => new Date(r.meetingDate) >= new Date(startDate));
    }
    if (endDate) {
      records = records.filter(r => new Date(r.meetingDate) <= new Date(endDate));
    }
    
    const totalMeetings = records.length;
    const averageAttendance = totalMeetings > 0 
      ? records.reduce((sum, r) => sum + r.attendancePercentage, 0) / totalMeetings 
      : 0;
    
    return {
      totalMeetings,
      averageAttendance: Math.round(averageAttendance * 10) / 10,
      records
    };
  }
};

// ===== ADVISORY DATABASE =====
export const advisoryDB = {
  getAll: (): Advisory[] => {
    const data = localStorage.getItem(STORAGE_KEYS.advisories);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): Advisory | null => {
    const advisories = advisoryDB.getAll();
    return advisories.find(a => a.id === id) || null;
  },
  
  getByClub: (clubId: string): Advisory[] => {
    const advisories = advisoryDB.getAll();
    return advisories.filter(a => a.targetId === clubId && a.targetType === 'Club')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getByZone: (zoneId: string): Advisory[] => {
    const advisories = advisoryDB.getAll();
    return advisories.filter(a => a.targetId === zoneId || a.targetType === 'Zone')
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getPending: (clubId?: string): Advisory[] => {
    const advisories = advisoryDB.getAll();
    let pending = advisories.filter(a => a.status !== 'Implemented');
    if (clubId) {
      pending = pending.filter(a => a.targetId === clubId);
    }
    return pending;
  },
  
  create: (advisory: Advisory): Advisory => {
    const advisories = advisoryDB.getAll();
    advisories.push(advisory);
    localStorage.setItem(STORAGE_KEYS.advisories, JSON.stringify(advisories));
    return advisory;
  },
  
  update: (id: string, updates: Partial<Advisory>): Advisory | null => {
    const advisories = advisoryDB.getAll();
    const index = advisories.findIndex(a => a.id === id);
    if (index === -1) return null;
    advisories[index] = { ...advisories[index], ...updates, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.advisories, JSON.stringify(advisories));
    return advisories[index];
  },
  
  delete: (id: string): boolean => {
    const advisories = advisoryDB.getAll();
    const filtered = advisories.filter(a => a.id !== id);
    localStorage.setItem(STORAGE_KEYS.advisories, JSON.stringify(filtered));
    return advisories.length !== filtered.length;
  }
};

// ===== REPORT DATABASE =====
export const reportDB = {
  getAll: (): AutomatedReport[] => {
    const data = localStorage.getItem(STORAGE_KEYS.reports);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): AutomatedReport | null => {
    const reports = reportDB.getAll();
    return reports.find(r => r.id === id) || null;
  },
  
  getByClub: (clubId: string): AutomatedReport[] => {
    const reports = reportDB.getAll();
    return reports.filter(r => r.clubId === clubId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getByZone: (zoneId: string): AutomatedReport[] => {
    const reports = reportDB.getAll();
    return reports.filter(r => r.zoneId === zoneId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getPendingSubmission: (zoneId: string): AutomatedReport[] => {
    const reports = reportDB.getAll();
    return reports.filter(r => 
      r.zoneId === zoneId && 
      (r.lionsPortalStatus === 'Not Submitted' || !r.lionsPortalStatus)
    );
  },
  
  create: (report: AutomatedReport): AutomatedReport => {
    const reports = reportDB.getAll();
    reports.push(report);
    localStorage.setItem(STORAGE_KEYS.reports, JSON.stringify(reports));
    return report;
  },
  
  update: (id: string, updates: Partial<AutomatedReport>): AutomatedReport | null => {
    const reports = reportDB.getAll();
    const index = reports.findIndex(r => r.id === id);
    if (index === -1) return null;
    reports[index] = { ...reports[index], ...updates, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.reports, JSON.stringify(reports));
    return reports[index];
  },
  
  delete: (id: string): boolean => {
    const reports = reportDB.getAll();
    const filtered = reports.filter(r => r.id !== id);
    localStorage.setItem(STORAGE_KEYS.reports, JSON.stringify(filtered));
    return reports.length !== filtered.length;
  }
};

// ===== SOCIAL IMPACT DATABASE =====
export const socialImpactDB = {
  getAll: (): SocialImpactReport[] => {
    const data = localStorage.getItem(STORAGE_KEYS.socialImpact);
    return data ? JSON.parse(data) : [];
  },
  
  getByClub: (clubId: string): SocialImpactReport[] => {
    const reports = socialImpactDB.getAll();
    return reports.filter(r => r.clubId === clubId);
  },
  
  getByZone: (zoneId: string): SocialImpactReport[] => {
    const reports = socialImpactDB.getAll();
    return reports.filter(r => r.zoneId === zoneId);
  },
  
  create: (report: SocialImpactReport): SocialImpactReport => {
    const reports = socialImpactDB.getAll();
    reports.push(report);
    localStorage.setItem(STORAGE_KEYS.socialImpact, JSON.stringify(reports));
    return report;
  },
  
  update: (id: string, updates: Partial<SocialImpactReport>): SocialImpactReport | null => {
    const reports = socialImpactDB.getAll();
    const index = reports.findIndex(r => r.id === id);
    if (index === -1) return null;
    reports[index] = { ...reports[index], ...updates, updatedAt: new Date().toISOString() };
    localStorage.setItem(STORAGE_KEYS.socialImpact, JSON.stringify(reports));
    return reports[index];
  }
};

// ===== NOTIFICATION DATABASE =====
export const notificationDB = {
  getAll: (): Notification[] => {
    const data = localStorage.getItem(STORAGE_KEYS.notifications);
    return data ? JSON.parse(data) : [];
  },
  
  getByRecipient: (recipientId: string): Notification[] => {
    const notifications = notificationDB.getAll();
    return notifications.filter(n => n.recipientId === recipientId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
  
  getUnread: (recipientId: string): Notification[] => {
    const notifications = notificationDB.getAll();
    return notifications.filter(n => n.recipientId === recipientId && !n.isRead);
  },
  
  create: (notification: Notification): Notification => {
    const notifications = notificationDB.getAll();
    notifications.push(notification);
    localStorage.setItem(STORAGE_KEYS.notifications, JSON.stringify(notifications));
    return notification;
  },
  
  markAsRead: (id: string): boolean => {
    const notifications = notificationDB.getAll();
    const index = notifications.findIndex(n => n.id === id);
    if (index === -1) return false;
    notifications[index].isRead = true;
    notifications[index].readAt = new Date().toISOString();
    localStorage.setItem(STORAGE_KEYS.notifications, JSON.stringify(notifications));
    return true;
  },
  
  markAllAsRead: (recipientId: string): void => {
    const notifications = notificationDB.getAll();
    notifications.forEach(n => {
      if (n.recipientId === recipientId && !n.isRead) {
        n.isRead = true;
        n.readAt = new Date().toISOString();
      }
    });
    localStorage.setItem(STORAGE_KEYS.notifications, JSON.stringify(notifications));
  },
  
  delete: (id: string): boolean => {
    const notifications = notificationDB.getAll();
    const filtered = notifications.filter(n => n.id !== id);
    localStorage.setItem(STORAGE_KEYS.notifications, JSON.stringify(filtered));
    return notifications.length !== filtered.length;
  }
};

// ===== ZONE DASHBOARD STATS =====
export function getZoneDashboardStats(zoneId: string): ZoneDashboardStats {
  const clubs = clubDB.getByZone(zoneId);
  const attendanceRecords = attendanceDB.getByZone(zoneId);
  const advisories = advisoryDB.getByZone(zoneId);
  const reports = reportDB.getByZone(zoneId);
  
  // Calculate totals
  const totalMembers = clubs.reduce((sum, c) => sum + c.stats.totalMembers, 0);
  const totalServiceActivities = clubs.reduce((sum, c) => sum + c.stats.serviceActivities, 0);
  const totalVolunteerHours = clubs.reduce((sum, c) => sum + c.stats.volunteerHours, 0);
  const totalFundsRaised = clubs.reduce((sum, c) => sum + c.stats.fundsRaised, 0);
  const totalBeneficiaries = clubs.reduce((sum, c) => sum + c.stats.beneficiariesServed, 0);
  
  // Calculate attendance average
  const averageAttendance = attendanceRecords.length > 0
    ? attendanceRecords.reduce((sum, r) => sum + r.attendancePercentage, 0) / attendanceRecords.length
    : 0;
  
  // Generate club rankings
  const clubRankings: ClubRanking[] = clubs.map((club, index) => ({
    clubId: club.id,
    clubName: club.clubName,
    clubNumber: club.clubNumber,
    rank: index + 1,
    score: Math.round(
      (club.stats.activeMembers / Math.max(club.stats.totalMembers, 1)) * 20 +
      Math.min(club.stats.serviceActivities / 10, 20) +
      Math.min(club.stats.volunteerHours / 100, 20) +
      Math.min(club.stats.fundsRaised / 50000, 20) +
      20 // Reporting score
    ),
    metrics: {
      attendance: Math.round((club.stats.activeMembers / Math.max(club.stats.totalMembers, 1)) * 100),
      membership: club.stats.totalMembers,
      service: club.stats.serviceActivities,
      fundraising: Math.round(club.stats.fundsRaised / 1000),
      reporting: 100
    }
  })).sort((a, b) => b.score - a.score).map((r, i) => ({ ...r, rank: i + 1 }));
  
  // Generate alerts
  const alerts: ZoneAlert[] = [];
  
  clubs.forEach(club => {
    const clubAttendance = attendanceDB.getStats(club.id);
    if (clubAttendance.averageAttendance < 60) {
      alerts.push({
        id: generateId(),
        type: 'Attendance',
        severity: 'Warning',
        clubId: club.id,
        clubName: club.clubName,
        message: `${club.clubName} has low attendance (${clubAttendance.averageAttendance}%)`,
        actionRequired: 'Review attendance and send advisory',
        createdAt: new Date().toISOString()
      });
    }
    
    if (club.stats.totalMembers < 20) {
      alerts.push({
        id: generateId(),
        type: 'Membership',
        severity: 'Warning',
        clubId: club.id,
        clubName: club.clubName,
        message: `${club.clubName} has low membership (${club.stats.totalMembers} members)`,
        actionRequired: 'Focus on membership growth',
        createdAt: new Date().toISOString()
      });
    }
  });
  
  return {
    totalClubs: clubs.length,
    totalMembers,
    totalServiceActivities,
    totalVolunteerHours,
    totalFundsRaised,
    totalBeneficiaries,
    clubRankings,
    attendanceTrend: [],
    averageAttendance: Math.round(averageAttendance * 10) / 10,
    membershipTrend: [],
    membershipGrowth: 0,
    activitiesByCategory: [],
    activitiesByMonth: [],
    alerts,
    pendingReports: reports.filter(r => r.lionsPortalStatus === 'Not Submitted').length,
    pendingAdvisories: advisories.filter(a => a.status !== 'Implemented').length,
    pendingApprovals: attendanceRecords.filter(r => !r.reviewedBy).length
  };
}

// ===== SEED DATA =====
export function seedZoneData(): void {
  // Check if already seeded
  if (zoneDB.getAll().length > 0) return;
  
  // Create Zone
  const zone: Zone = {
    id: generateId(),
    zoneCode: 'Z-I',
    zoneName: 'Zone I - Baroda',
    districtId: '3232F1',
    regionId: 'VI',
    chairpersonId: '',
    clubs: [],
    meetingSchedule: {
      day: '2nd Saturday',
      time: '4:00 PM',
      venue: 'Lions Hall, Vadodara',
      frequency: 'Monthly'
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  zoneDB.create(zone);
  
  // Create Club
  const club: Club = {
    id: generateId(),
    clubNumber: '179323',
    clubName: 'Lions Club of Baroda Rising Star',
    charterDate: '2020-12-01',
    zoneId: zone.id,
    districtId: '3232F1',
    regionId: 'VI',
    officers: {
      president: {
        memberId: '',
        name: 'Hiren Rathod',
        email: 'hiren.rathod@example.com',
        phone: '9712299333',
        designation: 'President',
        tenureStart: '2024-07-01',
        tenureEnd: '2025-06-30'
      },
      vicePresident: {
        memberId: '',
        name: 'TBD',
        email: '',
        phone: '',
        designation: 'Vice President',
        tenureStart: '2024-07-01',
        tenureEnd: '2025-06-30'
      },
      secretary: {
        memberId: '',
        name: 'TBD',
        email: '',
        phone: '',
        designation: 'Secretary',
        tenureStart: '2024-07-01',
        tenureEnd: '2025-06-30'
      },
      treasurer: {
        memberId: '',
        name: 'TBD',
        email: '',
        phone: '',
        designation: 'Treasurer',
        tenureStart: '2024-07-01',
        tenureEnd: '2025-06-30'
      },
      directors: []
    },
    meetingInfo: {
      day: '2nd and 4th Saturday',
      time: '7:00 PM',
      venue: '12-Kirtikunj Society, B/S Pragati Bank, Karelibaug, Vadodara',
      frequency: 'Bi-Weekly',
      nextMeetingDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    },
    email: 'barodarisingstar@gmail.com',
    phone: '+91-9712299333',
    website: 'https://lionsclubbaroda.org',
    address: {
      street: '12-Kirtikunj Society, B/S Pragati Bank',
      city: 'Vadodara',
      state: 'Gujarat',
      pincode: '390018',
      country: 'India'
    },
    socialMedia: {
      facebook: 'https://www.facebook.com/profile.php?id=61572422069093',
      instagram: 'https://www.instagram.com/barodarisingstar/'
    },
    stats: {
      totalMembers: 18,
      activeMembers: 16,
      newMembersThisYear: 2,
      serviceActivities: 12,
      volunteerHours: 450,
      fundsRaised: 250000,
      beneficiariesServed: 1200
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  clubDB.create(club);
  
  // Update zone with club
  zoneDB.update(zone.id, { clubs: [club.id] });
}
