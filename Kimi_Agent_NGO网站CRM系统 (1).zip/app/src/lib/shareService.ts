// ============================================
// SHARING SERVICE - QR Codes, Short Links, Posters
// ============================================

import { generateId } from './database';
import type { ShareLink, ShareableContent, Project } from '@/types/database';

// Generate short code (6 characters)
export function generateShortCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// Generate QR Code URL (using QRServer API)
export function generateQRCodeUrl(url: string, size: number = 200): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(url)}`;
}

// Create short link
export function createShortLink(
  entityType: 'project' | 'event' | 'campaign' | 'donation',
  entityId: string,
  _title: string
): ShareLink {
  const shortCode = generateShortCode();
  const baseUrl = window.location.origin;
  const originalUrl = `${baseUrl}/${entityType}s/${entityId}`;
  
  const shareLink: ShareLink = {
    id: generateId(),
    shortCode,
    originalUrl,
    entityType,
    entityId,
    qrCode: generateQRCodeUrl(originalUrl, 300),
    clickCount: 0,
    createdAt: new Date().toISOString(),
  };
  
  // Store in localStorage
  const links = JSON.parse(localStorage.getItem('lions_share_links') || '[]');
  links.push(shareLink);
  localStorage.setItem('lions_share_links', JSON.stringify(links));
  
  return shareLink;
}

// Get short link by code
export function getShareLink(shortCode: string): ShareLink | null {
  const links = JSON.parse(localStorage.getItem('lions_share_links') || '[]');
  return links.find((l: ShareLink) => l.shortCode === shortCode) || null;
}

// Get share links for entity
export function getEntityShareLinks(entityType: string, entityId: string): ShareLink[] {
  const links = JSON.parse(localStorage.getItem('lions_share_links') || '[]');
  return links.filter((l: ShareLink) => l.entityType === entityType && l.entityId === entityId);
}

// Increment click count
export function incrementClickCount(shortCode: string): void {
  const links = JSON.parse(localStorage.getItem('lions_share_links') || '[]');
  const link = links.find((l: ShareLink) => l.shortCode === shortCode);
  if (link) {
    link.clickCount++;
    localStorage.setItem('lions_share_links', JSON.stringify(links));
  }
}

// Generate shareable content for project
export function generateProjectShareContent(project: Project): ShareableContent {
  return {
    title: `Lions Club: ${project.name}`,
    description: `${project.description.substring(0, 150)}... Join us in making a difference!`,
    imageUrl: project.images[0],
    url: `${window.location.origin}/projects/${project.id}`,
    hashtags: ['LionsClub', 'BarodaRisingStar', 'CommunityService', project.category.replace(/\s/g, '')],
  };
}

// Generate WhatsApp share link
export function generateWhatsAppLink(content: ShareableContent): string {
  const text = `*${content.title}*\n\n${content.description}\n\n${content.url}\n\n${content.hashtags.map(h => '#' + h).join(' ')}`;
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
}

// Generate Facebook share link
export function generateFacebookLink(url: string): string {
  return `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
}

// Generate Twitter share link
export function generateTwitterLink(content: ShareableContent): string {
  const text = `${content.title}\n${content.description.substring(0, 100)}...`;
  return `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(content.url)}&hashtags=${content.hashtags.join(',')}`;
}

// Generate LinkedIn share link
export function generateLinkedInLink(url: string): string {
  return `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
}

// Generate email share link
export function generateEmailLink(content: ShareableContent): string {
  const subject = encodeURIComponent(content.title);
  const body = encodeURIComponent(`${content.description}\n\n${content.url}`);
  return `mailto:?subject=${subject}&body=${body}`;
}

// Copy to clipboard
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    // Fallback for older browsers
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    const result = document.execCommand('copy');
    document.body.removeChild(textArea);
    return result;
  }
}

// Generate embed code
export function generateEmbedCode(url: string, width: number = 560, height: number = 400): string {
  return `<iframe src="${url}" width="${width}" height="${height}" frameborder="0" allowfullscreen></iframe>`;
}

// Download QR Code
export async function downloadQRCode(url: string, filename: string): Promise<void> {
  const qrUrl = generateQRCodeUrl(url, 500);
  const response = await fetch(qrUrl);
  const blob = await response.blob();
  const downloadUrl = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = downloadUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(downloadUrl);
}

// Convert image to base64
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
  });
}

// Compress image before upload
export async function compressImage(base64: string, maxWidth: number = 1200, quality: number = 0.8): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;
      
      if (width > maxWidth) {
        height = (height * maxWidth) / width;
        width = maxWidth;
      }
      
      canvas.width = width;
      canvas.height = height;
      
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(img, 0, 0, width, height);
      
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
  });
}
