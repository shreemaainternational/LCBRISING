// ============================================
// LIONS CLUB AI CRM - DATABASE LAYER
// Professional CRM with AI Features
// ============================================

import type { 
  Member, Donor, Donation, Volunteer, Project, Event, Campaign, 
  Automation, Communication, MessageTemplate, FinancialTransaction, 
  Budget, Announcement, User, AuditLog, DashboardStats, LionsClubInfo,
  AIRecommendation
} from '@/types/database';

// Database Keys
const DB_KEYS = {
  MEMBERS: 'lions_crm_members',
  DONORS: 'lions_crm_donors',
  DONATIONS: 'lions_crm_donations',
  VOLUNTEERS: 'lions_crm_volunteers',
  PROJECTS: 'lions_crm_projects',
  EVENTS: 'lions_crm_events',
  CAMPAIGNS: 'lions_crm_campaigns',
  AUTOMATIONS: 'lions_crm_automations',
  COMMUNICATIONS: 'lions_crm_communications',
  TEMPLATES: 'lions_crm_templates',
  TRANSACTIONS: 'lions_crm_transactions',
  BUDGETS: 'lions_crm_budgets',
  ANNOUNCEMENTS: 'lions_crm_announcements',
  USERS: 'lions_crm_users',
  AUDIT_LOGS: 'lions_crm_audit_logs',
  CLUB_INFO: 'lions_crm_club_info',
  CURRENT_USER: 'lions_crm_current_user'
};

// ============================================
// GENERIC CRUD OPERATIONS
// ============================================

class Database<T extends { id: string }> {
  private key: string;

  constructor(key: string) {
    this.key = key;
  }

  getAll(): T[] {
    if (typeof window === 'undefined') return [];
    const data = localStorage.getItem(this.key);
    return data ? JSON.parse(data) : [];
  }

  getById(id: string): T | null {
    const items = this.getAll();
    return items.find(item => item.id === id) || null;
  }

  create(item: T): T {
    const items = this.getAll();
    items.push(item);
    localStorage.setItem(this.key, JSON.stringify(items));
    return item;
  }

  update(id: string, updates: Partial<T>): T | null {
    const items = this.getAll();
    const index = items.findIndex(item => item.id === id);
    if (index === -1) return null;
    
    items[index] = { ...items[index], ...updates };
    localStorage.setItem(this.key, JSON.stringify(items));
    return items[index];
  }

  delete(id: string): boolean {
    const items = this.getAll();
    const filtered = items.filter(item => item.id !== id);
    if (filtered.length === items.length) return false;
    
    localStorage.setItem(this.key, JSON.stringify(filtered));
    return true;
  }

  query(predicate: (item: T) => boolean): T[] {
    return this.getAll().filter(predicate);
  }

  count(): number {
    return this.getAll().length;
  }

  clear(): void {
    localStorage.removeItem(this.key);
  }
}

// ============================================
// DATABASE INSTANCES
// ============================================

export const db = {
  members: new Database<Member>(DB_KEYS.MEMBERS),
  donors: new Database<Donor>(DB_KEYS.DONORS),
  donations: new Database<Donation>(DB_KEYS.DONATIONS),
  volunteers: new Database<Volunteer>(DB_KEYS.VOLUNTEERS),
  projects: new Database<Project>(DB_KEYS.PROJECTS),
  events: new Database<Event>(DB_KEYS.EVENTS),
  campaigns: new Database<Campaign>(DB_KEYS.CAMPAIGNS),
  automations: new Database<Automation>(DB_KEYS.AUTOMATIONS),
  communications: new Database<Communication>(DB_KEYS.COMMUNICATIONS),
  templates: new Database<MessageTemplate>(DB_KEYS.TEMPLATES),
  transactions: new Database<FinancialTransaction>(DB_KEYS.TRANSACTIONS),
  budgets: new Database<Budget>(DB_KEYS.BUDGETS),
  announcements: new Database<Announcement>(DB_KEYS.ANNOUNCEMENTS),
  users: new Database<User>(DB_KEYS.USERS),
  auditLogs: new Database<AuditLog>(DB_KEYS.AUDIT_LOGS)
};

// ============================================
// CLUB INFO OPERATIONS
// ============================================

export const clubInfoDB = {
  get(): LionsClubInfo | null {
    if (typeof window === 'undefined') return null;
    const data = localStorage.getItem(DB_KEYS.CLUB_INFO);
    return data ? JSON.parse(data) : null;
  },
  
  set(info: LionsClubInfo): void {
    localStorage.setItem(DB_KEYS.CLUB_INFO, JSON.stringify(info));
  }
};

// ============================================
// AUTHENTICATION OPERATIONS
// ============================================

export const authDB = {
  getCurrentUser(): User | null {
    if (typeof window === 'undefined') return null;
    const data = localStorage.getItem(DB_KEYS.CURRENT_USER);
    return data ? JSON.parse(data) : null;
  },
  
  setCurrentUser(user: User | null): void {
    if (user) {
      localStorage.setItem(DB_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(DB_KEYS.CURRENT_USER);
    }
  },
  
  login(email: string, password: string): User | null {
    const users = db.users.getAll();
    const user = users.find(u => u.email === email && u.isActive);
    if (user && verifyPassword(password, user.passwordHash)) {
      authDB.setCurrentUser(user);
      db.users.update(user.id, { lastLogin: new Date().toISOString() });
      return user;
    }
    return null;
  },
  
  logout(): void {
    localStorage.removeItem(DB_KEYS.CURRENT_USER);
  },
  
  isAuthenticated(): boolean {
    return !!authDB.getCurrentUser();
  },
  
  hasPermission(permission: string): boolean {
    const user = authDB.getCurrentUser();
    if (!user) return false;
    if (user.role === 'Super Admin') return true;
    return user.permissions.includes(permission as any);
  }
};

// Simple password hashing
function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

export function hashPassword(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return hash.toString(16);
}

// ============================================
// ID GENERATORS
// ============================================

export const generateId = () => Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);

export const generateMemberId = () => `LC${Date.now().toString().slice(-6)}`;

export const generateDonorId = () => `DNR${Date.now().toString().slice(-6)}`;

export const generateDonationReceipt = () => `RCP${Date.now().toString(36).toUpperCase().slice(-8)}`;

export const generateProjectCode = () => `PRJ${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

export const generateEventCode = () => `EVT${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

export const generateCampaignCode = () => `CMP${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

export const generateTransactionCode = () => `TXN${Date.now().toString(36).toUpperCase().slice(-8)}`;

// ============================================
// AI FEATURES - DONOR SEGMENTATION
// ============================================

export function segmentDonor(donor: Donor): Donor['donorSegment'] {
  const { lifetimeValue, donationCount, lastDonationDate } = donor;
  
  // Calculate days since last donation
  const daysSinceLastDonation = lastDonationDate 
    ? Math.floor((Date.now() - new Date(lastDonationDate).getTime()) / (1000 * 60 * 60 * 24))
    : 999;
  
  // VIP/Major Donor: High lifetime value
  if (lifetimeValue >= 100000) return 'Major';
  
  // Lapsed: No donation in 180+ days
  if (daysSinceLastDonation > 180 && donationCount > 0) return 'Lapsed';
  
  // Regular: Multiple donations
  if (donationCount >= 3 && lifetimeValue >= 10000) return 'Regular';
  
  // New: First donation within 30 days
  if (donationCount === 1 && daysSinceLastDonation < 30) return 'New';
  
  return 'Occasional';
}

// ============================================
// AI FEATURES - CHURN RISK PREDICTION
// ============================================

export function predictChurnRisk(donor: Donor): 'low' | 'medium' | 'high' {
  let riskScore = 0;
  
  // Days since last donation
  const daysSinceLastDonation = donor.lastDonationDate 
    ? Math.floor((Date.now() - new Date(donor.lastDonationDate).getTime()) / (1000 * 60 * 60 * 24))
    : 999;
  
  if (daysSinceLastDonation > 365) riskScore += 40;
  else if (daysSinceLastDonation > 180) riskScore += 25;
  else if (daysSinceLastDonation > 90) riskScore += 10;
  
  // Donation frequency
  if (donor.donationCount === 1) riskScore += 20;
  else if (donor.donationCount >= 5) riskScore -= 15;
  
  // Engagement score
  if (donor.engagementScore < 30) riskScore += 20;
  else if (donor.engagementScore > 70) riskScore -= 15;
  
  // Recurring donors have lower churn risk
  if (donor.isRecurring) riskScore -= 20;
  
  if (riskScore >= 50) return 'high';
  if (riskScore >= 25) return 'medium';
  return 'low';
}

// ============================================
// AI FEATURES - PREDICTIVE FUNDRAISING
// ============================================

export function predictNextDonation(donor: Donor): string | undefined {
  if (!donor.lastDonationDate || donor.donationCount < 2) return undefined;
  
  const lastDate = new Date(donor.lastDonationDate);
  const avgDaysBetweenDonations = 90; // Default assumption
  
  const nextDate = new Date(lastDate.getTime() + avgDaysBetweenDonations * 24 * 60 * 60 * 1000);
  return nextDate.toISOString().split('T')[0];
}

export function predictMonthlyDonations(): number {
  const donations = db.donations.getAll().filter(d => d.paymentStatus === 'Completed');
  const last3Months = donations.filter(d => {
    const dDate = new Date(d.createdAt);
    const threeMonthsAgo = new Date();
    threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
    return dDate >= threeMonthsAgo;
  });
  
  const avgMonthly = last3Months.reduce((sum, d) => sum + d.amount, 0) / 3;
  return Math.round(avgMonthly * 1.1); // 10% growth prediction
}

// ============================================
// AI FEATURES - ENGAGEMENT SCORING
// ============================================

export function calculateEngagementScore(member: Member): number {
  let score = 0;
  
  // Attendance (max 30 points)
  const attendanceRate = member.attendance.length > 0
    ? member.attendance.filter(a => a.status === 'Present').length / member.attendance.length
    : 0;
  score += attendanceRate * 30;
  
  // Volunteer hours (max 25 points)
  score += Math.min(member.volunteerHours / 10, 25);
  
  // Donations (max 25 points)
  score += Math.min(member.totalDonations / 5000, 25);
  
  // Activity recency (max 20 points)
  if (member.lastActivityDate) {
    const daysSinceActivity = Math.floor((Date.now() - new Date(member.lastActivityDate).getTime()) / (1000 * 60 * 60 * 24));
    if (daysSinceActivity < 30) score += 20;
    else if (daysSinceActivity < 90) score += 10;
    else if (daysSinceActivity < 180) score += 5;
  }
  
  return Math.round(score);
}

// ============================================
// AI FEATURES - RECOMMENDATIONS
// ============================================

export function generateAIRecommendations(): AIRecommendation[] {
  const recommendations: AIRecommendation[] = [];
  
  const donors = db.donors.getAll();
  const atRiskDonors = donors.filter(d => predictChurnRisk(d) === 'high');
  
  if (atRiskDonors.length > 0) {
    recommendations.push({
      type: 'retention',
      priority: 'high',
      title: 'Re-engage At-Risk Donors',
      description: `${atRiskDonors.length} donors haven't donated in 6+ months. Send personalized re-engagement campaign.`,
      action: 'Launch retention campaign',
      expectedImpact: `Potential recovery of ₹${atRiskDonors.reduce((sum, d) => sum + d.lifetimeValue * 0.3, 0).toFixed(0)} in donations`
    });
  }
  
  const members = db.members.getAll();
  const lowEngagementMembers = members.filter(m => m.engagementScore < 40);
  
  if (lowEngagementMembers.length > 0) {
    recommendations.push({
      type: 'engagement',
      priority: 'medium',
      title: 'Boost Member Engagement',
      description: `${lowEngagementMembers.length} members have low engagement. Invite them to upcoming events.`,
      action: 'Send event invitations',
      expectedImpact: `Increase engagement score by 20-30%`
    });
  }
  
  const upcomingEvents = db.events.getAll().filter(e => new Date(e.startDate) > new Date());
  if (upcomingEvents.length > 0) {
    const event = upcomingEvents[0];
    recommendations.push({
      type: 'event',
      priority: 'high',
      title: `Promote: ${event.name}`,
      description: `Event in ${Math.ceil((new Date(event.startDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} days. Only ${event.attendees.length} registered.`,
      action: 'Send event reminders',
      expectedImpact: `Increase registrations by 40%`
    });
  }
  
  return recommendations;
}

// ============================================
// DASHBOARD STATS
// ============================================

export function getDashboardStats(): DashboardStats {
  const members = db.members.getAll();
  const donors = db.donors.getAll();
  const donations = db.donations.getAll();
  const projects = db.projects.getAll();
  const events = db.events.getAll();
  const volunteers = db.volunteers.getAll();
  const transactions = db.transactions.getAll();
  
  const now = new Date();
  const thisMonth = now.getMonth();
  const thisYear = now.getFullYear();
  
  // Calculate monthly stats
  const monthlyDonations: any[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(thisYear, thisMonth - i, 1);
    monthlyDonations.push({
      month: d.toLocaleString('default', { month: 'short' }),
      donations: 0,
      expenses: 0,
      newMembers: 0,
      volunteerHours: 0
    });
  }
  
  donations.forEach(d => {
    if (d.paymentStatus === 'Completed') {
      const dDate = new Date(d.createdAt);
      const monthIdx = monthlyDonations.findIndex(m => 
        m.month === dDate.toLocaleString('default', { month: 'short' })
      );
      if (monthIdx !== -1) monthlyDonations[monthIdx].donations += d.amount;
    }
  });
  
  // Calculate donation by category
  const categoryMap = new Map<string, number>();
  donations.filter(d => d.paymentStatus === 'Completed').forEach(d => {
    categoryMap.set(d.category, (categoryMap.get(d.category) || 0) + d.amount);
  });
  const totalDonated = Array.from(categoryMap.values()).reduce((a, b) => a + b, 0);
  const donationByCategory = Array.from(categoryMap.entries()).map(([category, amount]) => ({
    category,
    amount,
    percentage: totalDonated > 0 ? Math.round((amount / totalDonated) * 100) : 0
  }));
  
  // Calculate member growth
  const memberGrowth: any[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(thisYear, thisMonth - i, 1);
    const count = members.filter(m => new Date(m.joinDate) <= d).length;
    memberGrowth.push({
      date: d.toISOString().split('T')[0],
      members: count,
      donors: donors.filter((dn: Donor) => new Date(dn.createdAt) <= d).length
    });
  }
  
  // Calculate donor retention
  const activeDonors = donors.filter(d => d.donorSegment !== 'Lapsed').length;
  const donorRetentionRate = donors.length > 0 ? Math.round((activeDonors / donors.length) * 100) : 0;
  
  // Calculate at-risk donors
  const atRiskDonors = donors.filter(d => predictChurnRisk(d) === 'high').length;
  
  // Calculate YTD finances
  const ytdIncome = transactions
    .filter(t => t.type === 'Income' && new Date(t.date).getFullYear() === thisYear)
    .reduce((sum, t) => sum + t.amount, 0);
  const ytdExpense = transactions
    .filter(t => t.type === 'Expense' && new Date(t.date).getFullYear() === thisYear)
    .reduce((sum, t) => sum + t.amount, 0);
  
  return {
    totalMembers: members.length,
    activeMembers: members.filter(m => m.status === 'Active').length,
    newMembersThisMonth: members.filter(m => new Date(m.joinDate).getMonth() === thisMonth).length,
    memberGrowthRate: 15, // Simulated
    
    totalDonations: donations.filter(d => d.paymentStatus === 'Completed').reduce((sum, d) => sum + d.amount, 0),
    donationsThisMonth: donations.filter(d => {
      const dDate = new Date(d.createdAt);
      return d.paymentStatus === 'Completed' && dDate.getMonth() === thisMonth && dDate.getFullYear() === thisYear;
    }).reduce((sum, d) => sum + d.amount, 0),
    donationsThisYear: donations.filter(d => {
      return d.paymentStatus === 'Completed' && new Date(d.createdAt).getFullYear() === thisYear;
    }).reduce((sum, d) => sum + d.amount, 0),
    averageDonation: donations.filter(d => d.paymentStatus === 'Completed').length > 0
      ? Math.round(donations.filter(d => d.paymentStatus === 'Completed').reduce((sum, d) => sum + d.amount, 0) / donations.filter(d => d.paymentStatus === 'Completed').length)
      : 0,
    recurringDonors: donors.filter(d => d.isRecurring).length,
    
    totalDonors: donors.length,
    donorRetentionRate,
    donorChurnRisk: atRiskDonors,
    
    totalProjects: projects.length,
    activeProjects: projects.filter(p => p.status === 'In Progress').length,
    completedProjects: projects.filter(p => p.status === 'Completed').length,
    projectsThisMonth: projects.filter(p => new Date(p.createdAt).getMonth() === thisMonth).length,
    
    totalEvents: events.length,
    upcomingEvents: events.filter(e => new Date(e.startDate) > now).length,
    eventsThisMonth: events.filter(e => new Date(e.startDate).getMonth() === thisMonth).length,
    averageAttendance: 75, // Simulated
    
    totalVolunteers: volunteers.length,
    activeVolunteers: volunteers.filter(v => v.status === 'Active').length,
    volunteerHoursThisMonth: volunteers.reduce((sum, v) => sum + v.totalHours, 0),
    
    totalBeneficiaries: projects.reduce((sum, p) => sum + p.beneficiaries, 0),
    volunteerHours: volunteers.reduce((sum, v) => sum + v.totalHours, 0),
    
    yearToDateIncome: ytdIncome,
    yearToDateExpense: ytdExpense,
    netBalance: ytdIncome - ytdExpense,
    
    predictedDonationsNextMonth: predictMonthlyDonations(),
    atRiskDonors,
    recommendedActions: generateAIRecommendations(),
    
    monthlyDonations,
    donationByCategory,
    memberGrowth,
    recentDonations: donations.slice(-5).reverse(),
    recentMembers: members.slice(-5).reverse(),
    upcomingEventsList: events.filter(e => new Date(e.startDate) > now).slice(0, 5)
  };
}

// ============================================
// CSV EXPORT FOR LIONS PORTAL
// ============================================

export function exportMembersToCSV(): string {
  const members = db.members.getAll();
  
  const headers = [
    'Member ID', 'First Name', 'Last Name', 'Email', 'Phone',
    'Address', 'City', 'State', 'Pincode', 'Date of Birth',
    'Join Date', 'Designation', 'Status', 'Membership Type'
  ];
  
  const rows = members.map(m => [
    m.memberId,
    m.firstName,
    m.lastName,
    m.email,
    m.phone,
    m.address.street,
    m.address.city,
    m.address.state,
    m.address.pincode,
    m.dateOfBirth,
    m.joinDate,
    m.designation,
    m.status,
    m.membershipType
  ]);
  
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
  ].join('\n');
  
  return csvContent;
}

export function downloadCSV(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
}

// ============================================
// AUDIT LOGGING
// ============================================

export function logAudit(
  userId: string,
  userName: string,
  action: string,
  entityType: string,
  entityId: string,
  oldValue?: any,
  newValue?: any
): void {
  const log: AuditLog = {
    id: generateId(),
    userId,
    userName,
    action,
    entityType,
    entityId,
    oldValue: oldValue ? JSON.stringify(oldValue) : undefined,
    newValue: newValue ? JSON.stringify(newValue) : undefined,
    timestamp: new Date().toISOString()
  };
  db.auditLogs.create(log);
}

// ============================================
// SEED DATA
// ============================================

export function seedDatabase(): void {
  if (typeof window === 'undefined') return;
  if (db.members.getAll().length > 0) return;
  
  // Seed Club Info
  const clubInfo: LionsClubInfo = {
    clubName: 'Lions Club of Baroda Rising Star',
    clubNumber: '179323',
    charterDate: '2020-12-01',
    district: '3232F1',
    region: 'VI',
    zone: 'I',
    meetingVenue: '12-Kirtikunj Society, B/S Pragati Bank, Karelibaug, Vadodara',
    meetingDay: '2nd and 4th Saturday',
    meetingTime: '7:00 PM',
    logo: '/logo.png',
    website: 'https://lionsclubbaroda.org',
    email: 'barodarisingstar@gmail.com',
    phone: '+91-9712299333',
    socialMedia: {
      facebook: 'https://www.facebook.com/profile.php?id=61572422069093',
      instagram: 'https://www.instagram.com/barodarisingstar/'
    }
  };
  clubInfoDB.set(clubInfo);
  
  // Seed Admin User
  const adminUser: User = {
    id: generateId(),
    email: 'admin@lionsclub.org',
    passwordHash: hashPassword('admin123'),
    role: 'Super Admin',
    permissions: ['members.view', 'members.create', 'members.edit', 'members.delete', 'members.export',
      'donors.view', 'donors.create', 'donors.edit', 'donors.delete',
      'donations.view', 'donations.create', 'donations.edit', 'donations.delete',
      'projects.view', 'projects.create', 'projects.edit', 'projects.delete',
      'events.view', 'events.create', 'events.edit', 'events.delete',
      'volunteers.view', 'volunteers.create', 'volunteers.edit', 'volunteers.delete',
      'campaigns.view', 'campaigns.create', 'campaigns.edit', 'campaigns.delete',
      'finance.view', 'finance.create', 'finance.edit', 'finance.delete',
      'reports.view', 'reports.create', 'reports.export',
      'automation.view', 'automation.create', 'automation.edit', 'automation.delete',
      'settings.view', 'settings.edit', 'announcements.manage'],
    loginAttempts: 0,
    isActive: true,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  db.users.create(adminUser);
  
  console.log('✅ AI CRM Database seeded successfully!');
}

// Initialize database
if (typeof window !== 'undefined') {
  seedDatabase();
}
