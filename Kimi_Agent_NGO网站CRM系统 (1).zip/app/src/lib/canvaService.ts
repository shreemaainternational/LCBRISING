// ============================================
// CANVA INTEGRATION SERVICE
// ============================================

import { generateId } from './database';
import type { 
  CanvaConfig, 
  CanvaDesign, 
  CanvaTemplate, 
  CanvaExport
} from '@/types/canvaConfig';
import { 
  defaultCanvaConfig,
  CANVA_EMBED_URLS 
} from '@/types/canvaConfig';

// Storage keys
const STORAGE_KEYS = {
  config: 'lions_canva_config',
  designs: 'lions_canva_designs',
  exports: 'lions_canva_exports'
};

// ============================================
// CONFIGURATION MANAGEMENT
// ============================================

export const canvaConfigDB = {
  get: (): CanvaConfig => {
    const data = localStorage.getItem(STORAGE_KEYS.config);
    if (data) {
      return { ...defaultCanvaConfig, ...JSON.parse(data) };
    }
    return defaultCanvaConfig;
  },
  
  set: (config: Partial<CanvaConfig>): void => {
    const current = canvaConfigDB.get();
    const updated = { ...current, ...config };
    localStorage.setItem(STORAGE_KEYS.config, JSON.stringify(updated));
  },
  
  reset: (): void => {
    localStorage.setItem(STORAGE_KEYS.config, JSON.stringify(defaultCanvaConfig));
  },
  
  isEnabled: (): boolean => {
    return canvaConfigDB.get().enabled;
  },
  
  getTemplates: (category?: string): CanvaTemplate[] => {
    const config = canvaConfigDB.get();
    if (category) {
      return config.templates.filter(t => t.category === category);
    }
    return config.templates;
  },
  
  getBrandKit: () => {
    return canvaConfigDB.get().brandKit;
  }
};

// ============================================
// DESIGN MANAGEMENT
// ============================================

export const canvaDesignDB = {
  getAll: (): CanvaDesign[] => {
    const data = localStorage.getItem(STORAGE_KEYS.designs);
    return data ? JSON.parse(data) : [];
  },
  
  getById: (id: string): CanvaDesign | null => {
    const designs = canvaDesignDB.getAll();
    return designs.find(d => d.id === id) || null;
  },
  
  getByEntity: (entityType: string, entityId: string): CanvaDesign[] => {
    const designs = canvaDesignDB.getAll();
    return designs.filter(d => d.entityType === entityType && d.entityId === entityId)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  },
  
  create: (design: Omit<CanvaDesign, 'id' | 'createdAt' | 'updatedAt' | 'version'>): CanvaDesign => {
    const designs = canvaDesignDB.getAll();
    const newDesign: CanvaDesign = {
      ...design,
      id: generateId(),
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    designs.push(newDesign);
    localStorage.setItem(STORAGE_KEYS.designs, JSON.stringify(designs));
    return newDesign;
  },
  
  update: (id: string, updates: Partial<CanvaDesign>): CanvaDesign | null => {
    const designs = canvaDesignDB.getAll();
    const index = designs.findIndex(d => d.id === id);
    if (index === -1) return null;
    
    designs[index] = { 
      ...designs[index], 
      ...updates, 
      version: designs[index].version + 1,
      updatedAt: new Date().toISOString() 
    };
    localStorage.setItem(STORAGE_KEYS.designs, JSON.stringify(designs));
    return designs[index];
  },
  
  delete: (id: string): boolean => {
    const designs = canvaDesignDB.getAll();
    const filtered = designs.filter(d => d.id !== id);
    localStorage.setItem(STORAGE_KEYS.designs, JSON.stringify(filtered));
    return designs.length !== filtered.length;
  },
  
  addExport: (designId: string, exportData: CanvaExport): CanvaDesign | null => {
    const design = canvaDesignDB.getById(designId);
    if (!design) return null;
    
    design.exports.push(exportData);
    return canvaDesignDB.update(designId, { exports: design.exports });
  }
};

// ============================================
// CANVA EMBED/EDITOR URLS
// ============================================

export const canvaUrls = {
  // Open Canva editor with a new design from template
  createDesign: (templateId?: string, prefillData?: Record<string, any>): string => {
    const config = canvaConfigDB.get();
    
    // Use prefillData if available for better template matching
    const searchQuery = prefillData?.category 
      ? `lions+club+${prefillData.category.toLowerCase().replace(/\s/g, '+')}`
      : 'lions+club+event';
    
    // If we have a Canva API integration, use it
    if (config.apiKey && config.partnerId) {
      // This would call the actual Canva API
      // For now, return the template URL
      return `https://www.canva.com/design?template=${templateId || ''}`;
    }
    
    // Fallback: Open Canva with search for Lions Club templates
    return `https://www.canva.com/templates/?search=${searchQuery}`;
  },
  
  // Edit an existing design
  editDesign: (canvaDesignId: string): string => {
    return CANVA_EMBED_URLS.editor(canvaDesignId);
  },
  
  // View a design (read-only)
  viewDesign: (canvaDesignId: string): string => {
    return CANVA_EMBED_URLS.viewer(canvaDesignId);
  },
  
  // Embed a design in iframe
  embedDesign: (canvaDesignId: string): string => {
    return CANVA_EMBED_URLS.embed(canvaDesignId);
  },
  
  // Browse templates
  browseTemplates: (category?: string): string => {
    const searchTerms: Record<string, string> = {
      'social': 'social+media+post',
      'poster': 'event+poster',
      'flyer': 'flyer',
      'banner': 'banner',
      'presentation': 'presentation'
    };
    
    const search = category && searchTerms[category] 
      ? searchTerms[category] 
      : 'lions+club';
    
    return `https://www.canva.com/templates/?search=${search}`;
  }
};

// ============================================
// DESIGN CREATION HELPERS
// ============================================

export function createDesignFromTemplate(
  templateId: string,
  entityType: CanvaDesign['entityType'],
  entityId?: string,
  title?: string
): { design: CanvaDesign; editorUrl: string } {
  const config = canvaConfigDB.get();
  const template = config.templates.find(t => t.id === templateId);
  
  if (!template) {
    throw new Error(`Template ${templateId} not found`);
  }
  
  // Create design record in CRM
  const design = canvaDesignDB.create({
    title: title || `New ${template.name}`,
    description: `Created from ${template.name} template`,
    entityType,
    entityId,
    templateId,
    dimensions: {
      width: template.defaultDimensions.width,
      height: template.defaultDimensions.height
    },
    exports: [],
    status: 'draft',
    createdBy: 'current-user',
    collaborators: []
  });
  
  // Get Canva editor URL
  const editorUrl = canvaUrls.createDesign(templateId, template.prefillData);
  
  return { design, editorUrl };
}

// ============================================
// EXPORT HANDLING
// ============================================

export function createExport(
  designId: string,
  format: CanvaExport['format'],
  url: string,
  dimensions: { width: number; height: number },
  fileSize: number = 0
): CanvaExport {
  const exportData: CanvaExport = {
    id: generateId(),
    format,
    quality: 'high',
    url,
    fileSize,
    dimensions,
    exportedAt: new Date().toISOString(),
    exportedBy: 'current-user'
  };
  
  canvaDesignDB.addExport(designId, exportData);
  return exportData;
}

// ============================================
// BRAND KIT HELPERS
// ============================================

export function getBrandKitCSS(): string {
  const brandKit = canvaConfigDB.getBrandKit();
  if (!brandKit) return '';
  
  return `
    :root {
      --lions-primary: ${brandKit.colors.primary};
      --lions-secondary: ${brandKit.colors.secondary};
      --lions-accent: ${brandKit.colors.accent};
      --lions-text: ${brandKit.colors.text};
      --lions-background: ${brandKit.colors.background};
      --lions-font-heading: ${brandKit.fonts.heading};
      --lions-font-body: ${brandKit.fonts.body};
    }
  `;
}

// ============================================
// PREFILL DATA GENERATORS
// ============================================

export function generateProjectPrefill(project: any): Record<string, any> {
  return {
    title: project.name,
    description: project.description,
    date: new Date(project.startDate).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }),
    location: project.location,
    clubName: 'Lions Club of Baroda Rising Star',
    hashtag: '#LionsClub #WeServe #BarodaRisingStar',
    category: project.category
  };
}

export function generateEventPrefill(event: any): Record<string, any> {
  return {
    title: event.name,
    description: event.description,
    date: new Date(event.startDate).toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }),
    time: event.time || '7:00 PM',
    venue: event.venue,
    address: event.address,
    clubName: 'Lions Club of Baroda Rising Star',
    hashtag: '#LionsClub #WeServe #BarodaRisingStar'
  };
}

// ============================================
// INITIALIZATION
// ============================================

export function initializeCanva(): void {
  // Ensure default config exists
  const config = canvaConfigDB.get();
  if (!config.enabled) {
    console.log('Canva integration is disabled');
    return;
  }
  
  // Inject brand kit CSS if available
  const brandCSS = getBrandKitCSS();
  if (brandCSS) {
    const styleEl = document.createElement('style');
    styleEl.id = 'lions-canva-brand';
    styleEl.textContent = brandCSS;
    document.head.appendChild(styleEl);
  }
  
  console.log('Canva integration initialized');
}

// Initialize on module load
if (typeof window !== 'undefined') {
  initializeCanva();
}
