import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, Users, Heart, HandHeart, Briefcase, Calendar, 
  Megaphone, Zap, BarChart3, MessageSquare, Settings, LogOut, 
  Menu, X, Bell, Sparkles, Crown
} from 'lucide-react';
import { toast } from 'sonner';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { authDB } from '@/lib/database';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const user = authDB.getCurrentUser();

  useEffect(() => {
    if (!authDB.isAuthenticated()) {
      navigate('/admin');
    }
  }, [navigate]);

  const handleLogout = () => {
    authDB.logout();
    toast.success('Logged out successfully');
    navigate('/admin');
  };

  const menuItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard', badge: null },
    { icon: Crown, label: 'Zone Control', path: '/admin/zone', badge: 'NEW' },
    { icon: Users, label: 'Members', path: '/admin/members', badge: null },
    { icon: Heart, label: 'Donors', path: '/admin/donors', badge: 'AI' },
    { icon: HandHeart, label: 'Donations', path: '/admin/donations', badge: null },
    { icon: Briefcase, label: 'Service Activities', path: '/admin/projects', badge: null },
    { icon: Calendar, label: 'Events', path: '/admin/events', badge: null },
    { icon: Users, label: 'Volunteers', path: '/admin/volunteers', badge: null },
    { icon: Megaphone, label: 'Campaigns', path: '/admin/campaigns', badge: null },
    { icon: Zap, label: 'Automation', path: '/admin/automation', badge: 'AI' },
    { icon: BarChart3, label: 'Reports', path: '/admin/reports', badge: null },
    { icon: MessageSquare, label: 'Communications', path: '/admin/communications', badge: null },
    { icon: Settings, label: 'Settings', path: '/admin/settings', badge: null },
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <aside className={`${sidebarOpen ? 'w-72' : 'w-20'} bg-gradient-to-b from-blue-900 via-blue-900 to-blue-950 text-white transition-all duration-300 hidden lg:flex flex-col fixed h-full z-30`}>
        {/* Logo */}
        <div className="p-6 flex items-center justify-between border-b border-white/10">
          {sidebarOpen ? (
            <div>
              <div className="font-bold text-lg">Lions Club CRM</div>
              <div className="text-blue-300 text-xs">AI-Powered</div>
            </div>
          ) : (
            <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center">
              <span className="text-blue-900 font-bold text-lg">L</span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 py-4 overflow-y-auto">
          {menuItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-3 mx-2 rounded-xl transition-all duration-200 group ${
                location.pathname === item.path 
                  ? 'bg-yellow-500 text-blue-900 shadow-lg' 
                  : 'hover:bg-white/10 text-blue-100'
              }`}
            >
              <item.icon className={`w-5 h-5 ${location.pathname === item.path ? 'text-blue-900' : 'text-blue-300 group-hover:text-white'}`} />
              {sidebarOpen && (
                <>
                  <span className="ml-3 flex-1">{item.label}</span>
                  {item.badge && (
                    <Badge className="bg-purple-500 text-white text-[10px] px-1.5 py-0">
                      <Sparkles className="w-3 h-3 mr-1" />
                      {item.badge}
                    </Badge>
                  )}
                </>
              )}
            </Link>
          ))}
        </nav>
        
        {/* User Profile */}
        <div className="p-4 border-t border-white/10">
          <div className={`flex items-center ${sidebarOpen ? 'space-x-3' : 'justify-center'}`}>
            <Avatar className="w-10 h-10 border-2 border-yellow-500">
              <AvatarFallback className="bg-yellow-500 text-blue-900 font-bold">
                {user?.email?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.role}</p>
                <p className="text-xs text-blue-300 truncate">{user?.email}</p>
              </div>
            )}
          </div>
          
          <button 
            onClick={handleLogout}
            className={`mt-4 flex items-center ${sidebarOpen ? 'px-4' : 'justify-center'} py-2 w-full hover:bg-white/10 rounded-lg transition-colors text-red-300 hover:text-red-200`}
          >
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span className="ml-3">Logout</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Sidebar */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileMenuOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-72 bg-gradient-to-b from-blue-900 to-blue-950 text-white">
            <div className="p-6 flex items-center justify-between border-b border-white/10">
              <div>
                <div className="font-bold text-lg">Lions Club CRM</div>
                <div className="text-blue-300 text-xs">AI-Powered</div>
              </div>
              <button onClick={() => setMobileMenuOpen(false)} className="p-2 hover:bg-white/10 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="py-4">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center px-4 py-3 mx-2 rounded-xl transition-all ${
                    location.pathname === item.path 
                      ? 'bg-yellow-500 text-blue-900' 
                      : 'hover:bg-white/10 text-blue-100'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span className="ml-3 flex-1">{item.label}</span>
                  {item.badge && <Badge className="bg-purple-500 text-white text-xs">{item.badge}</Badge>}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${sidebarOpen ? 'lg:ml-72' : 'lg:ml-20'}`}>
        {/* Header */}
        <header className="bg-white shadow-sm sticky top-0 z-20">
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setMobileMenuOpen(true)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">
                  {menuItems.find(m => m.path === location.pathname)?.label || 'Dashboard'}
                </h1>
                <p className="text-sm text-gray-500">Welcome back, {user?.role}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="p-2 hover:bg-gray-100 rounded-full relative">
                <Bell className="w-5 h-5 text-gray-600" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              <Avatar className="w-9 h-9 border-2 border-blue-900">
                <AvatarFallback className="bg-blue-900 text-white text-sm">
                  {user?.email?.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-auto">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
