import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'sonner';
import './App.css';

// Public Components
import PublicNavbar from './components/PublicNavbar';
import Footer from './components/Footer';

// Public Pages
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import ProjectsPage from './pages/ProjectsPage';
import EventsPage from './pages/EventsPage';
import ContactPage from './pages/ContactPage';
import DonatePage from './pages/DonatePage';
import VolunteerPage from './pages/VolunteerPage';

// Admin Pages
import LoginPage from './pages/admin/LoginPage';
import AdminDashboard from './pages/admin/AdminDashboard';
import ZoneDashboard from './pages/admin/ZoneDashboard';
import MembersManagement from './pages/admin/MembersManagement';
import DonorsManagement from './pages/admin/DonorsManagement';
import DonationsManagement from './pages/admin/DonationsManagement';
import VolunteersManagement from './pages/admin/VolunteersManagement';
import ProjectsManagement from './pages/admin/ProjectsManagement';
import EventsManagement from './pages/admin/EventsManagement';
import CampaignsManagement from './pages/admin/CampaignsManagement';
import AutomationPage from './pages/admin/AutomationPage';
import ReportsPage from './pages/admin/ReportsPage';
import CommunicationsPage from './pages/admin/CommunicationsPage';
import SettingsPage from './pages/admin/SettingsPage';

// Admin Layout
import AdminLayout from './components/AdminLayout';

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-right" richColors />
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<><PublicNavbar /><HomePage /><Footer /></>} />
        <Route path="/about" element={<><PublicNavbar /><AboutPage /><Footer /></>} />
        <Route path="/projects" element={<><PublicNavbar /><ProjectsPage /><Footer /></>} />
        <Route path="/events" element={<><PublicNavbar /><EventsPage /><Footer /></>} />
        <Route path="/contact" element={<><PublicNavbar /><ContactPage /><Footer /></>} />
        <Route path="/donate" element={<><PublicNavbar /><DonatePage /><Footer /></>} />
        <Route path="/volunteer" element={<><PublicNavbar /><VolunteerPage /><Footer /></>} />
        
        {/* Admin Routes */}
        <Route path="/admin" element={<LoginPage />} />
        <Route path="/admin/dashboard" element={<AdminLayout><AdminDashboard /></AdminLayout>} />
        <Route path="/admin/zone" element={<AdminLayout><ZoneDashboard /></AdminLayout>} />
        <Route path="/admin/members" element={<AdminLayout><MembersManagement /></AdminLayout>} />
        <Route path="/admin/donors" element={<AdminLayout><DonorsManagement /></AdminLayout>} />
        <Route path="/admin/donations" element={<AdminLayout><DonationsManagement /></AdminLayout>} />
        <Route path="/admin/volunteers" element={<AdminLayout><VolunteersManagement /></AdminLayout>} />
        <Route path="/admin/projects" element={<AdminLayout><ProjectsManagement /></AdminLayout>} />
        <Route path="/admin/events" element={<AdminLayout><EventsManagement /></AdminLayout>} />
        <Route path="/admin/campaigns" element={<AdminLayout><CampaignsManagement /></AdminLayout>} />
        <Route path="/admin/automation" element={<AdminLayout><AutomationPage /></AdminLayout>} />
        <Route path="/admin/reports" element={<AdminLayout><ReportsPage /></AdminLayout>} />
        <Route path="/admin/communications" element={<AdminLayout><CommunicationsPage /></AdminLayout>} />
        <Route path="/admin/settings" element={<AdminLayout><SettingsPage /></AdminLayout>} />
        
        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
